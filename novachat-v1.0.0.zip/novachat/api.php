<?php
/**
 * NovaChat - API
 * Tüm veri alışverişi buradan yapılır. İstemciye asla ham veritabanı
 * verisi gönderilmez; her istek sunucu tarafında doğrulanır.
 */
declare(strict_types=1);

require __DIR__ . '/core.php';

if (PHP_SAPI === 'cli') {
    exit;
}

$action = (string)($_GET['action'] ?? '');
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$data   = nc_input();
$now    = time();

if ($action === '') {
    nc_fail('İşlem belirtilmedi.', 400);
}

// POST isteklerinde CSRF koruması (multipart dahil)
if ($method === 'POST') {
    nc_csrf_check();
}

// Gövde sunucu limitini aştıysa (PHP post_max_size) anlaşılır hata ver
$contentType = (string)($_SERVER['CONTENT_TYPE'] ?? '');
if ($method === 'POST'
    && stripos($contentType, 'multipart/form-data') !== false
    && empty($_FILES)
    && empty($_POST)
    && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
    nc_fail('Dosya sunucu limitini aşıyor. php.ini içindeki post_max_size / upload_max_filesize değerlerini artır.', 413);
}

/* ============================================================
   YARDIMCI: MESAJ SORGUSU
   ============================================================ */

function nc_api_messages(int $sinceId, int $limit = 100): array
{
    $pdo = nc_db();
    $limit = max(1, min($limit, 200));
    if ($sinceId <= 0) {
        $sql = nc_message_sql() . ' WHERE m.deleted = 0 ORDER BY m.id DESC LIMIT ' . $limit;
        $stmt = $pdo->query($sql);
        $rows = array_reverse($stmt->fetchAll());
    } else {
        $stmt = $pdo->prepare(nc_message_sql() . ' WHERE m.deleted = 0 AND m.id > ? ORDER BY m.id ASC LIMIT ' . $limit);
        $stmt->execute([$sinceId]);
        $rows = $stmt->fetchAll();
    }
    $out = [];
    foreach ($rows as $r) {
        $out[] = nc_message_view($r);
    }
    return $out;
}

/* ============================================================
   GİRİŞ / ÇIKIŞ
   ============================================================ */

if ($action === 'login') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    if (nc_ip_banned(nc_client_ip())) {
        nc_fail('Bu IP adresinden giriş yapılamıyor.', 403, ['ip_banned' => true]);
    }
    if ((int)nc_setting('maintenance', '0') === 1) {
        nc_fail('Site bakım modunda.', 503);
    }
    if (!nc_throttle('login:' . nc_client_ip(), 12, 60)) {
        nc_fail('Çok fazla giriş denemesi. Lütfen 1 dakika bekle.', 429);
    }
    $name = trim((string)($data['username'] ?? ''));
    if (!preg_match('/^[\p{L}\p{N}_]{3,20}$/u', $name)) {
        nc_fail('Kullanıcı adı 3-20 karakter olmalı; sadece harf, rakam ve alt çizgi kullanılabilir.');
    }
    if (!nc_username_valid($name)) {
        nc_fail('Bu kullanıcı adı sistem tarafından rezerve edilmiş. Başka bir ad seç.');
    }
    $lower = mb_strtolower($name, 'UTF-8');
    $pdo = nc_db();
    $stmt = $pdo->prepare('SELECT * FROM nc_users WHERE username_lc = ? LIMIT 1');
    $stmt->execute([$lower]);
    $user = $stmt->fetch();

    if ($user) {
        if ((int)$user['is_banned'] === 1) {
            $reason = (string)$user['ban_reason'] !== '' ? (string)$user['ban_reason'] : 'Belirtilmedi';
            nc_fail('Bu hesap askıya alınmış. Sebep: ' . $reason, 403, ['banned' => true]);
        }
        if (!hash_equals((string)$user['ip'], nc_client_ip())) {
            nc_log('login_denied', 'Farklı IP ile giriş denemesi', ['username' => $name, 'owner_ip' => $user['ip']], (int)$user['id']);
            nc_fail('Bu kullanıcı adı zaten alınmış. Başka bir kullanıcı adı seç.', 409, ['taken' => true]);
        }
        nc_login_user($user);
        nc_log('login', 'Giriş yapıldı', ['username' => $user['username']], (int)$user['id']);
        nc_json(['ok' => true, 'redirect' => 'chat.php', 'username' => $user['username']]);
    }

    try {
        $stmt = $pdo->prepare('INSERT INTO nc_users (username, username_lc, ip, created_at, last_seen) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$name, $lower, nc_client_ip(), $now, $now]);
        $uid = (int)$pdo->lastInsertId();
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            nc_log('login_denied', 'Kullanıcı adı yarışı', ['username' => $name]);
            nc_fail('Bu kullanıcı adı zaten alınmış. Başka bir kullanıcı adı seç.', 409, ['taken' => true]);
        }
        nc_fail('Kayıt sırasında bir hata oluştu.', 500);
    }
    $stmt = $pdo->prepare('SELECT * FROM nc_users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();
    nc_login_user($user);
    nc_log('register', 'Yeni kullanıcı kaydı', ['username' => $name], $uid);
    nc_json(['ok' => true, 'redirect' => 'chat.php', 'username' => $name]);
}

if ($action === 'logout') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    nc_logout_user();
    nc_json(['ok' => true, 'redirect' => 'index.php']);
}

/* ============================================================
   SOHBET DURUMU (polling)
   ============================================================ */

if ($action === 'state') {
    $u = nc_require_user();
    nc_touch_user((int)$u['id']);

    $sinceId = (int)($data['since_id'] ?? ($_GET['since_id'] ?? 0));
    $deletedSince = (int)($data['deleted_since'] ?? ($_GET['deleted_since'] ?? 0));
    if ($deletedSince <= 0) {
        $deletedSince = $now;
    }

    $messages = nc_api_messages($sinceId, $sinceId <= 0 ? 60 : 100);

    $deletedStmt = nc_db()->prepare('SELECT id FROM nc_messages WHERE deleted = 1 AND deleted_at > ? ORDER BY id ASC LIMIT 200');
    $deletedStmt->execute([$deletedSince]);
    $deletedIds = array_map('intval', $deletedStmt->fetchAll(PDO::FETCH_COLUMN));

    $onlineStmt = nc_db()->prepare(
        'SELECT u.id, u.username, u.typing_at, COALESCE(g.total_earned, 0) AS score
         FROM nc_users u LEFT JOIN nc_game g ON g.user_id = u.id
         WHERE u.last_seen >= ? AND u.is_banned = 0
         ORDER BY u.username ASC LIMIT 200'
    );
    $onlineStmt->execute([$now - 70]);
    $online = [];
    $typingNames = [];
    foreach ($onlineStmt->fetchAll() as $row) {
        $typing = (int)$row['typing_at'] >= $now - 5;
        $online[] = [
            'id'       => (int)$row['id'],
            'username' => (string)$row['username'],
            'score'    => nc_num((float)$row['score']),
            'typing'   => $typing,
        ];
        if ($typing && (int)$row['id'] !== (int)$u['id']) {
            $typingNames[] = (string)$row['username'];
        }
    }

    nc_json([
        'ok'                  => true,
        'messages'            => $messages,
        'deleted_ids'         => $deletedIds,
        'next_deleted_since'  => max(0, $now - 1),
        'online'              => $online,
        'typing'              => $typingNames,
        'self'                => ['id' => (int)$u['id'], 'username' => (string)$u['username']],
        'my'                  => [
            'last_msg_at'  => (int)$u['last_msg_at'],
            'muted_until'  => (int)$u['muted_until'],
            'quota_used'   => nc_quota_used(nc_client_ip()),
            'quota_limit'  => nc_quota_limit_bytes(),
        ],
        'settings'            => [
            'cooldown_ms'      => (int)nc_setting('cooldown_ms', '3000'),
            'msg_max_len'      => (int)nc_setting('msg_max_len', '500'),
            'uploads_enabled'  => (int)nc_setting('uploads_enabled', '1'),
            'gifs_enabled'     => (int)nc_setting('gifs_enabled', '1'),
            'chat_enabled'     => (int)nc_setting('chat_enabled', '1'),
            'games_enabled'    => (int)nc_setting('games_enabled', '1'),
            'max_upload_mb'    => (int)nc_setting('max_upload_mb', '80'),
            'quota_gb'         => (int)nc_setting('ip_quota_gb', '5'),
            'site_name'        => (string)nc_setting('site_name', 'NovaChat'),
        ],
        'announcement'        => (string)nc_setting('announcement', ''),
        'csrf'                => nc_csrf_token(),
        'server_time'         => $now,
    ]);
}

/* ============================================================
   MESAJ GÖNDERME
   ============================================================ */

if ($action === 'send') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    if ((int)nc_setting('chat_enabled', '1') !== 1) {
        nc_fail('Sohbet şu anda yönetici tarafından kapalı.', 403);
    }
    if ((int)$u['muted_until'] > $now) {
        $mins = (int)ceil(((int)$u['muted_until'] - $now) / 60);
        nc_fail('Susturulmuşsun. Kalan süre: ~' . $mins . ' dakika.', 403, ['muted' => true]);
    }
    if (!nc_throttle('msg:' . $u['id'], 20, 60)) {
        nc_fail('Çok hızlı mesaj gönderiyorsun. Biraz yavaşla. 🐢', 429);
    }
    if (!nc_throttle('msg-ip:' . nc_client_ip(), 40, 60)) {
        nc_fail('Bu IP adresinden çok fazla mesaj gönderildi. Biraz bekle.', 429);
    }

    $lastMs = (int)$u['last_msg_at'];
    $cdMs = max(0, min(60000, (int)nc_setting('cooldown_ms', '3000')));
    $nowMs = (int)floor(microtime(true) * 1000);
    if ($lastMs > 0 && $nowMs - $lastMs < $cdMs) {
        nc_fail('Bekleme süresi dolmadı.', 429, ['cooldown_remaining' => $cdMs - ($nowMs - $lastMs)]);
    }

    $body = nc_clean_text((string)($data['body'] ?? ''));
    $body = trim($body);
    $maxLen = max(50, min(2000, (int)nc_setting('msg_max_len', '500')));
    if (mb_strlen($body, 'UTF-8') > $maxLen) {
        nc_fail('Mesaj çok uzun. En fazla ' . $maxLen . ' karakter olabilir.');
    }

    $replyTo = (int)($data['reply_to'] ?? 0);
    if ($replyTo > 0) {
        $chk = nc_db()->prepare('SELECT id FROM nc_messages WHERE id = ? LIMIT 1');
        $chk->execute([$replyTo]);
        if (!$chk->fetchColumn()) {
            $replyTo = 0;
        }
    } else {
        $replyTo = 0;
    }

    $fileId = (int)($data['file_id'] ?? 0);
    $fileRow = null;
    if ($fileId > 0) {
        $chk = nc_db()->prepare('SELECT * FROM nc_files WHERE id = ? AND user_id = ? LIMIT 1');
        $chk->execute([$fileId, (int)$u['id']]);
        $fileRow = $chk->fetch();
        if (!$fileRow) {
            nc_fail('Dosya bulunamadı veya sana ait değil.', 404);
        }
        $used = nc_db()->prepare('SELECT COUNT(*) FROM nc_messages WHERE file_id = ?');
        $used->execute([$fileId]);
        if ((int)$used->fetchColumn() > 0) {
            nc_fail('Bu dosya zaten gönderilmiş.', 409);
        }
    }

    $gifUrl = trim((string)($data['gif_url'] ?? ($data['gif'] ?? '')));
    if ($gifUrl !== '') {
        if ((int)nc_setting('gifs_enabled', '1') !== 1) {
            nc_fail('GIF gönderimi yönetici tarafından kapatılmış.', 403);
        }
        if (!nc_gif_url_valid($gifUrl)) {
            nc_fail('Geçersiz GIF bağlantısı.', 400);
        }
    }

    if ($body === '' && !$fileRow && $gifUrl === '') {
        nc_fail('Boş mesaj gönderilemez.');
    }

    $pdo = nc_db();
    $stmt = $pdo->prepare('INSERT INTO nc_messages (user_id, body, reply_to, file_id, gif_url, created_at) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        (int)$u['id'],
        $body,
        $replyTo > 0 ? $replyTo : null,
        $fileRow ? $fileId : null,
        $gifUrl,
        $now,
    ]);
    $msgId = (int)$pdo->lastInsertId();
    $newMs = (int)floor(microtime(true) * 1000);
    $pdo->prepare('UPDATE nc_users SET last_msg_at = ?, typing_at = 0 WHERE id = ?')->execute([$newMs, (int)$u['id']]);

    $stmt = $pdo->prepare(nc_message_sql() . ' WHERE m.id = ?');
    $stmt->execute([$msgId]);
    $row = $stmt->fetch();

    nc_log('message', 'Mesaj gönderildi', ['message_id' => $msgId], (int)$u['id']);

    nc_json([
        'ok'           => true,
        'message'      => nc_message_view($row),
        'last_msg_at'  => $newMs,
        'cooldown_ms'  => $cdMs,
    ]);
}

/* ============================================================
   YAZIYOR GÖSTERGESİ
   ============================================================ */

if ($action === 'typing') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    if ((int)nc_setting('chat_enabled', '1') === 1 && nc_throttle('typing:' . $u['id'], 1, 1)) {
        nc_db()->prepare('UPDATE nc_users SET typing_at = ? WHERE id = ?')->execute([$now, (int)$u['id']]);
    }
    nc_json(['ok' => true]);
}

/* ============================================================
   DOSYA YÜKLEME
   ============================================================ */

if ($action === 'upload') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    if ((int)nc_setting('uploads_enabled', '1') !== 1) {
        nc_fail('Dosya yükleme yönetici tarafından kapatılmış.', 403);
    }
    if (!nc_throttle('upload:' . $u['id'], 10, 300)) {
        nc_fail('Çok fazla dosya yükledin. 5 dakika sonra tekrar dene.', 429);
    }
    if (!isset($_FILES['file']) || !is_array($_FILES['file'])) {
        nc_fail('Dosya seçilmedi.');
    }
    $file = $_FILES['file'];
    if ((int)$file['error'] !== UPLOAD_ERR_OK) {
        $map = [
            UPLOAD_ERR_INI_SIZE   => 'Dosya PHP limitini (upload_max_filesize) aşıyor.',
            UPLOAD_ERR_FORM_SIZE  => 'Dosya form limitini aşıyor.',
            UPLOAD_ERR_PARTIAL    => 'Dosya yalnızca kısmen yüklendi.',
            UPLOAD_ERR_NO_FILE    => 'Dosya seçilmedi.',
            UPLOAD_ERR_NO_TMP_DIR => 'Sunucuda geçici klasör yok.',
            UPLOAD_ERR_CANT_WRITE => 'Sunucu diske yazamadı.',
            UPLOAD_ERR_EXTENSION  => 'Yükleme bir eklenti tarafından durduruldu.',
        ];
        nc_fail($map[(int)$file['error']] ?? 'Yükleme hatası.', 400);
    }
    $tmp = (string)$file['tmp_name'];
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        nc_fail('Geçersiz yükleme.', 400);
    }
    $size = (int)filesize($tmp);
    $maxBytes = max(1, min(80, (int)nc_setting('max_upload_mb', '80'))) * 1024 * 1024;
    if ($size <= 0) {
        nc_fail('Boş dosya yüklenemez.');
    }
    if ($size > $maxBytes) {
        nc_fail('Dosya çok büyük. En fazla ' . nc_format_bytes($maxBytes) . ' olabilir.', 413);
    }
    $quotaLimit = nc_quota_limit_bytes();
    $quotaUsed = nc_quota_used(nc_client_ip());
    if ($quotaUsed + $size > $quotaLimit) {
        nc_fail(
            'IP dosya kotan doldu. Kullanılan: ' . nc_format_bytes($quotaUsed) . ' / ' . nc_format_bytes($quotaLimit),
            403,
            ['quota_exceeded' => true]
        );
    }

    $orig = (string)($file['name'] ?? 'dosya');
    $orig = str_replace("\0", '', str_replace('\\', '/', $orig));
    $orig = basename($orig);
    $orig = trim(nc_clean_text($orig));
    if ($orig === '' || $orig === '.' || $orig === '..') {
        $orig = 'dosya';
    }
    if (mb_strlen($orig) > 170) {
        $orig = mb_substr($orig, 0, 170);
    }
    $ext = strtolower((string)pathinfo($orig, PATHINFO_EXTENSION));

    $allowed = [
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'gif'  => ['image/gif'],
        'webp' => ['image/webp'],
        'mp4'  => ['video/mp4'],
        'webm' => ['video/webm', 'audio/webm'],
        'mov'  => ['video/quicktime'],
        'mp3'  => ['audio/mpeg'],
        'ogg'  => ['audio/ogg'],
        'wav'  => ['audio/wav', 'audio/x-wav'],
        'm4a'  => ['audio/mp4', 'audio/x-m4a'],
        'pdf'  => ['application/pdf'],
        'zip'  => ['application/zip', 'application/x-zip-compressed'],
        'rar'  => ['application/vnd.rar', 'application/x-rar-compressed'],
        '7z'   => ['application/x-7z-compressed'],
        'txt'  => ['text/plain'],
        'doc'  => ['application/msword'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'xls'  => ['application/vnd.ms-excel'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        'ppt'  => ['application/vnd.ms-powerpoint'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation'],
    ];
    if (!isset($allowed[$ext])) {
        nc_fail('Bu dosya türüne izin verilmiyor. İzinli türler: resim, video, ses, pdf, ofis belgesi, txt, zip/rar/7z.', 415);
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $detected = strtolower(trim(explode(';', (string)$finfo->file($tmp))[0]));
    if (!in_array($detected, $allowed[$ext], true)) {
        nc_fail('Dosya içeriği uzantısıyla uyuşmuyor. (' . $detected . ')', 415);
    }
    if (strpos($detected, 'html') !== false || strpos($detected, 'svg') !== false) {
        nc_fail('Bu içerik türüne izin verilmiyor.', 415);
    }

    $stored = bin2hex(random_bytes(20)) . '.dat';
    $dest = NC_ROOT . '/uploads/' . $stored;
    if (!move_uploaded_file($tmp, $dest)) {
        nc_fail('Dosya kaydedilemedi.', 500);
    }
    @chmod($dest, 0640);

    $pdo = nc_db();
    try {
        $stmt = $pdo->prepare('INSERT INTO nc_files (user_id, ip, orig_name, stored_name, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([(int)$u['id'], nc_client_ip(), $orig, $stored, $detected, $size, $now]);
        $fileId = (int)$pdo->lastInsertId();
    } catch (Throwable $e) {
        @unlink($dest);
        nc_fail('Dosya kaydı oluşturulamadı. Lütfen tekrar dene.', 500);
    }

    nc_log('file_upload', 'Dosya yüklendi', ['name' => $orig, 'size' => $size, 'file_id' => $fileId], (int)$u['id']);

    nc_json([
        'ok'    => true,
        'file'  => [
            'id'       => $fileId,
            'name'     => $orig,
            'size'     => $size,
            'size_txt' => nc_format_bytes((float)$size),
            'is_image' => (bool)preg_match('#^image/(jpeg|png|gif|webp)$#', $detected),
            'is_video' => (bool)preg_match('#^video/(mp4|webm|quicktime)$#', $detected),
            'is_audio' => (bool)preg_match('#^audio/(mpeg|ogg|wav|x-wav|mp4|x-m4a)$#', $detected),
        ],
        'quota_used'  => nc_quota_used(nc_client_ip()),
        'quota_limit' => $quotaLimit,
    ]);
}

if ($action === 'cancel_file') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    $fileId = (int)($data['file_id'] ?? 0);
    $stmt = nc_db()->prepare('SELECT * FROM nc_files WHERE id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$fileId, (int)$u['id']]);
    $row = $stmt->fetch();
    if (!$row) {
        nc_fail('Dosya bulunamadı.', 404);
    }
    $used = nc_db()->prepare('SELECT COUNT(*) FROM nc_messages WHERE file_id = ?');
    $used->execute([$fileId]);
    if ((int)$used->fetchColumn() > 0) {
        nc_fail('Gönderilmiş dosya iptal edilemez.', 409);
    }
    $path = NC_ROOT . '/uploads/' . $row['stored_name'];
    if (is_file($path)) {
        @unlink($path);
    }
    nc_db()->prepare('DELETE FROM nc_files WHERE id = ?')->execute([$fileId]);
    nc_json(['ok' => true, 'quota_used' => nc_quota_used(nc_client_ip())]);
}

/* ============================================================
   DOSYA SUNMA (yetki kontrollü, asla doğrudan erişim yok)
   ============================================================ */

if ($action === 'file') {
    $u = nc_require_user();
    $fileId = (int)($data['id'] ?? ($_GET['id'] ?? 0));
    if ($fileId <= 0) {
        http_response_code(404);
        exit;
    }
    $stmt = nc_db()->prepare('SELECT * FROM nc_files WHERE id = ? LIMIT 1');
    $stmt->execute([$fileId]);
    $row = $stmt->fetch();
    if (!$row) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Dosya bulunamadı.';
        exit;
    }
    $path = NC_ROOT . '/uploads/' . (string)$row['stored_name'];
    if (!is_file($path)) {
        http_response_code(410);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Dosya silinmiş.';
        exit;
    }
    $mime = (string)$row['mime'];
    if (!preg_match('#^[a-z0-9][a-z0-9.+-]*/[a-z0-9][a-z0-9.+-]*$#i', $mime)) {
        $mime = 'application/octet-stream';
    }
    $inline = (bool)preg_match('#^(image/(jpeg|png|gif|webp)|video/(mp4|webm|quicktime)|audio/(mpeg|ogg|wav|x-wav|mp4|x-m4a))$#', $mime);
    $name = (string)$row['orig_name'];
    $ascii = preg_replace('/[^A-Za-z0-9._-]/', '_', $name) ?: 'dosya';
    if (!headers_sent()) {
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string)filesize($path));
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $ascii . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('X-Content-Type-Options: nosniff');
        header('Content-Security-Policy: sandbox; default-src \'none\'; img-src \'self\'; media-src \'self\'');
        header('Cache-Control: private, max-age=86400');
        header('Referrer-Policy: no-referrer');
    }
    readfile($path);
    exit;
}

/* ============================================================
   GIF LİSTESİ
   ============================================================ */

if ($action === 'gif_search') {
    $u = nc_require_user();
    if ((int)nc_setting('gifs_enabled', '1') !== 1) {
        nc_fail('GIF arama yönetici tarafından kapatılmış.', 403);
    }
    if (!nc_throttle('gif:' . $u['id'], 40, 60)) {
        nc_fail('Çok fazla GIF araması yaptın. Biraz bekle.', 429);
    }
    $q = trim((string)($data['q'] ?? ($_GET['q'] ?? '')));
    $q = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $q) ?? '';
    $q = trim(preg_replace('/\s+/u', ' ', $q) ?? '');
    if (mb_strlen($q) > 40) {
        $q = mb_substr($q, 0, 40);
    }
    $result = nc_tenor_search($q, 30);
    if (empty($result['ok'])) {
        nc_fail($result['error'] ?? 'GIF araması başarısız.', 503);
    }
    nc_json([
        'ok'     => true,
        'items'  => $result['items'],
        'query'  => $result['query'],
        'cached' => !empty($result['cached']),
    ]);
}

/* ============================================================
   OYUN (SUNUCU TARAFI)
   ============================================================ */

if ($action === 'game_get') {
    $u = nc_require_user();
    if ((int)nc_setting('games_enabled', '1') !== 1) {
        nc_fail('Oyunlar yönetici tarafından kapatılmış.', 403, ['games_disabled' => true]);
    }
    nc_touch_user((int)$u['id']);
    $pdo = nc_db();
    $row = nc_game_get((int)$u['id']);
    $away = max(0, $now - (int)$row['last_tick']);
    $tick = nc_game_apply_ticks($row);
    nc_game_save($row);
    $awayGain = $away > 60 ? nc_num($tick['gain']) : 0.0;
    nc_json(array_merge(['ok' => true], nc_game_payload((int)$u['id'], $row, $away, $awayGain)));
}

if ($action === 'game_click') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    if ((int)nc_setting('games_enabled', '1') !== 1) {
        nc_fail('Oyunlar kapalı.', 403);
    }
    $n = (int)($data['n'] ?? 1);
    $n = max(1, min(200, $n));
    $pdo = nc_db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT * FROM nc_game WHERE user_id = ? FOR UPDATE');
        $stmt->execute([(int)$u['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            $pdo->commit();
            $row = nc_game_get((int)$u['id']);
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('SELECT * FROM nc_game WHERE user_id = ? FOR UPDATE');
            $stmt->execute([(int)$u['id']]);
            $row = $stmt->fetch();
        }
        $tick = nc_game_apply_ticks($row);

        $rate = max(1, min(50, (int)nc_setting('click_rate', '20')));
        $cap = $rate * 2;
        $nowF = microtime(true);
        $row['tokens'] = min($cap, (float)$row['tokens'] + max(0.0, $nowF - (float)$row['tokens_at']) * $rate);
        $row['tokens_at'] = $nowF;

        $available = (int)floor((float)$row['tokens']);
        if ($available < 1) {
            $pdo->rollBack();
            nc_fail('Çok hızlı tıklıyorsun! Kısa bir an bekle. ⏳', 429, ['tokens' => 0]);
        }
        $n = min($n, $available);
        $power = nc_game_click_power((int)$row['click_level']);
        $gain = $power * $n;
        $row['cookies'] = nc_num((float)$row['cookies'] + $gain);
        $row['total_earned'] = nc_num((float)$row['total_earned'] + $gain);
        $row['clicks'] = (int)$row['clicks'] + $n;
        $row['tokens'] = max(0.0, (float)$row['tokens'] - $n);
        nc_game_save($row);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        nc_fail('Tıklama işlenemedi.', 500);
    }

    nc_json([
        'ok'           => true,
        'gain'         => $gain,
        'count'        => $n,
        'cookies'      => nc_num((float)$row['cookies']),
        'total_earned' => nc_num((float)$row['total_earned']),
        'clicks'       => (int)$row['clicks'],
        'tokens'       => (int)floor((float)$row['tokens']),
        'click_power'  => $power,
        'cps'          => nc_game_cps($row),
        'tick_gain'    => nc_num($tick['gain']),
    ]);
}

if ($action === 'game_buy') {
    if ($method !== 'POST') {
        nc_fail('Geçersiz istek.', 405);
    }
    $u = nc_require_user();
    if ((int)nc_setting('games_enabled', '1') !== 1) {
        nc_fail('Oyunlar kapalı.', 403);
    }
    $kind = (string)($data['kind'] ?? '');
    $buildingId = (int)($data['id'] ?? 0);
    $amount = (int)($data['amount'] ?? 1);
    $amount = in_array($amount, [1, 10, 100], true) ? $amount : 1;

    $pdo = nc_db();
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare('SELECT * FROM nc_game WHERE user_id = ? FOR UPDATE');
        $stmt->execute([(int)$u['id']]);
        $row = $stmt->fetch();
        if (!$row) {
            $pdo->rollBack();
            nc_fail('Oyun verisi bulunamadı.', 409);
        }
        nc_game_apply_ticks($row);
        $counts = nc_game_counts($row['buildings']);

        if ($kind === 'click') {
            $level = max(1, (int)$row['click_level']);
            $cost = nc_num(nc_game_click_cost($level));
            if ((float)$row['cookies'] < $cost) {
                $pdo->rollBack();
                nc_fail('Yetersiz kurabiye.', 409, ['need' => $cost]);
            }
            $row['cookies'] = nc_num((float)$row['cookies'] - $cost);
            $row['click_level'] = $level + 1;
        } elseif ($kind === 'building') {
            $defs = nc_game_buildings_def();
            if (!isset($defs[$buildingId])) {
                $pdo->rollBack();
                nc_fail('Geçersiz bina.', 400);
            }
            $owned = $counts[$buildingId] ?? 0;
            $cost = nc_num(nc_game_bulk_cost($buildingId, $owned, $amount));
            if ((float)$row['cookies'] < $cost) {
                $pdo->rollBack();
                nc_fail('Yetersiz kurabiye.', 409, ['need' => $cost]);
            }
            $row['cookies'] = nc_num((float)$row['cookies'] - $cost);
            $counts[$buildingId] = $owned + $amount;
            $row['buildings'] = json_encode($counts);
        } else {
            $pdo->rollBack();
            nc_fail('Geçersiz satın alma.', 400);
        }

        nc_game_save($row);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        nc_fail('Satın alma işlenemedi.', 500);
    }

    nc_log('game_buy', 'Oyun içi satın alma', ['kind' => $kind, 'id' => $buildingId, 'amount' => $amount], (int)$u['id']);
    nc_json(array_merge(['ok' => true], nc_game_payload((int)$u['id'], $row)));
}

if ($action === 'game_lb') {
    nc_require_user();
    $u = nc_user();
    $row = nc_game_get((int)$u['id']);
    nc_json([
        'ok'          => true,
        'leaderboard' => nc_game_leaderboard(50),
        'rank'        => nc_game_rank((int)$u['id'], (float)$row['total_earned']),
        'score'       => nc_num((float)$row['total_earned']),
    ]);
}

/* ============================================================
   ADMIN API
   ============================================================ */

if (strpos($action, 'admin_') === 0) {
    nc_require_admin();

    if ($action === 'admin_stats') {
        $pdo = nc_db();
        $todayStart = (int)strtotime('today');
        $usersTotal = (int)$pdo->query('SELECT COUNT(*) FROM nc_users')->fetchColumn();
        $online = (int)$pdo->query('SELECT COUNT(*) FROM nc_users WHERE last_seen >= ' . ($now - 70) . ' AND is_banned = 0')->fetchColumn();
        $messages = (int)$pdo->query('SELECT COUNT(*) FROM nc_messages WHERE deleted = 0')->fetchColumn();
        $messagesToday = (int)$pdo->query('SELECT COUNT(*) FROM nc_messages WHERE created_at >= ' . $todayStart)->fetchColumn();
        $files = (int)$pdo->query('SELECT COUNT(*) FROM nc_files')->fetchColumn();
        $storage = (int)$pdo->query('SELECT COALESCE(SUM(size), 0) FROM nc_files')->fetchColumn();
        $banned = (int)$pdo->query('SELECT COUNT(*) FROM nc_users WHERE is_banned = 1')->fetchColumn();
        $ipbans = (int)$pdo->query('SELECT COUNT(*) FROM nc_ip_bans WHERE expires = 0 OR expires > ' . $now)->fetchColumn();
        $players = (int)$pdo->query('SELECT COUNT(*) FROM nc_game')->fetchColumn();
        $totalEarned = (float)$pdo->query('SELECT COALESCE(SUM(total_earned), 0) FROM nc_game')->fetchColumn();

        $logs = $pdo->query('SELECT l.*, u.username FROM nc_logs l LEFT JOIN nc_users u ON u.id = l.user_id ORDER BY l.id DESC LIMIT 12')->fetchAll();
        $recentLogs = [];
        foreach ($logs as $l) {
            $recentLogs[] = [
                'id'       => (int)$l['id'],
                'type'     => (string)$l['type'],
                'data'     => (string)$l['data'],
                'username' => $l['username'],
                'ip'       => (string)$l['ip'],
                'ts'       => (int)$l['created_at'],
            ];
        }

        nc_json([
            'ok' => true,
            'stats' => [
                'users'          => $usersTotal,
                'online'         => $online,
                'messages'       => $messages,
                'messages_today' => $messagesToday,
                'files'          => $files,
                'storage'        => $storage,
                'banned'         => $banned,
                'ipbans'         => $ipbans,
                'players'        => $players,
                'total_earned'   => nc_num($totalEarned),
            ],
            'settings' => nc_settings(),
            'logs'     => $recentLogs,
            'top'      => nc_game_leaderboard(5),
            'server'   => [
                'php'        => PHP_VERSION,
                'software'   => (string)($_SERVER['SERVER_SOFTWARE'] ?? ''),
                'upload_max' => (string)ini_get('upload_max_filesize'),
                'post_max'   => (string)ini_get('post_max_size'),
                'config_writable' => is_writable(NC_ROOT . '/config.php'),
                'db'         => (string)$GLOBALS['NC_CONFIG']['db']['name'],
                'session_until' => (int)($_SESSION['admin_at'] ?? 0) + 7200,
            ],
        ]);
    }

    if ($action === 'admin_users') {
        $q = trim((string)($data['q'] ?? ''));
        $page = max(1, (int)($data['page'] ?? 1));
        $per = 20;
        $offset = ($page - 1) * $per;
        $where = '';
        $params = [];
        if ($q !== '' && mb_strlen($q) <= 30) {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $where = 'WHERE (u.username LIKE ? OR u.ip LIKE ?)';
            $params = [$like, $like];
        }
        $pdo = nc_db();
        $countStmt = $pdo->prepare('SELECT COUNT(*) FROM nc_users u ' . $where);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = 'SELECT u.id, u.username, u.ip, u.is_banned, u.ban_reason, u.muted_until, u.created_at, u.last_seen,
                       (SELECT COUNT(*) FROM nc_messages m WHERE m.user_id = u.id AND m.deleted = 0) AS msg_count,
                       (SELECT COALESCE(SUM(f.size), 0) FROM nc_files f WHERE f.user_id = u.id) AS up_bytes,
                       g.cookies, g.total_earned, g.clicks, g.click_level
                FROM nc_users u LEFT JOIN nc_game g ON g.user_id = u.id
                ' . $where . ' ORDER BY u.last_seen DESC LIMIT ' . $per . ' OFFSET ' . $offset;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = [];
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = [
                'id'          => (int)$r['id'],
                'username'    => (string)$r['username'],
                'ip'          => (string)$r['ip'],
                'is_banned'   => (int)$r['is_banned'] === 1,
                'ban_reason'  => (string)$r['ban_reason'],
                'muted_until' => (int)$r['muted_until'],
                'created_at'  => (int)$r['created_at'],
                'last_seen'   => (int)$r['last_seen'],
                'online'      => (int)$r['last_seen'] >= $now - 70,
                'msg_count'   => (int)$r['msg_count'],
                'up_bytes'    => (int)$r['up_bytes'],
                'cookies'     => nc_num((float)$r['cookies']),
                'total_earned'=> nc_num((float)$r['total_earned']),
                'clicks'      => (int)$r['clicks'],
                'click_level' => (int)$r['click_level'],
            ];
        }
        nc_json(['ok' => true, 'users' => $rows, 'total' => $total, 'page' => $page, 'pages' => max(1, (int)ceil($total / $per))]);
    }

    if ($action === 'admin_user_action') {
        $uid = (int)($data['uid'] ?? 0);
        $op = (string)($data['op'] ?? '');
        $reason = mb_substr(nc_clean_text((string)($data['reason'] ?? '')), 0, 200);
        $minutes = max(1, min(525600, (int)($data['minutes'] ?? 10)));
        $pdo = nc_db();
        $stmt = $pdo->prepare('SELECT * FROM nc_users WHERE id = ? LIMIT 1');
        $stmt->execute([$uid]);
        $target = $stmt->fetch();
        if (!$target) {
            nc_fail('Kullanıcı bulunamadı.', 404);
        }
        $targetName = (string)$target['username'];

        switch ($op) {
            case 'ban':
                $pdo->prepare('UPDATE nc_users SET is_banned = 1, ban_reason = ?, remember_selector = ?, remember_hash = ?, remember_expires = 0 WHERE id = ?')
                    ->execute([$reason, '', '', $uid]);
                nc_log('admin_ban', 'Kullanıcı banlandı: ' . $targetName . ($reason !== '' ? ' (' . $reason . ')' : ''), [], $uid);
                break;
            case 'unban':
                $pdo->prepare('UPDATE nc_users SET is_banned = 0, ban_reason = ? WHERE id = ?')->execute(['', $uid]);
                nc_log('admin_unban', 'Ban kaldırıldı: ' . $targetName, [], $uid);
                break;
            case 'mute':
                $until = $now + $minutes * 60;
                $pdo->prepare('UPDATE nc_users SET muted_until = ? WHERE id = ?')->execute([$until, $uid]);
                nc_log('admin_mute', 'Kullanıcı susturuldu: ' . $targetName . ' (' . $minutes . ' dk)', [], $uid);
                break;
            case 'unmute':
                $pdo->prepare('UPDATE nc_users SET muted_until = 0 WHERE id = ?')->execute([$uid]);
                nc_log('admin_unmute', 'Susturma kaldırıldı: ' . $targetName, [], $uid);
                break;
            case 'setip':
                $newIp = trim((string)($data['ip'] ?? ''));
                if (!filter_var($newIp, FILTER_VALIDATE_IP)) {
                    nc_fail('Geçersiz IP adresi.', 400);
                }
                $pdo->prepare('UPDATE nc_users SET ip = ? WHERE id = ?')->execute([$newIp, $uid]);
                nc_log('admin_setip', 'Kullanıcı IP güncellendi: ' . $targetName . ' -> ' . $newIp, ['old' => $target['ip']], $uid);
                break;
            case 'delete':
                $pdo->beginTransaction();
                try {
                    $stmtF = $pdo->prepare('SELECT stored_name FROM nc_files WHERE user_id = ?');
                    $stmtF->execute([$uid]);
                    foreach ($stmtF->fetchAll(PDO::FETCH_COLUMN) as $stored) {
                        $p = NC_ROOT . '/uploads/' . basename((string)$stored);
                        if (is_file($p)) {
                            @unlink($p);
                        }
                    }
                    $pdo->prepare('DELETE FROM nc_files WHERE user_id = ?')->execute([$uid]);
                    $pdo->prepare('UPDATE nc_messages SET deleted = 1, deleted_at = ? WHERE user_id = ? AND deleted = 0')->execute([$now, $uid]);
                    $pdo->prepare('DELETE FROM nc_game WHERE user_id = ?')->execute([$uid]);
                    $pdo->prepare('DELETE FROM nc_users WHERE id = ?')->execute([$uid]);
                    $pdo->commit();
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    nc_fail('Kullanıcı silinemedi.', 500);
                }
                nc_log('admin_user_delete', 'Kullanıcı silindi: ' . $targetName . ' (IP: ' . $target['ip'] . ')');
                break;
            case 'resetgame':
                $pdo->prepare('DELETE FROM nc_game WHERE user_id = ?')->execute([$uid]);
                nc_log('admin_game_reset', 'Oyun verisi sıfırlandı: ' . $targetName, [], $uid);
                break;
            default:
                nc_fail('Bilinmeyen işlem.', 400);
        }
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_messages') {
        $q = trim((string)($data['q'] ?? ''));
        $filter = (string)($data['filter'] ?? 'all');
        $page = max(1, (int)($data['page'] ?? 1));
        $per = 25;
        $offset = ($page - 1) * $per;
        $conds = [];
        $params = [];
        if ($filter === 'deleted') {
            $conds[] = 'm.deleted = 1';
        } elseif ($filter === 'active') {
            $conds[] = 'm.deleted = 0';
        }
        if ($q !== '' && mb_strlen($q) <= 50) {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $conds[] = '(m.body LIKE ? OR u.username LIKE ?)';
            $params[] = $like;
            $params[] = $like;
        }
        $where = $conds ? ('WHERE ' . implode(' AND ', $conds)) : '';
        $pdo = nc_db();
        $countStmt = $pdo->prepare('SELECT COUNT(*) FROM nc_messages m LEFT JOIN nc_users u ON u.id = m.user_id ' . $where);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();
        $sql = 'SELECT m.id, m.body, m.deleted, m.created_at, m.gif_url, m.user_id,
                       u.username, u.ip AS user_ip,
                       f.orig_name AS file_name, f.size AS file_size
                FROM nc_messages m
                LEFT JOIN nc_users u ON u.id = m.user_id
                LEFT JOIN nc_files f ON f.id = m.file_id
                ' . $where . ' ORDER BY m.id DESC LIMIT ' . $per . ' OFFSET ' . $offset;
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = [];
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = [
                'id'         => (int)$r['id'],
                'body'       => (string)$r['body'],
                'deleted'    => (int)$r['deleted'] === 1,
                'ts'         => (int)$r['created_at'],
                'gif'        => (string)$r['gif_url'] !== '' ? 'tenor' : '',
                'username'   => $r['username'] !== null ? (string)$r['username'] : null,
                'user_id'    => (int)$r['user_id'],
                'ip'         => (string)($r['user_ip'] ?? ''),
                'file_name'  => $r['file_name'] !== null ? (string)$r['file_name'] : null,
                'file_size'  => (int)($r['file_size'] ?? 0),
            ];
        }
        nc_json(['ok' => true, 'messages' => $rows, 'total' => $total, 'page' => $page, 'pages' => max(1, (int)ceil($total / $per))]);
    }

    if ($action === 'admin_msg_action') {
        $id = (int)($data['id'] ?? 0);
        $op = (string)($data['op'] ?? '');
        $stmt = nc_db()->prepare('SELECT id FROM nc_messages WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        if (!$stmt->fetchColumn()) {
            nc_fail('Mesaj bulunamadı.', 404);
        }
        if ($op === 'delete') {
            nc_db()->prepare('UPDATE nc_messages SET deleted = 1, deleted_at = ? WHERE id = ?')->execute([$now, $id]);
            nc_log('admin_msg_delete', 'Mesaj silindi', ['message_id' => $id]);
        } elseif ($op === 'restore') {
            nc_db()->prepare('UPDATE nc_messages SET deleted = 0, deleted_at = 0 WHERE id = ?')->execute([$id]);
            nc_log('admin_msg_restore', 'Mesaj geri getirildi', ['message_id' => $id]);
        } else {
            nc_fail('Bilinmeyen işlem.', 400);
        }
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_chat_clear') {
        nc_db()->prepare('UPDATE nc_messages SET deleted = 1, deleted_at = ? WHERE deleted = 0')->execute([$now]);
        nc_log('admin_chat_clear', 'Tüm sohbet mesajları silindi');
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_files') {
        $page = max(1, (int)($data['page'] ?? 1));
        $per = 25;
        $offset = ($page - 1) * $per;
        $pdo = nc_db();
        $total = (int)$pdo->query('SELECT COUNT(*) FROM nc_files')->fetchColumn();
        $stmt = $pdo->query('SELECT f.*, u.username FROM nc_files f LEFT JOIN nc_users u ON u.id = f.user_id ORDER BY f.id DESC LIMIT ' . $per . ' OFFSET ' . $offset);
        $rows = [];
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = [
                'id'       => (int)$r['id'],
                'name'     => (string)$r['orig_name'],
                'mime'     => (string)$r['mime'],
                'size'     => (int)$r['size'],
                'size_txt' => nc_format_bytes((float)$r['size']),
                'ip'       => (string)$r['ip'],
                'username' => $r['username'],
                'ts'       => (int)$r['created_at'],
            ];
        }
        $ipRows = $pdo->query('SELECT ip, COUNT(*) AS c, COALESCE(SUM(size), 0) AS s FROM nc_files GROUP BY ip ORDER BY s DESC LIMIT 30')->fetchAll();
        $quotaLimit = nc_quota_limit_bytes();
        $perIp = [];
        foreach ($ipRows as $r) {
            $perIp[] = [
                'ip'        => (string)$r['ip'],
                'count'     => (int)$r['c'],
                'bytes'     => (int)$r['s'],
                'bytes_txt' => nc_format_bytes((float)$r['s']),
                'percent'   => $quotaLimit > 0 ? min(100, round(((int)$r['s'] / $quotaLimit) * 100, 1)) : 0,
            ];
        }
        nc_json(['ok' => true, 'files' => $rows, 'per_ip' => $perIp, 'total' => $total, 'page' => $page, 'pages' => max(1, (int)ceil($total / $per))]);
    }

    if ($action === 'admin_file_delete') {
        $id = (int)($data['id'] ?? 0);
        $stmt = nc_db()->prepare('SELECT stored_name, orig_name FROM nc_files WHERE id = ? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if (!$row) {
            nc_fail('Dosya bulunamadı.', 404);
        }
        nc_db()->prepare('UPDATE nc_messages SET file_id = NULL WHERE file_id = ?')->execute([$id]);
        nc_db()->prepare('DELETE FROM nc_files WHERE id = ?')->execute([$id]);
        $p = NC_ROOT . '/uploads/' . basename((string)$row['stored_name']);
        if (is_file($p)) {
            @unlink($p);
        }
        nc_log('admin_file_delete', 'Dosya silindi: ' . $row['orig_name'], ['file_id' => $id]);
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_ipbans') {
        $rows = [];
        foreach (nc_db()->query('SELECT * FROM nc_ip_bans ORDER BY created_at DESC LIMIT 200')->fetchAll() as $r) {
            $rows[] = [
                'id'       => (int)$r['id'],
                'ip'       => (string)$r['ip'],
                'reason'   => (string)$r['reason'],
                'created_at' => (int)$r['created_at'],
                'expires'  => (int)$r['expires'],
                'active'   => (int)$r['expires'] === 0 || (int)$r['expires'] > $now,
            ];
        }
        // Aktif IP'leri temizle (süresi geçmiş)
        nc_db()->prepare('DELETE FROM nc_ip_bans WHERE expires > 0 AND expires <= ?')->execute([$now]);
        nc_json(['ok' => true, 'bans' => $rows]);
    }

    if ($action === 'admin_ipban') {
        $ip = trim((string)($data['ip'] ?? ''));
        $reason = mb_substr(nc_clean_text((string)($data['reason'] ?? '')), 0, 200);
        $minutes = max(0, min(525600, (int)($data['minutes'] ?? 0)));
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            nc_fail('Geçersiz IP adresi.', 400);
        }
        $expires = $minutes > 0 ? $now + $minutes * 60 : 0;
        nc_db()->prepare('INSERT INTO nc_ip_bans (ip, reason, created_at, expires) VALUES (?, ?, ?, ?)
                          ON DUPLICATE KEY UPDATE reason = VALUES(reason), created_at = VALUES(created_at), expires = VALUES(expires)')
            ->execute([$ip, $reason, $now, $expires]);
        nc_log('admin_ipban', 'IP banlandı: ' . $ip . ($reason !== '' ? ' (' . $reason . ')' : ''), ['minutes' => $minutes]);
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_ipunban') {
        $id = (int)($data['id'] ?? 0);
        $stmt = nc_db()->prepare('SELECT ip FROM nc_ip_bans WHERE id = ?');
        $stmt->execute([$id]);
        $ip = $stmt->fetchColumn();
        if ($ip === false) {
            nc_fail('Kayıt bulunamadı.', 404);
        }
        nc_db()->prepare('DELETE FROM nc_ip_bans WHERE id = ?')->execute([$id]);
        nc_log('admin_ipunban', 'IP banı kaldırıldı: ' . $ip);
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_game') {
        $sqlText = 'SELECT u.id, u.username, u.ip, u.is_banned, COALESCE(g.cookies,0) AS cookies, COALESCE(g.total_earned,0) AS total_earned,
                       COALESCE(g.clicks,0) AS clicks, COALESCE(g.click_level,1) AS click_level, g.last_tick
                FROM nc_users u LEFT JOIN nc_game g ON g.user_id = u.id
                ORDER BY COALESCE(g.total_earned,0) DESC, u.id ASC LIMIT 100';
        $rows = [];
        foreach (nc_db()->query($sqlText)->fetchAll() as $r) {
            $rows[] = [
                'id'           => (int)$r['id'],
                'username'     => (string)$r['username'],
                'ip'           => (string)$r['ip'],
                'is_banned'    => (int)$r['is_banned'] === 1,
                'cookies'      => nc_num((float)$r['cookies']),
                'total_earned' => nc_num((float)$r['total_earned']),
                'clicks'       => (int)$r['clicks'],
                'click_level'  => (int)$r['click_level'],
                'last_tick'    => (int)($r['last_tick'] ?? 0),
            ];
        }
        nc_json(['ok' => true, 'game' => $rows, 'settings' => ['click_rate' => (int)nc_setting('click_rate', '20'), 'cps_multiplier' => (int)nc_setting('cps_multiplier', '100')]]);
    }

    if ($action === 'admin_game_reset') {
        $uid = (int)($data['uid'] ?? 0);
        if ($uid > 0) {
            nc_db()->prepare('DELETE FROM nc_game WHERE user_id = ?')->execute([$uid]);
            nc_log('admin_game_reset', 'Oyun verisi sıfırlandı', ['user_id' => $uid]);
        } elseif ((string)($data['all'] ?? '') === '1') {
            nc_db()->exec('DELETE FROM nc_game');
            nc_log('admin_game_reset_all', 'TÜM oyun verileri sıfırlandı');
        } else {
            nc_fail('Hedef belirtilmedi.', 400);
        }
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_logs') {
        $type = trim((string)($data['type'] ?? ''));
        $page = max(1, (int)($data['page'] ?? 1));
        $per = 30;
        $offset = ($page - 1) * $per;
        $where = '';
        $params = [];
        if ($type !== '' && preg_match('/^[a-z0-9_]{1,30}$/', $type)) {
            $where = 'WHERE l.type = ?';
            $params[] = $type;
        }
        $pdo = nc_db();
        $countStmt = $pdo->prepare('SELECT COUNT(*) FROM nc_logs l ' . $where);
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();
        $stmt = $pdo->prepare('SELECT l.*, u.username FROM nc_logs l LEFT JOIN nc_users u ON u.id = l.user_id ' . $where . ' ORDER BY l.id DESC LIMIT ' . $per . ' OFFSET ' . $offset);
        $stmt->execute($params);
        $rows = [];
        foreach ($stmt->fetchAll() as $r) {
            $rows[] = [
                'id'       => (int)$r['id'],
                'type'     => (string)$r['type'],
                'data'     => (string)$r['data'],
                'username' => $r['username'],
                'user_id'  => (int)($r['user_id'] ?? 0),
                'ip'       => (string)$r['ip'],
                'ts'       => (int)$r['created_at'],
            ];
        }
        $types = $pdo->query('SELECT DISTINCT type FROM nc_logs ORDER BY type ASC')->fetchAll(PDO::FETCH_COLUMN);
        nc_json(['ok' => true, 'logs' => $rows, 'types' => $types, 'total' => $total, 'page' => $page, 'pages' => max(1, (int)ceil($total / $per))]);
    }

    if ($action === 'admin_logs_clear') {
        $days = max(1, min(3650, (int)($data['days'] ?? 30)));
        $cut = $now - $days * 86400;
        $stmt = nc_db()->prepare('DELETE FROM nc_logs WHERE created_at < ?');
        $stmt->execute([$cut]);
        $deleted = $stmt->rowCount();
        nc_log('admin_logs_clear', 'Eski loglar temizlendi', ['days' => $days, 'deleted' => $deleted]);
        nc_json(['ok' => true, 'deleted' => $deleted]);
    }

    if ($action === 'admin_settings_save') {
        $in = $data['settings'] ?? null;
        if (!is_array($in)) {
            nc_fail('Ayarlar eksik.', 400);
        }
        $allowed = ['site_name', 'chat_enabled', 'uploads_enabled', 'gifs_enabled', 'games_enabled', 'maintenance',
                    'cooldown_ms', 'max_upload_mb', 'ip_quota_gb', 'msg_max_len', 'announcement', 'click_rate', 'cps_multiplier'];
        $saved = [];
        foreach ($allowed as $key) {
            if (!array_key_exists($key, $in)) {
                continue;
            }
            $val = $in[$key];
            if (is_bool($val)) {
                $val = $val ? '1' : '0';
            }
            $val = (string)$val;
            switch ($key) {
                case 'site_name':
                    $val = mb_substr(trim(nc_clean_text($val)), 0, 30);
                    if ($val === '') {
                        $val = 'NovaChat';
                    }
                    break;
                case 'announcement':
                    $val = mb_substr(trim(nc_clean_text($val)), 0, 300);
                    break;
                case 'chat_enabled':
                case 'uploads_enabled':
                case 'gifs_enabled':
                case 'games_enabled':
                case 'maintenance':
                    $val = $val === '1' ? '1' : '0';
                    break;
                case 'cooldown_ms':
                    $val = (string)max(0, min(60000, (int)$val));
                    break;
                case 'max_upload_mb':
                    $val = (string)max(1, min(80, (int)$val));
                    break;
                case 'ip_quota_gb':
                    $val = (string)max(1, min(100, (int)$val));
                    break;
                case 'msg_max_len':
                    $val = (string)max(50, min(2000, (int)$val));
                    break;
                case 'click_rate':
                    $val = (string)max(1, min(50, (int)$val));
                    break;
                case 'cps_multiplier':
                    $val = (string)max(10, min(1000, (int)$val));
                    break;
            }
            nc_set_setting($key, $val);
            $saved[$key] = $val;
        }
        nc_log('admin_settings', 'Ayarlar güncellendi', $saved);
        nc_json(['ok' => true, 'settings' => nc_settings()]);
    }

    if ($action === 'admin_password') {
        $current = (string)($data['current'] ?? '');
        $new = (string)($data['new'] ?? '');
        if (!nc_verify_admin_pass($current)) {
            nc_fail('Mevcut şifre yanlış.', 403);
        }
        if (mb_strlen($new) < 6 || mb_strlen($new) > 100) {
            nc_fail('Yeni şifre 6-100 karakter olmalı.');
        }
        if ($new === $current) {
            nc_fail('Yeni şifre eskisinden farklı olmalı.');
        }
        if (!nc_set_admin_password($new)) {
            nc_fail('config.php yazılamadı. Dosya izinlerini kontrol et (yazılabilir olmalı).', 500);
        }
        nc_log('admin_password', 'Admin şifresi değiştirildi');
        nc_json(['ok' => true]);
    }

    if ($action === 'admin_logout') {
        unset($_SESSION['is_admin'], $_SESSION['admin_at']);
        nc_log('admin_logout', 'Admin çıkışı yaptı');
        nc_json(['ok' => true]);
    }

    nc_fail('Bilinmeyen admin işlemi.', 400);
}

nc_fail('Bilinmeyen işlem.', 400);
