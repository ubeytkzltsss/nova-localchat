<?php
/**
 * NovaChat - Gizli yönetim paneli
 * Adres: /adminlol.php   (site içinde hiçbir linki yoktur)
 *
 * Varsayılan şifre: 123321
 * Değiştirmek için: panel -> Güvenlik sekmesi (config.php otomatik güncellenir)
 */
declare(strict_types=1);

require __DIR__ . '/core.php';
nc_page_headers();

$loginError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['do'] ?? '') === 'login') {
    $token = (string)($_POST['csrf'] ?? '');
    $pass  = (string)($_POST['password'] ?? '');

    if (!hash_equals(nc_csrf_token(), $token)) {
        $loginError = 'Güvenlik doğrulaması başarısız (CSRF). Sayfayı yenileyip tekrar dene.';
    } elseif (!nc_throttle('adminlogin:' . nc_client_ip(), 8, 600)) {
        $loginError = 'Çok fazla hatalı deneme. 10 dakika sonra tekrar dene.';
        nc_log('admin_login_block', 'Admin girişi rate limit nedeniyle engellendi');
    } elseif (nc_verify_admin_pass($pass)) {
        session_regenerate_id(true);
        $_SESSION['is_admin'] = true;
        $_SESSION['admin_at'] = time();
        nc_csrf_rotate();
        nc_log('admin_login', 'Admin girişi yapıldı');
        header('Location: adminlol.php');
        exit;
    } else {
        usleep(350000);
        $loginError = 'Şifre hatalı.';
        nc_log('admin_login_fail', 'Hatalı admin şifresi denemesi');
    }
}

$isAdmin = nc_is_admin();
$csrf = nc_csrf_token();
$siteName = nc_setting('site_name', 'NovaChat');

if (!$isAdmin):
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="theme-color" content="#070812">
<title>Yönetim Girişi</title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-admin-login" data-page="admin-login">

<div class="bg-decor" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
    <div class="grid-floor"></div>
</div>

<main class="admin-login-wrap">
    <div class="admin-login-card">
        <div class="card-border"></div>
        <div class="card-body">
            <div class="shield-wrap">
                <span class="shield">🛡️</span>
                <span class="shield-ring"></span>
            </div>
            <h1>Yönetim Paneli</h1>
            <p class="muted"><?= nc_h($siteName) ?> · yetkili girişi</p>

            <?php if ($loginError !== ''): ?>
                <div class="alert error" role="alert"><?= nc_h($loginError) ?></div>
            <?php endif; ?>

            <form method="post" action="adminlol.php" class="admin-login-form" autocomplete="off">
                <input type="hidden" name="csrf" value="<?= nc_h($csrf) ?>">
                <input type="hidden" name="do" value="login">
                <label for="adminPass">Admin şifresi</label>
                <div class="input-shell">
                    <span class="at">🔑</span>
                    <input id="adminPass" name="password" type="password" placeholder="••••••"
                           required autofocus autocomplete="current-password" maxlength="100">
                </div>
                <button class="btn-primary" type="submit"><span>Sisteme gir</span></button>
            </form>

            <p class="fineprint">
                Bu adres site üzerinde hiçbir yerde bağlantılı değildir. Şifreni
                <code>config.php</code> içindeki <code>admin_pass_hash</code> alanından veya panelden değiştirebilirsin.
            </p>
        </div>
    </div>
</main>

<div id="toastRoot" class="toast-root"></div>
<script src="assets/admin.js" defer></script>
</body>
</html>
<?php
exit;
endif;
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="theme-color" content="#070812">
<meta name="csrf-token" content="<?= nc_h($csrf) ?>">
<title>Yönetim · <?= nc_h($siteName) ?></title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-admin" data-page="admin">

<div class="bg-decor admin-bg" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
</div>

<header class="admin-topbar">
    <div class="brand">
        <span class="logo-mark">🛡️</span>
        <span class="brand-name"><?= nc_h($siteName) ?> <em>yönetim</em></span>
    </div>
    <div class="admin-topbar-actions">
        <span class="admin-session" id="adminSession">oturum: 2s 00d</span>
        <a class="btn-ghost" href="chat.php" target="_blank" rel="noopener">Siteyi aç ↗</a>
        <button class="btn-ghost" id="adminLogoutBtn" type="button">Çıkış</button>
    </div>
</header>

<main class="admin-layout">

    <nav class="admin-nav" id="adminNav">
        <button class="active" data-tab="dashboard" type="button"><span>📊</span> Genel Bakış</button>
        <button data-tab="users" type="button"><span>👥</span> Kullanıcılar</button>
        <button data-tab="messages" type="button"><span>💬</span> Mesajlar</button>
        <button data-tab="files" type="button"><span>📁</span> Dosyalar</button>
        <button data-tab="ipbans" type="button"><span>🚫</span> IP Banları</button>
        <button data-tab="game" type="button"><span>🍪</span> Oyun</button>
        <button data-tab="logs" type="button"><span>📜</span> Loglar</button>
        <button data-tab="settings" type="button"><span>⚙️</span> Ayarlar</button>
        <button data-tab="security" type="button"><span>🔑</span> Güvenlik</button>
    </nav>

    <section class="admin-content" id="adminContent">

        <!-- GENEL BAKIŞ -->
        <section class="admin-tab active" data-tab-panel="dashboard">
            <div class="admin-tab-head">
                <div><h2>Genel Bakış</h2><p>Sunucunun anlık durumu.</p></div>
                <button class="mini-btn" id="refreshDashboard" type="button">↻ Yenile</button>
            </div>
            <div class="stat-grid" id="statGrid">
                <div class="stat-card loading"></div>
                <div class="stat-card loading"></div>
                <div class="stat-card loading"></div>
                <div class="stat-card loading"></div>
            </div>
            <div class="admin-two">
                <div class="admin-box">
                    <header><h3>Son Hareketler</h3><span class="muted small">canlı log akışı</span></header>
                    <div class="log-feed" id="recentLogs"><p class="muted small">Yükleniyor…</p></div>
                </div>
                <div class="admin-box">
                    <header><h3>En İyi Oyuncular</h3><span class="muted small">toplam kazanç</span></header>
                    <ol class="lb-list small" id="topPlayers"><li class="lb-empty">Yükleniyor…</li></ol>
                </div>
            </div>
            <div class="admin-box">
                <header><h3>Sunucu Durumu</h3></header>
                <div class="kv-grid" id="serverInfo"></div>
            </div>
        </section>

        <!-- KULLANICILAR -->
        <section class="admin-tab" data-tab-panel="users">
            <div class="admin-tab-head">
                <div><h2>Kullanıcılar</h2><p>Ban, mute, IP değiştirme ve oyun verisi yönetimi.</p></div>
            </div>
            <form class="admin-toolbar" id="userSearchForm">
                <input type="search" id="userSearch" placeholder="Kullanıcı adı veya IP ara…" maxlength="30">
                <button class="mini-btn" type="submit">Ara</button>
                <button class="mini-btn ghost" type="button" id="userSearchClear">Temizle</button>
            </form>
            <div class="table-wrap">
                <table class="admin-table" id="usersTable">
                    <thead>
                    <tr>
                        <th>Kullanıcı</th><th>IP</th><th>Durum</th><th>Mesaj</th><th>Yükleme</th><th>Skor</th><th>Son görülme</th><th></th>
                    </tr>
                    </thead>
                    <tbody><tr><td colspan="8" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
            <div class="pager" id="usersPager"></div>
        </section>

        <!-- MESAJLAR -->
        <section class="admin-tab" data-tab-panel="messages">
            <div class="admin-tab-head">
                <div><h2>Mesajlar</h2><p>Tüm mesaj geçmişi. Silinenler dahil.</p></div>
                <button class="mini-btn danger" id="chatClearBtn" type="button">Sohbeti temizle</button>
            </div>
            <div class="admin-toolbar">
                <div class="filter-tabs" id="msgFilters">
                    <button class="active" data-filter="all" type="button">Tümü</button>
                    <button data-filter="active" type="button">Aktif</button>
                    <button data-filter="deleted" type="button">Silinen</button>
                </div>
                <form id="msgSearchForm" class="inline-form">
                    <input type="search" id="msgSearch" placeholder="Mesaj veya kullanıcı ara…" maxlength="50">
                    <button class="mini-btn" type="submit">Ara</button>
                </form>
            </div>
            <div class="table-wrap">
                <table class="admin-table" id="messagesTable">
                    <thead>
                    <tr><th>ID</th><th>Kullanıcı</th><th>IP</th><th>Mesaj</th><th>Tarih</th><th>Durum</th><th></th></tr>
                    </thead>
                    <tbody><tr><td colspan="7" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
            <div class="pager" id="messagesPager"></div>
        </section>

        <!-- DOSYALAR -->
        <section class="admin-tab" data-tab-panel="files">
            <div class="admin-tab-head">
                <div><h2>Dosyalar</h2><p>Yüklenen dosyalar ve IP başına kota kullanımı.</p></div>
            </div>
            <div class="admin-box">
                <header><h3>IP Kotası Kullanımı</h3><span class="muted small">en çok kullananlar</span></header>
                <div id="perIpList" class="per-ip-list"><p class="muted small">Yükleniyor…</p></div>
            </div>
            <div class="table-wrap">
                <table class="admin-table" id="filesTable">
                    <thead>
                    <tr><th>ID</th><th>Dosya</th><th>Tür</th><th>Boyut</th><th>Yükleyen</th><th>IP</th><th>Tarih</th><th></th></tr>
                    </thead>
                    <tbody><tr><td colspan="8" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
            <div class="pager" id="filesPager"></div>
        </section>

        <!-- IP BANLARI -->
        <section class="admin-tab" data-tab-panel="ipbans">
            <div class="admin-tab-head">
                <div><h2>IP Banları</h2><p>Banlı IP'ler siteye hiçbir şekilde erişemez.</p></div>
            </div>
            <form class="admin-box form-box" id="ipBanForm">
                <header><h3>Yeni IP Banı</h3></header>
                <div class="form-grid">
                    <label>IP adresi<input type="text" id="ipBanIp" placeholder="ör. 192.168.1.50" maxlength="45" required></label>
                    <label>Süre (dakika · 0 = süresiz)<input type="number" id="ipBanMinutes" value="0" min="0" max="525600"></label>
                    <label class="span-2">Sebep<input type="text" id="ipBanReason" placeholder="ör. spam / kötüye kullanım" maxlength="200"></label>
                </div>
                <button class="btn-primary small" type="submit">IP'yi banla</button>
            </form>
            <div class="table-wrap">
                <table class="admin-table" id="ipBansTable">
                    <thead>
                    <tr><th>IP</th><th>Sebep</th><th>Oluşturma</th><th>Bitiş</th><th>Durum</th><th></th></tr>
                    </thead>
                    <tbody><tr><td colspan="6" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
        </section>

        <!-- OYUN -->
        <section class="admin-tab" data-tab-panel="game">
            <div class="admin-tab-head">
                <div><h2>Oyun Yönetimi</h2><p>Kurabiye İmparatorluğu oyuncuları ve ayarları.</p></div>
                <button class="mini-btn danger" id="gameResetAll" type="button">Tüm oyun verisini sıfırla</button>
            </div>
            <div class="game-admin-stats" id="gameAdminStats"></div>
            <div class="table-wrap">
                <table class="admin-table" id="gameTable">
                    <thead>
                    <tr><th>#</th><th>Kullanıcı</th><th>IP</th><th>Kurabiye</th><th>Toplam kazanç</th><th>Tıklama</th><th>Güç seviyesi</th><th></th></tr>
                    </thead>
                    <tbody><tr><td colspan="8" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
            <p class="muted small">Oyun hızı ve çarpan ayarları <strong>Ayarlar</strong> sekmesinden değiştirilir.</p>
        </section>

        <!-- LOGLAR -->
        <section class="admin-tab" data-tab-panel="logs">
            <div class="admin-tab-head">
                <div><h2>Loglar</h2><p>Girişler, banlar, dosya yüklemeleri ve yönetim işlemleri.</p></div>
            </div>
            <div class="admin-toolbar">
                <select id="logTypeSelect"><option value="">Tüm türler</option></select>
                <div class="inline-form">
                    <label class="inline-label">Şundan eski logları sil:
                        <input type="number" id="logClearDays" value="30" min="1" max="3650">
                    </label>
                    <button class="mini-btn danger" id="logClearBtn" type="button">Temizle</button>
                </div>
            </div>
            <div class="table-wrap">
                <table class="admin-table" id="logsTable">
                    <thead>
                    <tr><th>ID</th><th>Tür</th><th>Detay</th><th>Kullanıcı</th><th>IP</th><th>Tarih</th></tr>
                    </thead>
                    <tbody><tr><td colspan="6" class="table-empty">Yükleniyor…</td></tr></tbody>
                </table>
            </div>
            <div class="pager" id="logsPager"></div>
        </section>

        <!-- AYARLAR -->
        <section class="admin-tab" data-tab-panel="settings">
            <div class="admin-tab-head">
                <div><h2>Site Ayarları</h2><p>Tüm ayarlar anında uygulanır.</p></div>
                <button class="mini-btn" id="settingsSave" type="button">💾 Kaydet</button>
            </div>
            <div id="settingsForm" class="settings-form">
                <p class="muted small">Yükleniyor…</p>
            </div>
        </section>

        <!-- GÜVENLİK -->
        <section class="admin-tab" data-tab-panel="security">
            <div class="admin-tab-head">
                <div><h2>Güvenlik</h2><p>Admin şifresi ve oturum bilgisi.</p></div>
            </div>
            <div class="admin-box">
                <header><h3>Admin şifresini değiştir</h3></header>
                <form id="passwordForm" class="form-grid" autocomplete="off">
                    <label>Mevcut şifre<input type="password" id="passCurrent" required autocomplete="current-password" maxlength="100"></label>
                    <label>Yeni şifre (min 6)<input type="password" id="passNew" required autocomplete="new-password" minlength="6" maxlength="100"></label>
                    <label>Yeni şifre (tekrar)<input type="password" id="passNew2" required autocomplete="new-password" minlength="6" maxlength="100"></label>
                    <button class="btn-primary small" type="submit">Şifreyi güncelle</button>
                </form>
                <p class="muted small">Şifre <code>config.php</code> içinde bcrypt hash olarak saklanır; panelden değiştirince dosya otomatik güncellenir.
                    Dosya yazılamıyorsa <code>config.php</code> izinlerini kontrol et.</p>
            </div>
            <div class="admin-box">
                <header><h3>Oturum</h3></header>
                <div class="kv-grid" id="securityInfo"></div>
                <button class="btn-ghost" id="securityLogout" type="button" style="margin-top:14px">Oturumu kapat</button>
            </div>
        </section>

    </section>
</main>

<!-- KULLANICI MODALI -->
<div class="modal hidden" id="userModal" role="dialog" aria-modal="true" aria-label="Kullanıcı yönetimi">
    <div class="modal-backdrop" data-close></div>
    <div class="modal-card user-modal">
        <header class="modal-head">
            <h3 id="umTitle">Kullanıcı</h3>
            <button class="modal-x" data-close aria-label="Kapat">×</button>
        </header>
        <div id="umBody"></div>
    </div>
</div>

<!-- ONAY MODALI -->
<div class="modal hidden" id="confirmModal" role="dialog" aria-modal="true" aria-label="Onay">
    <div class="modal-backdrop" data-close></div>
    <div class="modal-card confirm-card">
        <h3 id="cfTitle">Emin misin?</h3>
        <p id="cfText"></p>
        <div class="cf-actions">
            <button class="btn-ghost" id="cfCancel" type="button">İptal</button>
            <button class="btn-danger" id="cfOk" type="button">Onayla</button>
        </div>
    </div>
</div>

<div id="toastRoot" class="toast-root" aria-live="polite"></div>
<script src="assets/admin.js" defer></script>
</body>
</html>
