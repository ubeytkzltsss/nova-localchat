# 🚀 NovaChat'i GitHub'da Yayınlama — Adım Adım Rehber

Bu rehber **hiç GitHub kullanmamış** biri için yazıldı. Toplam süre: ~15 dakika.
Komutları sırayla kopyala-yapıştır yapabilirsin.

> **Kısa özet:** klasörü GitHub'a yükle → repo açıklamasını ve etiketleri gir →
> sosyal önizleme görselini seç → istersen bir sürüm (release) yayınla → linki paylaş.

---

## 0) Önce şunları hazırla

| Gereken | Nereden |
|---|---|
| GitHub hesabı | [github.com/signup](https://github.com/signup) (ücretsiz) |
| Git programı | [git-scm.com/downloads](https://git-scm.com/downloads) — Windows/macOS/Linux |
| Proje klasörü | `novachat/` (README, LICENSE, docs/ içindeki her şey hazır) |

Git kurulduktan sonra bir kez kimliğini tanıt (commit'lerde görünecek isim):

```bash
git config --global user.name "Adın Soyadın"
git config --global user.email "eposta@ornek.com"
```

> İstersen GitHub'ın senin e-postanı herkese göstermemesini sağlayabilirsin:
> GitHub → **Settings → Emails → Keep my email addresses private**.
> Sonra `user.email` olarak GitHub'ın verdiği `12345+kullanici@users.noreply.github.com`
> adresini kullan.

---

## 1) GitHub'da boş repo aç

1. [github.com/new](https://github.com/new) adresine git.
2. **Repository name:** `novachat`
3. **Description:** aşağıdaki metni yapıştır (açıklama repo sayfasında ve aramalarda görünür).
4. **Public** seç (herkes görsün) — istemiyorsan **Private** de olur.
5. ⚠️ **"Add a README file", ".gitignore", "license" kutularını İŞARETLEME.** Projede bunlar zaten var;
   işaretlersen çakışma olur.
6. **Create repository** → karşına "…or push an existing repository from the command line" ekranı çıkar.

Description için kopyalanacak metin:

```text
Şifresiz (IP tabanlı) girişli, canlı Tenor GIF aramalı Türkçe sohbet + sonsuz clicker oyunu. PHP · MySQL · Apache · XAMPP
```

---

## 2) Projeyi yükle (terminal / komut satırı)

Terminali **novachat klasörünün içinde** aç ve sırayla çalıştır.
`KULLANICI_ADIN` yazan yeri kendi GitHub kullanıcı adınla değiştir.

```bash
cd novachat

git init
git add .
git commit -m "NovaChat: sohbet + clicker oyunu"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/novachat.git
git push -u origin main
```

İlk `push` sırasında tarayıcı açılıp GitHub'a giriş isteyebilir — izin ver, gerisi otomatik.

### Git kullanmadan (alternatif)
Git kurmak istemiyorsan: repo sayfasında **Add file → Upload files** → `novachat` klasörünün
**içindekileri** sürükle bırak → **Commit changes**.
> Dikkat: klasörün kendisini değil, **içindeki dosyaları** yükle. `docs/` klasörünü de
> sürüklemeyi unutma, yoksa README'deki görseller görünmez.

### Ne yükleniyor?
`uploads/` klasörü `.gitignore` sayesinde **yüklenmez** (kullanıcı dosyaları repoya girmez,
kurulumda kendiliğinden oluşur). `config.php` kutudan çıktığı hâliyle kişisel bilgi içermez
(XAMPP varsayılanları: `root` + boş şifre), bu yüzden güvenle repoda durabilir.

---

## 3) Repo sayfasını düzenle ("About" bölümü)

Repo sayfasında sağ üstteki ⚙️ **dişli** simgesine bas → **About** paneli açılır:

| Alan | Yazılacak |
|---|---|
| **Description** | Yukarıdaki tek satırlık açıklama |
| **Website** | Canlı demo adresin (varsa). Yoksa boş bırak. |
| **Topics** (etiketler) | `php` `mysql` `chat` `xampp` `clicker-game` `turkish` `self-hosted` `tenor` `vanilla-js` `no-framework` |

**Topics** çok önemli: GitHub aramasında ve "Explore" sayfasında projenin bulunmasını sağlar.
Yazıp **Enter**'a basarak tek tek ekle, sonra **Save changes**.

---

## 4) Sosyal önizleme görselini ayarla

Birisi linki Twitter/X, WhatsApp, Discord veya LinkedIn'de paylaştığında çıkan büyük görsel.

Repo → **Settings** → sol menüde **General** → en altta **Social preview** →
**Upload an image…** → `docs/social-preview.png` dosyasını seç.

> Dosya 1280×640 px (GitHub'ın önerdiği oran) ve proje için hazır üretildi.
> Aynı görsel README'nin en üstünde de kullanılıyor.

---

## 5) İsteğe bağlı ama çok işe yarar: Sürüm (Release) yayınla

"v1.0.0" sürümü, indirilebilir bir ZIP ve şık bir sürüm sayfası oluşturur.

1. Repo → sağ sütunda **Releases** → **Create a new release**
2. **Choose a tag** → `v1.0.0` yaz → **Create new tag on publish**
3. **Release title:** `NovaChat v1.0.0 — ilk sürüm`
4. **Describe this release:** alanına aşağıdaki metni yapıştır
5. **Attach binaries** → projenin ZIP'ini sürükle bırak (indirmek isteyenler için)
6. **Publish release**

Sürüm notu için kopyalanacak metin:

```markdown
İlk herkese açık sürüm.

- Şifresiz, IP tabanlı giriş (hesap IP'ye kilitli)
- Tek genel sohbet: yanıtlama, @etiketleme, masaüstü bildirimi
- Dosya paylaşımı: 80 MB/dosya, IP başına 5 GB kota
- Canlı Tenor GIF araması (önbellekli)
- Sonsuz clicker oyunu (sunucu tarafı, kaldığı yerden devam)
- Gizli yönetim paneli: ban, IP ban, mute, loglar, ayarlar

Kurulum: klasörü htdocs'a at, Apache + MySQL'i başlat, tarayıcıda aç. Hepsi bu.
```

> ZIP'i oluşturmak için klasörün bir üstünde:
> `zip -r novachat-v1.0.0.zip novachat -x "novachat/uploads/*"`
> (Windows'ta sağ tık → *Sıkıştırılmış klasöre gönder*).

---

## 6) Linki paylaş

Paylaşacağın adres:

```
https://github.com/KULLANICI_ADIN/novachat
```

**Kısa, hazır tanıtım metni** (kopyala-yapıştır):

> 🚀 **NovaChat** — XAMPP'ta 2 adımda çalışan Türkçe sohbet sitesi.
> Şifre yok, giriş IP tabanlı; tek genel oda, 80 MB dosya paylaşımı, canlı Tenor GIF araması,
> sonsuz clicker oyunu ve gizli yönetim paneli. Saf PHP + MySQL, framework yok.
> 👉 github.com/KULLANICI_ADIN/novachat

**Paylaşabileceğin yerler:**

| Yer | Not |
|---|---|
| **X / Twitter** | `#php #opensource #xampp #sideproject` etiketleriyle, görsel ekleyerek |
| **Reddit** | r/PHP, r/selfhosted, r/webdev — her birinin tanıtım kuralları farklı, önce oku |
| **Hacker News** | `Show HN: NovaChat – ...` formatı, İngilizce metin daha çok ilgi görür |
| **Discord / Telegram** | Geliştirici ve self-hosted toplulukları |
| **Türkçe topluluklar** | r/Turkey, r/yazilim, Dev Türkiye Discord sunucuları |
| **LinkedIn** | “Kendi sunucumda çalışan bir sohbet + oyun projesi yazdım” tonu iyi çalışır |

İngilizce tanıtım metni (yabancı topluluklar için):

> 🚀 **NovaChat** — a self-hosted Turkish chat app that runs on XAMPP in 2 steps.
> Passwordless IP-based login, one public room, 80 MB file sharing, live Tenor GIF search,
> an endless clicker game and a hidden admin panel. Plain PHP + MySQL, no framework, MIT licensed.
> 👉 github.com/KULLANICI_ADIN/novachat

> 💡 **İpucu:** Paylaştığın metne `docs/social-preview.png` görselini de ekle — link
> önizlemesinden çok daha fazla tıklama alır.

---

## 7) Yayına çıkardıktan sonra

| İş | Neden |
|---|---|
| **Varsayılan admin şifresini değiştir** | Panelde `123321` duruyor. Canlıya alacaksan ilk iş bu. |
| **HTTPS kullan** | Let's Encrypt ücretsiz. IP tabanlı giriş ve oturum çerezleri için şart. |
| **`config.php`'ye gerçek DB şifresini yazarsan** | O satırı `.gitignore`'a ekle, şifreyi repoya gönderme. |
| **Yedekleme** | `mysqldump novachat_db > yedek.sql` + `uploads/` klasörü (ikisi birlikte). |
| **Star / Watch** | Kendi projene star vermek görünürlüğü hafif artırır; "Watch → Releases only" ile sürümleri takip et. |

---

## 8) Sık karşılaşılan sorunlar

| Sorun | Çözüm |
|---|---|
| `remote origin already exists` | `git remote set-url origin https://github.com/KULLANICI_ADIN/novachat.git` |
| `rejected — fetch first` | Repo'yu README ile oluşturmuşsun: `git pull --rebase origin main` sonra tekrar `git push` |
| `Authentication failed` | GitHub artık şifre kabul etmiyor. **Settings → Developer settings → Personal access tokens** ile token üret, şifre yerine onu yapıştır. |
| README'de görseller kırık | `docs/` klasörü yüklenmemiş. Klasörün repoda olduğunu kontrol et (`docs/social-preview.png`, `docs/sohbet.jpg`…). |
| Dosya boyutu uyarısı | `uploads/` klasörü `.gitignore`'da olmalı; `git rm -r --cached uploads` ile takipten çıkar. |
| Türkçe karakterler bozuk | Terminal kodlaması UTF-8 olmalı: `git config --global core.quotepath false` |

---

## 9) Kontrol listesi ✅

- [ ] GitHub'da boş repo açıldı (README/gitignore/lisans **işaretlenmedi**)
- [ ] `git push` başarılı, dosyalar repoda görünüyor
- [ ] README en üstte ekran görüntüsüyle açılıyor
- [ ] About: açıklama + topics eklendi
- [ ] Social preview görseli yüklendi
- [ ] (İsteğe bağlı) `v1.0.0` release + ZIP eklendi
- [ ] Link bir arkadaşına gönderildi, önizleme doğru görünüyor
- [ ] Canlıya alacaksan admin şifresi değiştirildi ve HTTPS açık

**Hepsi bu — projen yayında! 🍪**
