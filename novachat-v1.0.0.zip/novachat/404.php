<?php
/**
 * NovaChat - 404
 */
declare(strict_types=1);

require __DIR__ . '/core.php';
nc_page_headers();
http_response_code(404);

$siteName = nc_safe_setting('site_name', 'NovaChat');
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>404 · <?= nc_h($siteName) ?></title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-404" data-page="404">
<div class="bg-decor" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <div class="grid-floor"></div>
</div>
<main class="notfound-wrap">
    <div class="notfound-card">
        <div class="nf-code">4<span>0</span>4</div>
        <h1>Bu sayfa burada değil.</h1>
        <p class="muted">Aradığın sayfa taşınmış ya da hiç var olmamış olabilir.</p>
        <div class="nf-actions">
            <a class="btn-primary" href="chat.php">Sohbete dön</a>
            <a class="btn-ghost" href="index.php">Giriş sayfası</a>
        </div>
    </div>
</main>
</body>
</html>
