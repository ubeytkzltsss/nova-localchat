<?php
/**
 * NovaChat - Genel sohbet sayfası
 */
declare(strict_types=1);

require __DIR__ . '/core.php';
nc_page_headers();
$user = nc_guard_page();

$siteName    = nc_setting('site_name', 'NovaChat');
$csrf        = nc_csrf_token();
$cooldownMs  = (int)nc_setting('cooldown_ms', '3000');
$maxLen      = (int)nc_setting('msg_max_len', '500');
$maxMb       = (int)nc_setting('max_upload_mb', '80');
$quotaUsed   = nc_quota_used(nc_client_ip());
$quotaLimit  = nc_quota_limit_bytes();
$gifsOn      = (int)nc_setting('gifs_enabled', '1') === 1;
$gamesOn     = (int)nc_setting('games_enabled', '1') === 1;
$uploadsOn   = (int)nc_setting('uploads_enabled', '1') === 1;
$chatOn      = (int)nc_setting('chat_enabled', '1') === 1;
$announcement = (string)nc_setting('announcement', '');

$onlineStmt = nc_db()->prepare(
    "SELECT u.id, u.username, u.typing_at, COALESCE(g.total_earned, 0) AS score
     FROM nc_users u LEFT JOIN nc_game g ON g.user_id = u.id
     WHERE u.last_seen >= ? AND u.is_banned = 0
     ORDER BY u.username ASC LIMIT 200"
);
$onlineStmt->execute([time() - 70]);
$onlineUsers = $onlineStmt->fetchAll();
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#070812">
<meta name="csrf-token" content="<?= nc_h($csrf) ?>">
<title>#genel-sohbet · <?= nc_h($siteName) ?></title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-chat"
      data-page="chat"
      data-uid="<?= (int)$user['id'] ?>"
      data-username="<?= nc_h($user['username']) ?>"
      data-site-name="<?= nc_h($siteName) ?>"
      data-cooldown-ms="<?= $cooldownMs ?>"
      data-max-len="<?= $maxLen ?>"
      data-max-upload="<?= $maxMb ?>"
      data-quota-used="<?= $quotaUsed ?>"
      data-quota-limit="<?= $quotaLimit ?>"
      data-chat-enabled="<?= $chatOn ? '1' : '0' ?>"
      data-uploads-enabled="<?= $uploadsOn ? '1' : '0' ?>"
      data-gifs-enabled="<?= $gifsOn ? '1' : '0' ?>"
      data-games-enabled="<?= $gamesOn ? '1' : '0' ?>"
      data-last-msg-ms="<?= (int)$user['last_msg_at'] ?>"
      data-mute-until="<?= (int)$user['muted_until'] ?>">

<div class="bg-decor chat-bg" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
    <div class="grid-floor"></div>
</div>

<div id="connBanner" class="conn-banner hidden" role="status">
    <span class="conn-spinner"></span> Bağlantı yeniden kuruluyor…
</div>

<header class="topbar">
    <a class="brand" href="chat.php">
        <span class="logo-mark">✦</span>
        <span class="brand-name"><?= nc_h($siteName) ?></span>
    </a>

    <div class="topbar-center">
        <span class="live-pill" id="livePill">
            <span class="live-dot"></span>
            <span id="onlinePill"><?= count($onlineUsers) ?> çevrimiçi</span>
        </span>
    </div>

    <div class="topbar-actions">
        <button id="btnPeople" class="btn-icon only-mobile" title="Aktif kullanıcılar" type="button">👥</button>
        <?php if ($gamesOn): ?>
        <button id="btnGames" class="btn-ghost" type="button"><span class="ico">🎮</span><span class="label">Oyunlar</span></button>
        <?php endif; ?>
        <button id="btnNotify" class="btn-icon" title="Masaüstü bildirimlerini aç" type="button">🔔</button>
        <div class="user-chip" id="selfChip" title="<?= nc_h($user['username']) ?>">
            <span class="avatar" data-avatar="<?= nc_h($user['username']) ?>"><?= nc_h(mb_strtoupper(mb_substr($user['username'], 0, 1))) ?></span>
            <span class="user-name"><?= nc_h($user['username']) ?></span>
        </div>
        <button id="btnLogout" class="btn-icon danger-hover" title="Çıkış yap" type="button">⏻</button>
    </div>
</header>

<main class="chat-layout">

    <aside class="panel online-panel" id="onlinePanel">
        <div class="panel-head">
            <h2>Aktif Kullanıcılar</h2>
            <span class="badge" id="onlineCount"><?= count($onlineUsers) ?></span>
        </div>
        <ul class="online-list" id="onlineList">
            <?php foreach ($onlineUsers as $ou): ?>
                <li class="online-item<?= (int)$ou['id'] === (int)$user['id'] ? ' me' : '' ?>" data-name="<?= nc_h($ou['username']) ?>">
                    <span class="avatar" data-avatar="<?= nc_h($ou['username']) ?>"><?= nc_h(mb_strtoupper(mb_substr($ou['username'], 0, 1))) ?></span>
                    <span class="online-meta">
                        <span class="online-name"><?= nc_h($ou['username']) ?><?= (int)$ou['id'] === (int)$user['id'] ? ' <em>(sen)</em>' : '' ?></span>
                        <span class="online-score">🍪 <span class="score-num"><?= number_format((float)$ou['score'], 0, ',', '.') ?></span></span>
                    </span>
                    <span class="presence-dot" aria-hidden="true"></span>
                </li>
            <?php endforeach; ?>
        </ul>
        <div class="panel-foot">
            <div class="me-card">
                <div class="me-top">
                    <span class="avatar" data-avatar="<?= nc_h($user['username']) ?>"><?= nc_h(mb_strtoupper(mb_substr($user['username'], 0, 1))) ?></span>
                    <div class="me-info">
                        <strong><?= nc_h($user['username']) ?></strong>
                        <span>IP kilitli hesap</span>
                    </div>
                </div>
                <div class="quota">
                    <div class="quota-row">
                        <span>Dosya kotan</span>
                        <span id="meQuotaText"><?= nc_h(nc_format_bytes((float)$quotaUsed)) ?> / <?= nc_h(nc_format_bytes((float)$quotaLimit)) ?></span>
                    </div>
                    <div class="quota-track"><div class="quota-fill" id="meQuotaFill" style="width: <?= $quotaLimit > 0 ? min(100, round($quotaUsed / $quotaLimit * 100, 1)) : 0 ?>%"></div></div>
                </div>
            </div>
        </div>
    </aside>

    <section class="panel chat-main">

        <div class="chat-head">
            <div class="chat-title">
                <h1><span class="hash">#</span> genel-sohbet</h1>
                <p id="chatSub">
                    Herkes burada · yavaş mod <strong><?= number_format($cooldownMs / 1000, 1, ',', '') ?> sn</strong>
                    · dosya limiti <strong><?= $maxMb ?> MB</strong>
                </p>
            </div>
            <div class="chat-head-right">
                <span class="pill-vibe" id="moodPill">✨ canlı</span>
            </div>
        </div>

        <?php if ($announcement !== ''): ?>
        <div class="announcement" id="announcement">
            <span class="ann-ico">📣</span>
            <p id="annText"><?= nc_h($announcement) ?></p>
            <button type="button" id="annClose" aria-label="Duyuruyu kapat">×</button>
        </div>
        <?php else: ?>
        <div class="announcement hidden" id="announcement">
            <span class="ann-ico">📣</span>
            <p id="annText"></p>
            <button type="button" id="annClose" aria-label="Duyuruyu kapat">×</button>
        </div>
        <?php endif; ?>

        <?php if (!$chatOn): ?>
        <div class="chat-closed" id="chatClosed">
            <span>🛠️</span>
            <strong>Sohbet yönetici tarafından geçici olarak kapatıldı.</strong>
            <p>Mesaj gönderimi devre dışı. Kısa süre sonra tekrar dene.</p>
        </div>
        <?php endif; ?>

        <div class="messages-wrap" id="messagesWrap">
            <div class="messages" id="messages" aria-live="polite" aria-relevant="additions">
                <div class="skeleton-list" id="skeletonList">
                    <div class="skeleton-msg"><span class="sk-avatar"></span><span class="sk-lines"><i></i><i></i></span></div>
                    <div class="skeleton-msg"><span class="sk-avatar"></span><span class="sk-lines"><i></i><i></i></span></div>
                    <div class="skeleton-msg"><span class="sk-avatar"></span><span class="sk-lines"><i></i></span></div>
                </div>
            </div>
            <button class="new-msg-pill hidden" id="newMsgPill" type="button">↓ Yeni mesajlar</button>
        </div>

        <div class="typing-bar" id="typingBar">
            <span class="typing-dots" aria-hidden="true"><i></i><i></i><i></i></span>
            <span id="typingText"></span>
        </div>

        <form class="composer" id="composer" autocomplete="off">
            <div class="reply-bar hidden" id="replyBar">
                <span class="reply-ico">↩</span>
                <span><strong id="replyName"></strong> mesajına yanıt veriyorsun</span>
                <button type="button" id="replyCancel" aria-label="Yanıtı iptal et">×</button>
            </div>

            <div class="pending-file hidden" id="pendingFile">
                <span class="pf-ico">📎</span>
                <div class="pf-meta">
                    <strong id="pfName"></strong>
                    <span id="pfSize"></span>
                </div>
                <div class="pf-progress"><div id="pfBar"></div></div>
                <button type="button" id="pfRemove" aria-label="Dosyayı kaldır">×</button>
            </div>

            <div class="composer-row">
                <button type="button" class="composer-btn" id="btnAttach" title="Dosya ekle (<?= $maxMb ?> MB)" <?= $uploadsOn ? '' : 'disabled' ?>>📎</button>
                <input type="file" id="fileInput" hidden>
                <textarea id="msgInput" rows="1" maxlength="<?= $maxLen ?>"
                          placeholder="Mesajını yaz…  @isim ile etiketle" <?= $chatOn ? '' : 'disabled' ?>></textarea>
                <button type="submit" class="send-btn" id="btnSend" <?= $chatOn ? '' : 'disabled' ?>>
                    <span>Gönder</span>
                    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M3 11.5 21 3l-8.5 18-2.2-7.3L3 11.5Z" fill="currentColor"/></svg>
                </button>
            </div>

            <div class="composer-meta">
                <span id="charCount">0/<?= $maxLen ?></span>
                <span class="dot-sep">·</span>
                <span id="quotaInfo">Kota: <?= nc_h(nc_format_bytes((float)$quotaUsed)) ?> / <?= nc_h(nc_format_bytes((float)$quotaLimit)) ?></span>
                <span class="hint">Enter gönder · Shift+Enter yeni satır</span>
            </div>

            <div class="cooldown-bar hidden" id="cooldownBar">
                <div class="cooldown-fill" id="cooldownFill"></div>
                <span class="cooldown-text" id="cooldownText"></span>
            </div>

            <div class="composer-lock hidden" id="muteNotice">
                <span>🔇</span> Susturulmuşsun. Kalan süre: <strong id="muteLeft">—</strong>
            </div>
        </form>

    </section>
</main>

<?php if ($gifsOn): ?>
<button class="gif-fab" id="gifFab" type="button" title="GIF gönder" aria-label="GIF gönder">
    <span class="gif-ring"></span>
    <span class="gif-text">GIF</span>
</button>
<?php endif; ?>

<div class="modal hidden" id="gifModal" role="dialog" aria-modal="true" aria-label="GIF ara">
    <div class="modal-backdrop" data-close></div>
    <div class="modal-card gif-card">
        <header class="modal-head">
            <h3>GIF Ara</h3>
            <button class="modal-x" data-close aria-label="Kapat">×</button>
        </header>

        <div class="gif-search">
            <span class="gs-ico" aria-hidden="true">🔍</span>
            <input
                id="gifQuery"
                type="search"
                inputmode="search"
                placeholder="GIF ara…  ör. kedi, dans, aşk"
                maxlength="40"
                autocomplete="off"
                spellcheck="false"
                aria-label="GIF ara"
            >
            <button type="button" class="gs-clear hidden" id="gifClear" aria-label="Aramayı temizle">×</button>
        </div>

        <div class="gif-hint-row">
            <span id="gifHint">Popüler GIF'ler</span>
            <span class="gif-powered">Tenor</span>
        </div>

        <div class="gif-grid" id="gifGrid"></div>
        <div class="gif-status" id="gifStatus" aria-live="polite"></div>
    </div>
</div>

<?php if ($gamesOn): ?>
<div class="modal hidden" id="gamesModal" role="dialog" aria-modal="true" aria-label="Oyun menüsü">
    <div class="modal-backdrop" data-close></div>
    <div class="modal-card games-card">
        <header class="modal-head">
            <h3>🎮 Oyun Menüsü</h3>
            <button class="modal-x" data-close aria-label="Kapat">×</button>
        </header>

        <div class="games-grid">
            <article class="game-tile playable">
                <div class="gt-glow"></div>
                <span class="gt-emoji bounce">🍪</span>
                <h4>Kurabiye İmparatorluğu</h4>
                <p>Sonsuz tıkla, dükkândan binalar al, skor tablosunda yüksel.</p>
                <a class="btn-play" href="game.php">Oyna <span>→</span></a>
            </article>
            <article class="game-tile locked">
                <span class="gt-emoji">💣</span>
                <h4>Mayın Tarlası</h4>
                <p>Klasik mayın temizleme. Yapım aşamasında.</p>
                <span class="soon-chip">yakında</span>
            </article>
            <article class="game-tile locked">
                <span class="gt-emoji">📈</span>
                <h4>Fake Trading</h4>
                <p>Sahte borsada al-sat. Yapım aşamasında.</p>
                <span class="soon-chip">yakında</span>
            </article>
        </div>

        <div class="scoreboard">
            <div class="scoreboard-head">
                <h3>🏆 Skor Tablosu</h3>
                <button class="mini-btn" id="refreshLb" type="button">↻ Yenile</button>
            </div>
            <ol class="lb-list small" id="gameLbList">
                <li class="lb-empty">Yükleniyor…</li>
            </ol>
        </div>

        <footer class="modal-foot">
            <button class="btn-ghost" type="button" data-close>← Sohbete dön</button>
        </footer>
    </div>
</div>
<?php endif; ?>

<div class="lightbox hidden" id="lightbox">
    <button class="lightbox-close" id="lightboxClose" aria-label="Kapat">×</button>
    <img id="lightboxImg" alt="">
</div>

<div id="toastRoot" class="toast-root" aria-live="polite"></div>
<script src="assets/app.js" defer></script>
</body>
</html>
