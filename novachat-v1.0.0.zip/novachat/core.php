<?php
/**
 * NovaChat - Çekirdek kütüphane
 * Tüm sunucu tarafı mantık buradan yürür.
 */
declare(strict_types=1);

define('NC_ROOT', __DIR__);
define('NC_VERSION', '1.0.0');

$GLOBALS['NC_CONFIG']  = require NC_ROOT . '/config.php';
$GLOBALS['NC_DB']      = null;
$GLOBALS['NC_SETTINGS'] = null;
$GLOBALS['NC_USER']    = null;
$GLOBALS['NC_USER_DONE'] = false;

date_default_timezone_set((string)($GLOBALS['NC_CONFIG']['app']['timezone'] ?? 'Europe/Istanbul'));
mb_internal_encoding('UTF-8');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

if (PHP_SAPI !== 'cli') {
    if (!headers_sent()) {
        header_remove('X-Powered-By');
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    }
}

/* ============================================================
   GLOBAL HATA YAKALAYICI
   Beklenmeyen hatalarda istemciye asla ham hata/stack trace gitmez.
   ============================================================ */

$GLOBALS['NC_RESPONDED'] = false;

function nc_error_response(string $logMessage): void
{
    if ($GLOBALS['NC_RESPONDED'] ?? false) {
        return;
    }
    $GLOBALS['NC_RESPONDED'] = true;

    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "[NovaChat] $logMessage\n");
        return;
    }
    try {
        nc_log('error', 'Beklenmeyen hata: ' . $logMessage);
    } catch (Throwable $e) {
    }
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
    }
    echo json_encode(['ok' => false, 'error' => 'Sunucu tarafında beklenmeyen bir hata oluştu. Lütfen tekrar dene.'], JSON_UNESCAPED_UNICODE);
    exit;
}

set_exception_handler(static function (Throwable $e): void {
    error_log('[NovaChat] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    nc_error_response(get_class($e) . ': ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());
});

register_shutdown_function(static function (): void {
    $err = error_get_last();
    if (!is_array($err)) {
        return;
    }
    if (!in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true)) {
        return;
    }
    nc_error_response($err['message'] . ' @ ' . basename((string)$err['file']) . ':' . $err['line']);
});

nc_session_start();

/* ============================================================
   OTURUM
   ============================================================ */

function nc_is_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
}

function nc_session_start(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = nc_is_https();
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_trans_sid', '0');
    session_name('NCSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    @session_start();
}

/* ============================================================
   TEMEL YARDIMCILAR
   ============================================================ */

function nc_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function nc_num(float $v): float
{
    if (is_nan($v) || is_infinite($v)) {
        return 0.0;
    }
    $max = 1.0e33;
    if ($v > $max) {
        return $max;
    }
    if ($v < -$max) {
        return -$max;
    }
    return $v;
}

function nc_format_bytes(float $bytes): string
{
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return ($i === 0 ? (string)(int)$bytes : number_format($bytes, 2, ',', '.')) . ' ' . $units[$i];
}

function nc_input(): array
{
    static $data = null;
    if ($data !== null) {
        return $data;
    }
    $data = $_POST;
    $ctype = (string)($_SERVER['CONTENT_TYPE'] ?? '');
    if (stripos($ctype, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        if (is_string($raw) && $raw !== '') {
            $json = json_decode($raw, true);
            if (is_array($json)) {
                $data = array_merge($data, $json);
            }
        }
    }
    return $data;
}

function nc_client_ip(): string
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

function nc_json($payload, int $code = 200): void
{
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    }
    $GLOBALS['NC_RESPONDED'] = true;
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function nc_fail(string $error, int $code = 400, array $extra = []): void
{
    nc_json(array_merge(['ok' => false, 'error' => $error], $extra), $code);
}

function nc_page_headers(): void
{
    if (headers_sent()) {
        return;
    }
    header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://*.tenor.com; media-src 'self' blob: https://*.tenor.com; connect-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

function nc_clean_text(string $text): string
{
    // Kontrol karakterlerini temizle (yeni satır / sekme hariç), geçersiz UTF-8'i düzelt.
    $text = mb_convert_encoding($text, 'UTF-8', 'UTF-8');
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);
    return is_string($text) ? $text : '';
}

/* ============================================================
   VERİTABANI + KURULUM
   ============================================================ */

function nc_db_error_page(string $message): void
{
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "Veritabani hatasi: $message\n");
        exit(1);
    }
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    $name = nc_h((string)($GLOBALS['NC_CONFIG']['app']['name'] ?? 'NovaChat'));
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Veritabanı Hatası</title>';
    echo '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0d17;color:#e8e9f3;font-family:Segoe UI,system-ui,sans-serif;padding:24px}'
        . 'main{max-width:560px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:32px}'
        . 'h1{margin:0 0 8px;font-size:22px}code{background:#11142a;padding:2px 8px;border-radius:8px;color:#8be9fd}'
        . 'p{line-height:1.6;color:#a9adc9}pre{white-space:pre-wrap;background:#11142a;padding:14px;border-radius:12px;font-size:13px;color:#ffb4c0}</style></head><body><main>';
    echo '<h1>🔌 Veritabanı bağlantısı kurulamadı</h1>';
    echo '<p>' . $name . ' çalışmak için MySQL/MariaDB kullanır. XAMPP kontrol panelinden <strong>MySQL</strong> servisini başlattığından emin ol.</p>';
    echo '<p><code>config.php</code> içindeki <code>db</code> ayarlarını kontrol et. Varsayılan XAMPP bilgileri: kullanıcı <code>root</code>, şifre boş.</p>';
    echo '<pre>' . nc_h($message) . '</pre></main></body></html>';
    exit;
}

function nc_install(PDO $pdo): void
{
    $sql = [
        "CREATE TABLE IF NOT EXISTS nc_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(20) NOT NULL,
            username_lc VARCHAR(20) NOT NULL,
            ip VARCHAR(45) NOT NULL DEFAULT '',
            remember_selector CHAR(32) NOT NULL DEFAULT '',
            remember_hash CHAR(64) NOT NULL DEFAULT '',
            remember_expires BIGINT UNSIGNED NOT NULL DEFAULT 0,
            is_banned TINYINT(1) NOT NULL DEFAULT 0,
            ban_reason VARCHAR(255) NOT NULL DEFAULT '',
            muted_until BIGINT UNSIGNED NOT NULL DEFAULT 0,
            last_msg_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            typing_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            last_seen BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY uq_username (username),
            UNIQUE KEY uq_username_lc (username_lc),
            KEY idx_ip (ip),
            KEY idx_seen (last_seen),
            KEY idx_selector (remember_selector)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_messages (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            body TEXT NOT NULL,
            reply_to INT UNSIGNED NULL DEFAULT NULL,
            file_id INT UNSIGNED NULL DEFAULT NULL,
            gif_url VARCHAR(300) NOT NULL DEFAULT '',
            deleted TINYINT(1) NOT NULL DEFAULT 0,
            deleted_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_created (created_at),
            KEY idx_user (user_id),
            KEY idx_deleted (deleted, deleted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_files (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            ip VARCHAR(45) NOT NULL,
            orig_name VARCHAR(190) NOT NULL,
            stored_name VARCHAR(64) NOT NULL,
            mime VARCHAR(100) NOT NULL,
            size BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_user (user_id),
            KEY idx_ip (ip),
            KEY idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_game (
            user_id INT UNSIGNED NOT NULL,
            cookies DOUBLE NOT NULL DEFAULT 0,
            total_earned DOUBLE NOT NULL DEFAULT 0,
            clicks BIGINT UNSIGNED NOT NULL DEFAULT 0,
            click_level INT UNSIGNED NOT NULL DEFAULT 1,
            buildings TEXT NOT NULL,
            last_tick BIGINT UNSIGNED NOT NULL DEFAULT 0,
            tokens DOUBLE NOT NULL DEFAULT 30,
            tokens_at DOUBLE NOT NULL DEFAULT 0,
            updated_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_logs (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            type VARCHAR(30) NOT NULL DEFAULT '',
            data TEXT NOT NULL,
            user_id INT UNSIGNED NULL DEFAULT NULL,
            ip VARCHAR(45) NOT NULL DEFAULT '',
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_type (type),
            KEY idx_created (created_at),
            KEY idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_ip_bans (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            ip VARCHAR(45) NOT NULL,
            reason VARCHAR(255) NOT NULL DEFAULT '',
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            expires BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY uq_ip (ip),
            KEY idx_expires (expires)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_settings (
            k VARCHAR(50) NOT NULL,
            v TEXT NOT NULL,
            PRIMARY KEY (k)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_cache (
            k CHAR(64) NOT NULL,
            v MEDIUMTEXT NOT NULL,
            expires BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (k)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

        "CREATE TABLE IF NOT EXISTS nc_throttle (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            bucket CHAR(64) NOT NULL,
            created_at BIGINT UNSIGNED NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_bucket (bucket, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    ];

    $needsCreate = !$pdo->query("SHOW TABLES LIKE 'nc_users'")->fetchColumn();
    if ($needsCreate) {
        foreach ($sql as $q) {
            $pdo->exec($q);
        }
    }

    // Şema sürümü: migrasyonlar yalnızca gerektiğinde çalışır (her istekte sorgu yapılmaz)
    $schemaVersion = '4';
    $installed = null;
    if (!$needsCreate) {
        try {
            $st = $pdo->query("SELECT v FROM nc_settings WHERE k = 'schema_ver' LIMIT 1");
            $installed = $st ? $st->fetchColumn() : null;
        } catch (Throwable $e) {
            $installed = null;
        }
    }
    if ($needsCreate || (string)$installed !== $schemaVersion) {
        try {
            $len = (int)$pdo->query("SELECT COALESCE(MAX(CHARACTER_MAXIMUM_LENGTH), 0) FROM information_schema.COLUMNS
                                     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'nc_files' AND COLUMN_NAME = 'stored_name'")->fetchColumn();
            if ($len > 0 && $len < 64) {
                $pdo->exec('ALTER TABLE nc_files MODIFY stored_name VARCHAR(64) NOT NULL');
            }
            // schema 3: Tenor GIF desteği (gif_url kolonu + önbellek tablosu)
            $hasGifUrl = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS
                                           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'nc_messages' AND COLUMN_NAME = 'gif_url'")->fetchColumn();
            if ($hasGifUrl === 0) {
                $pdo->exec("ALTER TABLE nc_messages ADD COLUMN gif_url VARCHAR(300) NOT NULL DEFAULT ''");
            }
            // schema 4: kullanılmayan gif_key kolonu kaldırıldı
            $hasGifKey = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS
                                           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'nc_messages' AND COLUMN_NAME = 'gif_key'")->fetchColumn();
            if ($hasGifKey > 0) {
                $pdo->exec('ALTER TABLE nc_messages DROP COLUMN gif_key');
            }
            $pdo->exec("CREATE TABLE IF NOT EXISTS nc_cache (
                k CHAR(64) NOT NULL,
                v MEDIUMTEXT NOT NULL,
                expires BIGINT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (k)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->prepare("INSERT INTO nc_settings (k, v) VALUES ('schema_ver', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)")
                ->execute([$schemaVersion]);
        } catch (Throwable $e) {
            // migrasyon başarısız olsa da site çalışmaya devam eder
        }
    }

    if ($needsCreate) {
        $defaults = nc_default_settings();
        $stmt = $pdo->prepare('INSERT IGNORE INTO nc_settings (k, v) VALUES (?, ?)');
        foreach ($defaults as $k => $v) {
            $stmt->execute([$k, (string)$v]);
        }
    }

    // Yükleme klasörünü ve güvenlik dosyalarını hazırla
    $dirs = [NC_ROOT . '/uploads'];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
    }
    $uploadHtaccess = NC_ROOT . '/uploads/.htaccess';
    $uploadRules = "# Yüklenen dosyalara DOĞRUDAN erişim tamamen kapalıdır.\n"
        . "# Dosyalar yalnızca api.php?action=file üzerinden, oturum doğrulamasıyla sunulur.\n"
        . "Options -Indexes -ExecCGI\n"
        . "<IfModule mod_php.c>\n  php_flag engine off\n</IfModule>\n"
        . "<IfModule mod_php7.c>\n  php_flag engine off\n</IfModule>\n"
        . "<IfModule mod_php8.c>\n  php_flag engine off\n</IfModule>\n"
        . "RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .php8 .phar .cgi .pl .py .sh\n"
        . "RemoveType .php .phtml .php3 .php4 .php5 .php7 .php8 .phar\n"
        . "AddType text/plain .php .phtml .php3 .php4 .php5 .php7 .php8 .phar\n"
        . "<FilesMatch \"\\..*\">\n  Require all denied\n</FilesMatch>\n"
        . "<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n";
    if (!is_file($uploadHtaccess) || strpos((string)@file_get_contents($uploadHtaccess), 'DOĞRUDAN') === false) {
        @file_put_contents($uploadHtaccess, $uploadRules);
    }
    $uploadIndex = NC_ROOT . '/uploads/index.html';
    if (!is_file($uploadIndex)) {
        @file_put_contents($uploadIndex, '<!doctype html><title>403</title>');
    }
}

function nc_db(): PDO
{
    if ($GLOBALS['NC_DB'] instanceof PDO) {
        return $GLOBALS['NC_DB'];
    }
    $c = $GLOBALS['NC_CONFIG']['db'];
    $dbName = (string)$c['name'];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $dbName)) {
        nc_db_error_page('Geçersiz veritabanı adı.');
    }
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_STRINGIFY_FETCHES  => false,
    ];
    try {
        $dsn = 'mysql:host=' . $c['host'] . ';port=' . (int)$c['port'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, (string)$c['user'], (string)$c['pass'], $options);
        $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . $dbName . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo->exec('USE `' . $dbName . '`');
        nc_install($pdo);
        $GLOBALS['NC_DB'] = $pdo;
        return $pdo;
    } catch (Throwable $e) {
        nc_db_error_page($e->getMessage());
        exit;
    }
}

/* ============================================================
   AYARLAR / LOGLAR / THROTTLE
   ============================================================ */

function nc_default_settings(): array
{
    return [
        'site_name'           => 'NovaChat',
        'chat_enabled'        => '1',
        'uploads_enabled'     => '1',
        'gifs_enabled'        => '1',
        'games_enabled'       => '1',
        'maintenance'         => '0',
        'cooldown_ms'         => '3000',
        'max_upload_mb'       => '80',
        'ip_quota_gb'         => '5',
        'msg_max_len'         => '500',
        'announcement'        => '',
        'click_rate'          => '20',
        'cps_multiplier'      => '100',
        'notify_mentions'     => '1',
    ];
}

function nc_settings(): array
{
    if (is_array($GLOBALS['NC_SETTINGS'])) {
        return $GLOBALS['NC_SETTINGS'];
    }
    $rows = nc_db()->query('SELECT k, v FROM nc_settings')->fetchAll();
    $out = nc_default_settings();
    foreach ($rows as $r) {
        $out[(string)$r['k']] = (string)$r['v'];
    }
    $GLOBALS['NC_SETTINGS'] = $out;
    return $out;
}

function nc_setting(string $key, ?string $default = null): ?string
{
    $s = nc_settings();
    return array_key_exists($key, $s) ? (string)$s[$key] : $default;
}

function nc_set_setting(string $key, string $value): void
{
    if (!preg_match('/^[a-z0-9_]{1,50}$/', $key)) {
        return;
    }
    $stmt = nc_db()->prepare('INSERT INTO nc_settings (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)');
    $stmt->execute([$key, $value]);
    if (is_array($GLOBALS['NC_SETTINGS'])) {
        $GLOBALS['NC_SETTINGS'][$key] = $value;
    }
}

function nc_log(string $type, string $message, array $extra = [], ?int $userId = null, ?string $ip = null): void
{
    $data = $message;
    if ($extra) {
        $data .= ' | ' . json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    if (mb_strlen($data) > 4000) {
        $data = mb_substr($data, 0, 4000) . '…';
    }
    try {
        $stmt = nc_db()->prepare('INSERT INTO nc_logs (type, data, user_id, ip, created_at) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute([$type, $data, $userId, $ip ?? nc_client_ip(), time()]);
    } catch (Throwable $e) {
        // Log yazımı asla ana akışı bozmasın
    }
}

function nc_throttle(string $bucket, int $max, int $window): bool
{
    $pdo = nc_db();
    $key = hash('sha256', $bucket);
    $now = time();
    if (random_int(1, 150) === 1) {
        try {
            $pdo->prepare('DELETE FROM nc_throttle WHERE created_at < ?')->execute([$now - 86400]);
        } catch (Throwable $e) {
        }
    }
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM nc_throttle WHERE bucket = ? AND created_at > ?');
    $stmt->execute([$key, $now - $window]);
    if ((int)$stmt->fetchColumn() >= $max) {
        return false;
    }
    $pdo->prepare('INSERT INTO nc_throttle (bucket, created_at) VALUES (?, ?)')->execute([$key, $now]);
    return true;
}

/* ============================================================
   CSRF
   ============================================================ */

function nc_csrf_token(): string
{
    if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function nc_csrf_rotate(): string
{
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function nc_csrf_check(): void
{
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? ''));
    if ($token === '' || !hash_equals(nc_csrf_token(), $token)) {
        nc_fail('Güvenlik doğrulaması başarısız oldu (CSRF). Sayfayı yenileyip tekrar dene.', 403);
    }
}

/* ============================================================
   KULLANICI / OTURUM / BENİ HATIRLA
   ============================================================ */

function nc_touch_user(int $userId): void
{
    $now = time();
    nc_db()->prepare('UPDATE nc_users SET last_seen = ? WHERE id = ?')->execute([$now, $userId]);
    if (isset($GLOBALS['NC_USER']['id']) && (int)$GLOBALS['NC_USER']['id'] === $userId) {
        $GLOBALS['NC_USER']['last_seen'] = $now;
    }
}

function nc_cookie_options(int $expires): array
{
    return [
        'expires'  => $expires,
        'path'     => '/',
        'secure'   => nc_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
}

function nc_remember_clear_cookie(): void
{
    if (!headers_sent()) {
        setcookie('NCREMEMBER', '', nc_cookie_options(time() - 3600));
    }
    unset($_COOKIE['NCREMEMBER']);
}

function nc_remember_issue(int $userId): void
{
    $selector = bin2hex(random_bytes(16));
    $token    = bin2hex(random_bytes(32));
    $days     = max(1, (int)($GLOBALS['NC_CONFIG']['app']['session_days'] ?? 30));
    $expires  = time() + $days * 86400;

    $stmt = nc_db()->prepare('UPDATE nc_users SET remember_selector = ?, remember_hash = ?, remember_expires = ? WHERE id = ?');
    $stmt->execute([$selector, hash('sha256', $token), $expires, $userId]);

    if (!headers_sent()) {
        setcookie('NCREMEMBER', $selector . ':' . $token, nc_cookie_options($expires));
    }
    $_COOKIE['NCREMEMBER'] = $selector . ':' . $token;
}

function nc_remember_clear(int $userId): void
{
    nc_db()->prepare('UPDATE nc_users SET remember_selector = ?, remember_hash = ?, remember_expires = ? WHERE id = ?')
        ->execute(['', '', 0, $userId]);
    nc_remember_clear_cookie();
}

function nc_login_user(array $user): void
{
    if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
        if (!isset($_SESSION['uid']) || (int)$_SESSION['uid'] !== (int)$user['id']) {
            session_regenerate_id(true);
        }
    }
    $_SESSION['uid']      = (int)$user['id'];
    $_SESSION['login_at'] = time();
    nc_csrf_rotate();
    nc_remember_issue((int)$user['id']);
    nc_touch_user((int)$user['id']);
}

function nc_logout_user(): void
{
    $uid = (int)($_SESSION['uid'] ?? 0);
    if ($uid > 0) {
        nc_log('logout', 'Kullanıcı çıkış yaptı', [], $uid);
        nc_db()->prepare('UPDATE nc_users SET remember_selector = ?, remember_hash = ?, remember_expires = ?, typing_at = 0 WHERE id = ?')
            ->execute(['', '', 0, $uid]);
    }
    nc_remember_clear_cookie();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $p['path'] ?: '/',
            'domain'   => $p['domain'] ?: '',
            'secure'   => (bool)$p['secure'],
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

function nc_user(): ?array
{
    if ($GLOBALS['NC_USER_DONE']) {
        return $GLOBALS['NC_USER'] instanceof stdClass ? null : $GLOBALS['NC_USER'];
    }
    $GLOBALS['NC_USER_DONE'] = true;

    $uid = (int)($_SESSION['uid'] ?? 0);
    if ($uid > 0) {
        $stmt = nc_db()->prepare('SELECT * FROM nc_users WHERE id = ? LIMIT 1');
        $stmt->execute([$uid]);
        $u = $stmt->fetch();
        if ($u) {
            $GLOBALS['NC_USER'] = $u;
            return $u;
        }
        unset($_SESSION['uid']);
    }

    // Oturum yok: kalıcı çerezle otomatik giriş
    $raw = $_COOKIE['NCREMEMBER'] ?? '';
    if (!is_string($raw) || $raw === '' || strpos($raw, ':') === false) {
        return null;
    }
    [$selector, $token] = explode(':', $raw, 2);
    if (!preg_match('/^[a-f0-9]{32}$/', $selector) || !preg_match('/^[a-f0-9]{64}$/', $token)) {
        nc_remember_clear_cookie();
        return null;
    }
    $stmt = nc_db()->prepare('SELECT * FROM nc_users WHERE remember_selector = ? LIMIT 1');
    $stmt->execute([$selector]);
    $u = $stmt->fetch();
    if (!$u
        || (int)$u['remember_expires'] < time()
        || !hash_equals((string)$u['remember_hash'], hash('sha256', $token))) {
        nc_remember_clear_cookie();
        return null;
    }
    if ((int)$u['is_banned'] === 1) {
        // Banlı kullanıcı otomatik giriş yapamaz; ban sayfasında bilgilendirilir.
        return null;
    }
    nc_login_user($u);
    nc_log('login_remember', 'Çerez ile otomatik giriş', ['username' => $u['username']], (int)$u['id']);
    $GLOBALS['NC_USER'] = $u;
    return $u;
}

function nc_is_admin(): bool
{
    if (empty($_SESSION['is_admin'])) {
        return false;
    }
    if (time() - (int)($_SESSION['admin_at'] ?? 0) > 7200) {
        unset($_SESSION['is_admin'], $_SESSION['admin_at']);
        return false;
    }
    return true;
}

function nc_admin_touch(): void
{
    if (nc_is_admin()) {
        $_SESSION['admin_at'] = time();
    }
}

function nc_require_admin(): void
{
    if (!nc_is_admin()) {
        nc_fail('Yetkisiz istek. Admin girişi gerekiyor.', 401);
    }
    nc_admin_touch();
}

function nc_verify_admin_pass(string $pass): bool
{
    $hash = (string)($GLOBALS['NC_CONFIG']['admin_pass_hash'] ?? '');
    return $hash !== '' && password_verify($pass, $hash);
}

/* ============================================================
   BAN / KORUMA
   ============================================================ */

function nc_ip_banned(string $ip): bool
{
    static $cache = [];
    if (array_key_exists($ip, $cache)) {
        return $cache[$ip];
    }
    $stmt = nc_db()->prepare('SELECT 1 FROM nc_ip_bans WHERE ip = ? AND (expires = 0 OR expires > ?) LIMIT 1');
    $stmt->execute([$ip, time()]);
    return $cache[$ip] = (bool)$stmt->fetchColumn();
}

function nc_require_user(): array
{
    if (nc_ip_banned(nc_client_ip())) {
        nc_fail('IP adresiniz bu siteden engellenmiş.', 403, ['ip_banned' => true]);
    }
    if ((int)nc_setting('maintenance', '0') === 1 && !nc_is_admin()) {
        nc_fail('Site bakım modunda. Kısa süre sonra tekrar dene.', 503, ['maintenance' => true]);
    }
    $u = nc_user();
    if (!$u) {
        nc_fail('Oturum bulunamadı. Lütfen tekrar giriş yap.', 401, ['logout' => true]);
    }
    if ((int)$u['is_banned'] === 1) {
        nc_fail('Hesabın askıya alınmış. Sebep: ' . ((string)$u['ban_reason'] !== '' ? (string)$u['ban_reason'] : 'belirtilmedi'), 403, ['banned' => true]);
    }
    return $u;
}

function nc_block_page(string $title, string $message, int $code = 403): void
{
    http_response_code($code);
    if (!headers_sent()) {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
    }
    $site = nc_h(nc_safe_setting('site_name', 'NovaChat'));
    echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . nc_h($title) . ' • ' . $site . '</title>';
    echo '<link rel="icon" href="assets/favicon.png"><style>'
        . ':root{color-scheme:dark}*{box-sizing:border-box}'
        . 'body{margin:0;min-height:100vh;display:grid;place-items:center;background:radial-gradient(1200px 800px at 20% 0%,#1b1440,#0b0d17 55%,#05060c);color:#eceef8;font-family:"Segoe UI",system-ui,-apple-system,sans-serif;padding:24px;overflow:hidden}'
        . '.orb{position:fixed;border-radius:50%;filter:blur(70px);opacity:.35;animation:float 14s ease-in-out infinite}'
        . '.o1{width:340px;height:340px;background:#7c3aed;top:-80px;left:-60px}'
        . '.o2{width:300px;height:300px;background:#06b6d4;bottom:-90px;right:-40px;animation-delay:-6s}'
        . '@keyframes float{0%,100%{transform:translate3d(0,0,0)}50%{transform:translate3d(30px,-40px,0)}}'
        . 'main{position:relative;max-width:520px;width:100%;background:rgba(18,21,40,.72);border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:36px;backdrop-filter:blur(18px);box-shadow:0 30px 80px rgba(0,0,0,.55);animation:pop .5s cubic-bezier(.2,1.3,.4,1)}'
        . '@keyframes pop{from{opacity:0;transform:scale(.94) translateY(12px)}to{opacity:1;transform:none}}'
        . '.ico{font-size:46px;filter:drop-shadow(0 6px 18px rgba(124,58,237,.5))}'
        . 'h1{margin:14px 0 8px;font-size:24px;letter-spacing:-.02em}'
        . 'p{color:#a8adc9;line-height:1.65;margin:0 0 22px}'
        . 'a.btn{display:inline-flex;align-items:center;gap:8px;text-decoration:none;color:#fff;font-weight:600;padding:12px 20px;border-radius:14px;background:linear-gradient(135deg,#7c3aed,#06b6d4);box-shadow:0 10px 30px rgba(124,58,237,.45);transition:.25s}'
        . 'a.btn:hover{transform:translateY(-2px);box-shadow:0 16px 40px rgba(124,58,237,.6)}'
        . '.brand{display:flex;align-items:center;gap:10px;margin-bottom:18px;font-weight:700;letter-spacing:.02em}'
        . '.dot{width:10px;height:10px;border-radius:50%;background:linear-gradient(135deg,#22d3ee,#a78bfa);box-shadow:0 0 12px #22d3ee}'
        . '</style></head><body><div class="orb o1"></div><div class="orb o2"></div><main>'
        . '<div class="brand"><span class="dot"></span>' . $site . '</div>'
        . '<div class="ico">⛔</div><h1>' . nc_h($title) . '</h1><p>' . nl2br($message) . '</p>'
        . '<a class="btn" href="/">← Siteye dön</a></main></body></html>';
    exit;
}

function nc_safe_setting(string $key, string $fallback): string
{
    try {
        $v = nc_setting($key, $fallback);
        return $v === null ? $fallback : $v;
    } catch (Throwable $e) {
        return $fallback;
    }
}

function nc_guard_page(): array
{
    $ip = nc_client_ip();
    if (nc_ip_banned($ip)) {
        nc_block_page('IP Adresi Engellendi', 'Bu IP adresinden siteye erişim engellenmiş.\nIP: <strong>' . nc_h($ip) . '</strong>', 403);
    }
    if ((int)nc_setting('maintenance', '0') === 1 && !nc_is_admin()) {
        nc_block_page('Bakım Çalışması', 'Site şu anda bakım modunda. Kısa bir süre sonra tekrar deneyebilirsin. 🔧', 503);
    }
    $u = nc_user();
    if (!$u) {
        header('Location: index.php');
        exit;
    }
    if ((int)$u['is_banned'] === 1) {
        $reason = (string)$u['ban_reason'] !== '' ? (string)$u['ban_reason'] : 'Belirtilmedi';
        nc_block_page(
            'Hesabın Askıya Alındı',
            'Hesabın bir yönetici tarafından banlandı.<br><br><strong>Sebep:</strong> ' . nc_h($reason) . '<br><strong>Kullanıcı adı:</strong> ' . nc_h($u['username']),
            403
        );
    }
    nc_touch_user((int)$u['id']);
    return $u;
}

function nc_logout_redirect(): void
{
    nc_logout_user();
    header('Location: index.php');
    exit;
}

/* ============================================================
   KULLANICI ADI / MESAJ / DOSYA YARDIMCILARI
   ============================================================ */

function nc_username_valid(string $name): bool
{
    if (!preg_match('/^[\p{L}\p{N}_]{3,20}$/u', $name)) {
        return false;
    }
    $reserved = ['admin', 'administrator', 'yonetici', 'yönetici', 'sistem', 'system', 'moderator', 'mod', 'root', 'nova', 'novachat', 'sunucu'];
    return !in_array(mb_strtolower($name, 'UTF-8'), $reserved, true);
}

function nc_http_get(string $url, int $timeout = 9): ?string
{
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_ENCODING       => '',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS,
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_HTTPHEADER     => ['Accept: text/html,application/xhtml+xml', 'Accept-Language: tr,en;q=0.8'],
        ]);
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($body !== false && $code === 200) ? (string)$body : null;
    }
    if (!ini_get('allow_url_fopen')) {
        return null;
    }
    $ctx = stream_context_create([
        'http' => [
            'method'        => 'GET',
            'timeout'       => $timeout,
            'user_agent'    => $ua,
            'header'        => "Accept: text/html,application/xhtml+xml\r\nAccept-Language: tr,en;q=0.8\r\n",
            'ignore_errors' => false,
        ],
        'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    return is_string($body) && $body !== '' ? $body : null;
}

/**
 * Tenor sayfasındaki gömülü "store-cache" JSON'undan GIF listesini çıkarır.
 * (Resmî Tenor API'si 30 Haziran 2026'da kapatıldığı için canlı web araması kullanılır.)
 */
function nc_tenor_parse(string $html): array
{
    if ($html === '' || !preg_match('~<script id="store-cache"[^>]*>(.*?)</script>~s', $html, $m)) {
        return [];
    }
    $data = json_decode($m[1], true);
    if (!is_array($data)) {
        return [];
    }

    $pools = [];
    if (!empty($data['universal']['search']) && is_array($data['universal']['search'])) {
        foreach ($data['universal']['search'] as $bucket) {
            if (!empty($bucket['results']) && is_array($bucket['results'])) {
                $pools[] = $bucket['results'];
            }
        }
    }
    if (!empty($data['gifs']['featured']['results']) && is_array($data['gifs']['featured']['results'])) {
        $pools[] = $data['gifs']['featured']['results'];
    }
    if (!empty($data['gifs']['search']) && is_array($data['gifs']['search'])) {
        foreach ($data['gifs']['search'] as $bucket) {
            if (!empty($bucket['results']) && is_array($bucket['results'])) {
                $pools[] = $bucket['results'];
            }
        }
    }
    if (!$pools) {
        return [];
    }
    $pool = count($pools) > 1 ? array_merge(...$pools) : $pools[0];

    $out = [];
    $seen = [];
    foreach ($pool as $r) {
        if (!is_array($r)) {
            continue;
        }
        $id = (string)($r['id'] ?? '');
        if ($id === '' || isset($seen[$id])) {
            continue;
        }
        $mf = isset($r['media_formats']) && is_array($r['media_formats']) ? $r['media_formats'] : [];
        $full = (string)($mf['gif']['url'] ?? '');
        if ($full === '') {
            $full = (string)($mf['mediumgif']['url'] ?? '');
        }
        if ($full === '' || !nc_gif_url_valid($full)) {
            continue;
        }
        $tiny = (string)($mf['tinygif']['url'] ?? '');
        if ($tiny === '' || !nc_gif_url_valid($tiny)) {
            $tiny = (string)($mf['tinywebp']['url'] ?? '');
        }
        if ($tiny === '' || !nc_gif_url_valid($tiny)) {
            $tiny = $full;
        }
        $dims = $mf['gif']['dims'] ?? [0, 0];
        $seen[$id] = 1;
        $out[] = [
            'id'    => $id,
            'url'   => $full,
            'tiny'  => $tiny,
            'w'     => (int)($dims[0] ?? 0),
            'h'     => (int)($dims[1] ?? 0),
            'title' => mb_substr((string)($r['title'] ?? ''), 0, 80),
        ];
        if (count($out) >= 48) {
            break;
        }
    }
    return $out;
}

/**
 * Tenor'da canlı GIF arar (sunucu tarafı, önbellekli).
 * Boş sorgu → öne çıkanlar (trending).
 */
function nc_tenor_search(string $query, int $limit = 30): array
{
    $query = trim((string)preg_replace('/\s+/u', ' ', nc_clean_text($query)) ?? '');
    $query = mb_substr($query, 0, 40);
    $limit = max(1, min(48, $limit));
    $cacheKey = 'tenor:' . md5('tr|' . mb_strtolower($query, 'UTF-8'));
    $now = time();
    $stale = null;

    try {
        $stmt = nc_db()->prepare('SELECT v, expires FROM nc_cache WHERE k = ? LIMIT 1');
        $stmt->execute([$cacheKey]);
        $row = $stmt->fetch();
        if ($row) {
            $items = json_decode((string)$row['v'], true);
            if (is_array($items)) {
                $stale = $items;
                if ((int)$row['expires'] > $now) {
                    return ['ok' => true, 'items' => array_slice($items, 0, $limit), 'cached' => true, 'query' => $query];
                }
            }
        }
    } catch (Throwable $e) {
        $stale = null;
    }

    // Kontrol karakterlerini temizle, ardından tek segmentlik güvenli bir slug üret
    $safe = preg_replace('/[\x00-\x1F\x7F]+/u', '', mb_strtolower($query, 'UTF-8')) ?? '';
    $safe = trim(preg_replace('/\s+/u', '-', trim($safe)) ?? '', '-');
    $slug = $safe === '' ? '' : rawurlencode($safe) . '-gifs';
    $url = $slug === '' ? 'https://tenor.com/tr/' : 'https://tenor.com/tr/search/' . $slug;
    $html = nc_http_get($url);
    $items = $html !== null ? nc_tenor_parse($html) : [];

    if (!$items && $query === '') {
        // Ana sayfa boş dönerse popüler sorguya düş
        $html = nc_http_get('https://tenor.com/tr/search/pop%C3%BCler-gifs');
        $items = $html !== null ? nc_tenor_parse($html) : [];
    }

    if (!$items) {
        if (is_array($stale) && $stale) {
            return ['ok' => true, 'items' => array_slice($stale, 0, $limit), 'cached' => true, 'stale' => true, 'query' => $query];
        }
        return ['ok' => false, 'error' => 'Tenor şu anda yanıt vermedi. İnternet bağlantını kontrol edip tekrar dene.', 'query' => $query];
    }

    try {
        $json = json_encode($items, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        $stmt = nc_db()->prepare('INSERT INTO nc_cache (k, v, expires) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v), expires = VALUES(expires)');
        $stmt->execute([$cacheKey, (string)$json, $now + 900]);
        if (random_int(1, 40) === 1) {
            nc_db()->prepare('DELETE FROM nc_cache WHERE expires < ?')->execute([$now - 604800]);
        }
    } catch (Throwable $e) {
        // önbellek yazılamasa da sonuç döner
    }

    return ['ok' => true, 'items' => array_slice($items, 0, $limit), 'cached' => false, 'query' => $query];
}

function nc_gif_url_valid(string $url): bool
{
    if ($url === '' || strlen($url) > 300) {
        return false;
    }
    if (!preg_match('#^https://#i', $url)) {
        return false;
    }
    // Kontrol karakteri, boşluk, ters bölü ve dizin atlama girişimlerini reddet
    $len = strlen($url);
    for ($i = 0; $i < $len; $i++) {
        $o = ord($url[$i]);
        if ($o <= 0x20 || $o === 0x7f || $url[$i] === '\\') {
            return false;
        }
    }
    if (strpos($url, '..') !== false) {
        return false;
    }
    $parts = parse_url($url);
    if (!is_array($parts)) {
        return false;
    }
    $host = strtolower((string)($parts['host'] ?? ''));
    if ($host === '' || !preg_match('/^(?:[a-z0-9-]+\.)*tenor\.com$/', $host)) {
        return false;
    }
    $path = (string)($parts['path'] ?? '');
    if (!preg_match('/\.(gif|webp|mp4|webm)$/i', $path)) {
        return false;
    }
    return true;
}

function nc_quota_used(string $ip): int
{
    $stmt = nc_db()->prepare('SELECT COALESCE(SUM(size), 0) FROM nc_files WHERE ip = ?');
    $stmt->execute([$ip]);
    return (int)$stmt->fetchColumn();
}

function nc_quota_limit_bytes(): int
{
    return max(1, (int)nc_setting('ip_quota_gb', '5')) * 1024 * 1024 * 1024;
}

function nc_snippet(string $text, int $len = 90): string
{
    $text = trim(preg_replace('/\s+/u', ' ', $text) ?? '');
    if ($text === '') {
        return '';
    }
    return mb_strlen($text) > $len ? mb_substr($text, 0, $len) . '…' : $text;
}

function nc_message_sql(): string
{
    return "SELECT m.id, m.user_id, m.body, m.reply_to, m.file_id, m.gif_url, m.deleted, m.created_at,
                   u.username AS username,
                   rf.id AS rf_id, rf.body AS rf_body, rf.deleted AS rf_deleted, rf.gif_url AS rf_gif_url, rf.reply_to AS rf_reply,
                   ru.username AS rf_username,
                   f.id AS f_id, f.orig_name AS f_name, f.mime AS f_mime, f.size AS f_size
            FROM nc_messages m
            LEFT JOIN nc_users u ON u.id = m.user_id
            LEFT JOIN nc_messages rf ON rf.id = m.reply_to
            LEFT JOIN nc_users ru ON ru.id = rf.user_id
            LEFT JOIN nc_files f ON f.id = m.file_id";
}

function nc_message_view(array $r): array
{
    $reply = null;
    if (!empty($r['rf_id'])) {
        $reply = [
            'id'       => (int)$r['rf_id'],
            'username' => $r['rf_username'] !== null ? (string)$r['rf_username'] : 'silinmiş',
            'body'     => nc_snippet((string)$r['rf_body'], 80),
            'deleted'  => (int)$r['rf_deleted'] === 1,
        ];
        if ($reply['body'] === '' && (string)($r['rf_gif_url'] ?? '') !== '') {
            $reply['body'] = '🎁 GIF';
        }
    }
    $file = null;
    if (!empty($r['f_id'])) {
        $mime = (string)$r['f_mime'];
        $file = [
            'id'       => (int)$r['f_id'],
            'name'     => (string)$r['f_name'],
            'size'     => (int)$r['f_size'],
            'size_txt' => nc_format_bytes((float)$r['f_size']),
            'is_image' => (bool)preg_match('#^image/(jpeg|png|gif|webp)$#', $mime),
            'is_video' => (bool)preg_match('#^video/(mp4|webm|quicktime)$#', $mime),
            'is_audio' => (bool)preg_match('#^audio/(mpeg|ogg|wav|x-wav|mp4|x-m4a)$#', $mime),
        ];
    }
    $gifUrl = (string)($r['gif_url'] ?? '');
    $gif = ($gifUrl !== '' && nc_gif_url_valid($gifUrl))
        ? ['url' => $gifUrl, 'label' => 'GIF']
        : null;

    return [
        'id'       => (int)$r['id'],
        'uid'      => (int)$r['user_id'],
        'username' => $r['username'] !== null ? (string)$r['username'] : null,
        'body'     => (int)$r['deleted'] === 1 ? '' : (string)$r['body'],
        'ts'       => (int)$r['created_at'],
        'deleted'  => (int)$r['deleted'] === 1,
        'reply'    => $reply,
        'file'     => $file,
        'gif'      => $gif,
    ];
}

/* ============================================================
   OYUN (SUNUCU TARAFI CLICKER)
   ============================================================ */

function nc_game_buildings_def(): array
{
    return [
        1  => ['İmleç',             '👆', 15,           0.1],
        2  => ['Büyükanne',         '👵', 100,          1],
        3  => ['Çiftlik',           '🚜', 1100,         8],
        4  => ['Maden',             '⛏️', 12000,        47],
        5  => ['Fabrika',           '🏭', 130000,       260],
        6  => ['Banka',             '🏦', 1400000,      1400],
        7  => ['Tapınak',           '🛕', 20000000,     7800],
        8  => ['Gökdelen',          '🏙️', 330000000,    44000],
        9  => ['Uzay İstasyonu',    '🛰️', 5100000000,   260000],
        10 => ['Kuantum Çekirdek',  '⚛️', 75000000000,  1600000],
    ];
}

function nc_game_counts($buildingsJson): array
{
    $data = json_decode((string)$buildingsJson, true);
    $counts = [];
    if (is_array($data)) {
        foreach (nc_game_buildings_def() as $id => $_) {
            if (isset($data[$id]) && is_numeric($data[$id])) {
                $counts[$id] = max(0, (int)$data[$id]);
            }
        }
    }
    return $counts;
}

function nc_game_cost(int $buildingId, int $owned): float
{
    $defs = nc_game_buildings_def();
    if (!isset($defs[$buildingId])) {
        return 0.0;
    }
    return $defs[$buildingId][2] * pow(1.15, max(0, $owned));
}

function nc_game_bulk_cost(int $buildingId, int $owned, int $amount): float
{
    $total = 0.0;
    $amount = max(0, min($amount, 500));
    for ($i = 0; $i < $amount; $i++) {
        $total += nc_game_cost($buildingId, $owned + $i);
    }
    return nc_num($total);
}

function nc_game_click_cost(int $level): float
{
    return nc_num(50 * pow(1.9, max(0, $level - 1)));
}

function nc_game_click_power(int $level): int
{
    return 1 + 2 * max(0, $level - 1);
}

function nc_game_cps_from_counts(array $counts): float
{
    $total = 0.0;
    foreach (nc_game_buildings_def() as $id => $def) {
        $total += ($counts[$id] ?? 0) * $def[3];
    }
    return $total;
}

function nc_game_multiplier(): float
{
    $m = (int)nc_setting('cps_multiplier', '100');
    $m = max(10, min(1000, $m));
    return $m / 100;
}

function nc_game_cps(array $row): float
{
    return nc_num(nc_game_cps_from_counts(nc_game_counts($row['buildings'])) * nc_game_multiplier());
}

function nc_game_apply_ticks(array &$row): array
{
    $now = time();
    $last = (int)$row['last_tick'];
    $elapsed = max(0, min($now - $last, 2592000)); // en fazla 30 gün
    $cps = nc_game_cps($row);
    $gain = nc_num($cps * $elapsed);
    $row['cookies'] = nc_num((float)$row['cookies'] + $gain);
    $row['total_earned'] = nc_num((float)$row['total_earned'] + $gain);
    $row['last_tick'] = $now;
    return ['elapsed' => $elapsed, 'gain' => $gain, 'cps' => $cps];
}

function nc_game_get(int $userId, bool $create = true): array
{
    $pdo = nc_db();
    if ($create) {
        $now = time();
        $pdo->prepare('INSERT IGNORE INTO nc_game (user_id, buildings, last_tick, tokens, tokens_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)')
            ->execute([$userId, '{}', $now, 30, microtime(true), $now]);
    }
    $stmt = $pdo->prepare('SELECT * FROM nc_game WHERE user_id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if (!$row) {
        return [
            'user_id' => $userId, 'cookies' => 0.0, 'total_earned' => 0.0, 'clicks' => 0,
            'click_level' => 1, 'buildings' => '{}', 'last_tick' => time(),
            'tokens' => 30.0, 'tokens_at' => microtime(true), 'updated_at' => time(),
        ];
    }
    return $row;
}

function nc_game_save(array $row): void
{
    nc_db()->prepare('UPDATE nc_game SET cookies = ?, total_earned = ?, clicks = ?, click_level = ?, buildings = ?, last_tick = ?, tokens = ?, tokens_at = ?, updated_at = ? WHERE user_id = ?')
        ->execute([
            nc_num((float)$row['cookies']),
            nc_num((float)$row['total_earned']),
            max(0, (int)$row['clicks']),
            max(1, (int)$row['click_level']),
            (string)$row['buildings'],
            (int)$row['last_tick'],
            nc_num((float)$row['tokens']),
            (float)$row['tokens_at'],
            time(),
            (int)$row['user_id'],
        ]);
}

function nc_game_leaderboard(int $limit = 10): array
{
    $limit = max(1, min(100, $limit));
    $sql = "SELECT u.id, u.username,
                   COALESCE(g.total_earned, 0) AS score,
                   COALESCE(g.cookies, 0) AS cookies,
                   COALESCE(g.clicks, 0) AS clicks,
                   COALESCE(g.click_level, 1) AS click_level
            FROM nc_users u
            LEFT JOIN nc_game g ON g.user_id = u.id
            WHERE u.is_banned = 0
            ORDER BY COALESCE(g.total_earned, 0) DESC, u.id ASC
            LIMIT " . $limit;
    $rows = nc_db()->query($sql)->fetchAll();
    $out = [];
    $pos = 0;
    foreach ($rows as $r) {
        $pos++;
        $out[] = [
            'pos'         => $pos,
            'id'          => (int)$r['id'],
            'username'    => (string)$r['username'],
            'score'       => nc_num((float)$r['score']),
            'cookies'     => nc_num((float)$r['cookies']),
            'clicks'      => (int)$r['clicks'],
            'click_level' => (int)$r['click_level'],
        ];
    }
    return $out;
}

function nc_game_rank(int $userId, float $score): int
{
    $stmt = nc_db()->prepare('SELECT COUNT(*) + 1 FROM nc_game g JOIN nc_users u ON u.id = g.user_id WHERE g.total_earned > ? AND u.is_banned = 0');
    $stmt->execute([$score]);
    $rank = (int)$stmt->fetchColumn();
    if ($rank <= 1) {
        // Kendisi lider olabilir; yine de gerçek sırayı hesapla
        $stmt2 = nc_db()->prepare('SELECT COUNT(*) FROM nc_game g JOIN nc_users u ON u.id = g.user_id WHERE u.is_banned = 0 AND (g.total_earned > ? OR (g.total_earned = ? AND g.user_id < ?))');
        $stmt2->execute([$score, $score, $userId]);
        $rank = (int)$stmt2->fetchColumn() + 1;
    }
    return $rank;
}

function nc_game_payload(int $userId, array $row, int $awaySeconds = 0, float $awayGain = 0.0): array
{
    $counts = nc_game_counts($row['buildings']);
    $defs = nc_game_buildings_def();
    $mult = nc_game_multiplier();
    $buildings = [];
    $cps = 0.0;
    foreach ($defs as $id => $def) {
        $count = $counts[$id] ?? 0;
        $baseCps = $def[3] * $mult;
        $buildings[] = [
            'id'       => $id,
            'name'     => $def[0],
            'emoji'    => $def[1],
            'count'    => $count,
            'cost'     => nc_num(nc_game_cost($id, $count)),
            'cost10'   => nc_num(nc_game_bulk_cost($id, $count, 10)),
            'cps'      => nc_num($baseCps),
            'cps_total'=> nc_num($count * $baseCps),
        ];
        $cps += $count * $baseCps;
    }
    $level = max(1, (int)$row['click_level']);
    $clickCost = nc_num(nc_game_click_cost($level));
    $cps = nc_num($cps);

    return [
        'cookies'      => nc_num((float)$row['cookies']),
        'total_earned' => nc_num((float)$row['total_earned']),
        'clicks'       => (int)$row['clicks'],
        'click_level'  => $level,
        'click_power'  => nc_game_click_power($level),
        'click_cost'   => $clickCost,
        'cps'          => $cps,
        'tokens'       => max(0, (int)floor((float)$row['tokens'])),
        'buildings'    => $buildings,
        'multiplier'   => $mult,
        'rank'         => nc_game_rank($userId, (float)$row['total_earned']),
        'leaderboard'  => nc_game_leaderboard(10),
        'away_seconds' => $awaySeconds,
        'away_gain'    => nc_num($awayGain),
        'server_time'  => time(),
    ];
}

/* ============================================================
   CONFIG YAZMA
   ============================================================ */

function nc_write_config(array $config): bool
{
    $file = NC_ROOT . '/config.php';
    if (!is_file($file) || !is_writable($file)) {
        return false;
    }
    $code = "<?php\n/**\n * NovaChat - Yapılandırma (admin panelinden güncellenebilir)\n */\n\nreturn " . var_export($config, true) . ";\n";
    $tmp = $file . '.tmp';
    if (@file_put_contents($tmp, $code, LOCK_EX) === false) {
        return false;
    }
    return @rename($tmp, $file);
}

function nc_set_admin_password(string $newPassword): bool
{
    $hash = password_hash($newPassword, PASSWORD_BCRYPT);
    if ($hash === false) {
        return false;
    }
    $config = $GLOBALS['NC_CONFIG'];
    $config['admin_pass_hash'] = $hash;
    if (!nc_write_config($config)) {
        return false;
    }
    $GLOBALS['NC_CONFIG'] = $config;
    return true;
}
