#!/usr/bin/env bash
# NovaChat'i release icin paketler: uploads/ haric temiz bir ZIP uretir.
set -euo pipefail
VER="${1:-1.0.0}"
OUT="novachat-v${VER}.zip"
rm -f "$OUT"
cd "$(dirname "$0")/../.."
zip -rq "$OUT" novachat \
  -x "novachat/uploads/*.dat" \
  -x "novachat/.git/*" \
  -x "*/.DS_Store"
echo "Olusturuldu: $(pwd)/$OUT ($(du -h "$OUT" | cut -f1))"
unzip -l "$OUT" | tail -3
