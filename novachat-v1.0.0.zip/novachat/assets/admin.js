/* ==========================================================================
   NovaChat - Yönetim paneli istemcisi
   Paneldeki her işlem sunucuda nc_require_admin() ile korunur.
   ========================================================================== */
'use strict';

(() => {
    if (document.body.dataset.page !== 'admin') return;

    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    let CSRF = csrfMeta ? csrfMeta.content : '';

    const A = {
        tab: 'dashboard',
        users: { q: '', page: 1 },
        messages: { q: '', filter: 'all', page: 1 },
        files: { page: 1 },
        logs: { type: '', page: 1 },
        settings: null,
        server: null,
        user: null
    };

    /* ---------------- yardımcılar ---------------- */

    function api(action, opts = {}) {
        let url = 'api.php?action=' + encodeURIComponent(action);
        const init = {
            method: opts.method || 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-CSRF-Token': CSRF },
            cache: 'no-store'
        };
        if (opts.data) {
            init.method = 'POST';
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(opts.data);
        }
        return fetch(url, init).then(async (res) => {
            let j = null;
            try { j = await res.json(); } catch (e) { j = null; }
            if (res.status === 401 && !(j && j.error && j.error.indexOf('şifre') >= 0)) {
                // admin oturumu düşmüş
                setTimeout(() => location.href = 'adminlol.php', 600);
            }
            if (!res.ok || !j || j.ok === false) {
                const err = new Error((j && j.error) || ('Sunucu hatası (' + res.status + ')'));
                err.status = res.status;
                err.payload = j || {};
                throw err;
            }
            return j;
        });
    }

    function h(tag, cls, text) {
        const e = document.createElement(tag);
        if (cls) e.className = cls;
        if (text !== undefined && text !== null) e.textContent = String(text);
        return e;
    }

    function toast(title, text = '', kind = 'info', ttl = 4000) {
        const root = $('#toastRoot');
        if (!root) return;
        const icons = { info: '💬', success: '✅', error: '⚠️' };
        const el = document.createElement('div');
        el.className = 'toast ' + kind;
        const ico = h('span', 'toast-ico', icons[kind] || icons.info);
        const bodyEl = h('div', 'toast-body');
        bodyEl.appendChild(h('strong', 'toast-title', title));
        if (text) bodyEl.appendChild(h('span', 'toast-text', text));
        el.append(ico, bodyEl);
        root.appendChild(el);
        while (root.children.length > 4) root.removeChild(root.firstElementChild);
        const dismiss = () => { el.classList.add('out'); setTimeout(() => el.remove(), 320); };
        setTimeout(dismiss, ttl);
    }

    function fmtBytes(b) {
        b = Number(b) || 0;
        const u = ['B', 'KB', 'MB', 'GB', 'TB'];
        let i = 0;
        while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
        return (i === 0 ? Math.round(b) : b.toFixed(2).replace('.', ',')) + ' ' + u[i];
    }

    const UNITS = [[1e3, 'B'], [1e6, 'Mn'], [1e9, 'Mr'], [1e12, 'Tn'], [1e15, 'Kt'], [1e18, 'Kn']];
    function fmtNum(n) {
        n = Number(n) || 0;
        if (n < 1000) return String(Math.floor(n));
        for (let i = UNITS.length - 1; i >= 0; i--) {
            if (n >= UNITS[i][0]) {
                const v = n / UNITS[i][0];
                return (v >= 100 ? Math.round(v) : v.toFixed(1).replace('.', ',')) + ' ' + UNITS[i][1];
            }
        }
        return String(Math.floor(n));
    }

    function fmtDate(ts) {
        if (!ts) return '—';
        return new Date(ts * 1000).toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' });
    }

    function fmtAgo(ts) {
        if (!ts) return '—';
        const diff = Math.max(0, Math.floor(Date.now() / 1000) - ts);
        if (diff < 60) return diff + ' sn önce';
        if (diff < 3600) return Math.floor(diff / 60) + ' dk önce';
        if (diff < 86400) return Math.floor(diff / 3600) + ' sa önce';
        return Math.floor(diff / 86400) + ' gün önce';
    }

    function avatarColor(el, name) {
        let hsh = 0;
        for (const ch of String(name || '?')) hsh = (hsh * 31 + ch.codePointAt(0)) % 360;
        el.style.background = `linear-gradient(135deg, hsl(${hsh} 85% 62%), hsl(${(hsh + 65) % 360} 85% 52%))`;
        el.style.boxShadow = `0 4px 12px hsl(${hsh} 80% 40% / .4), inset 0 0 0 1px rgba(255,255,255,.14)`;
        el.textContent = String(name || '?').slice(0, 1).toUpperCase();
    }

    function td(content, cls) {
        const cell = document.createElement('td');
        if (cls) cell.className = cls;
        if (content instanceof Node) cell.appendChild(content);
        else cell.textContent = content === undefined || content === null ? '' : String(content);
        return cell;
    }

    function b(text, kind) {
        return h('span', 'b' + (kind ? ' ' + kind : ''), text);
    }

    function emptyRow(tbody, cols, text) {
        tbody.innerHTML = '';
        const tr = document.createElement('tr');
        const cell = td(text || 'Kayıt yok', 'table-empty');
        cell.colSpan = cols;
        tr.appendChild(cell);
        tbody.appendChild(tr);
    }

    function pager(container, page, pages, cb) {
        if (!container) return;
        container.innerHTML = '';
        if (!pages || pages <= 1) return;
        const mk = (label, p, active, disabled) => {
            const btn = h('button', null, label);
            btn.type = 'button';
            if (active) btn.classList.add('active');
            btn.disabled = !!disabled;
            btn.addEventListener('click', () => cb(p));
            return btn;
        };
        container.appendChild(mk('‹', Math.max(1, page - 1), false, page <= 1));
        const start = Math.max(1, page - 2);
        const end = Math.min(pages, start + 4);
        if (start > 1) container.appendChild(mk('1', 1, page === 1));
        if (start > 2) container.appendChild(h('span', null, '…'));
        for (let i = start; i <= end; i++) container.appendChild(mk(String(i), i, i === page));
        if (end < pages - 1) container.appendChild(h('span', null, '…'));
        if (end < pages) container.appendChild(mk(String(pages), pages, page === pages));
        container.appendChild(mk('›', Math.min(pages, page + 1), false, page >= pages));
    }

    function openModal(el) { if (el) el.classList.remove('hidden'); }
    function closeModal(el) { if (el) el.classList.add('hidden'); }

    function confirmDialog(title, text, okLabel = 'Onayla') {
        const modal = $('#confirmModal');
        const cfTitle = $('#cfTitle');
        const cfText = $('#cfText');
        const cfOk = $('#cfOk');
        const cfCancel = $('#cfCancel');
        cfTitle.textContent = title;
        cfText.textContent = text;
        cfOk.textContent = okLabel;
        openModal(modal);

        return new Promise((resolve) => {
            const done = (val) => {
                cleanup();
                closeModal(modal);
                resolve(val);
            };
            const onOk = () => done(true);
            const onCancel = () => done(false);
            const onBackdrop = (e) => { if (e.target.classList.contains('modal-backdrop')) done(false); };
            const onKey = (e) => { if (e.key === 'Escape') done(false); };
            function cleanup() {
                cfOk.removeEventListener('click', onOk);
                cfCancel.removeEventListener('click', onCancel);
                modal.removeEventListener('click', onBackdrop);
                document.removeEventListener('keydown', onKey);
            }
            cfOk.addEventListener('click', onOk);
            cfCancel.addEventListener('click', onCancel);
            modal.addEventListener('click', onBackdrop);
            document.addEventListener('keydown', onKey);
        });
    }

    /* ---------------- sekmeler ---------------- */

    const loaders = {
        dashboard: loadDashboard,
        users: () => loadUsers(A.users.page),
        messages: () => loadMessages(A.messages.page),
        files: () => loadFiles(A.files.page),
        ipbans: loadIpBans,
        game: loadGame,
        logs: () => loadLogs(A.logs.page),
        settings: loadSettings,
        security: loadSecurity
    };

    function switchTab(name) {
        if (!loaders[name]) return;
        A.tab = name;
        $$('#adminNav button').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === name));
        $$('.admin-tab').forEach(panel => panel.classList.toggle('active', panel.dataset.tabPanel === name));
        loaders[name]();
    }

    /* ---------------- dashboard ---------------- */

    async function loadDashboard() {
        const grid = $('#statGrid');
        try {
            const j = await api('admin_stats');
            A.settings = j.settings;
            A.server = j.server;
            renderStats(grid, j.stats);
            renderRecentLogs(j.logs);
            renderTopPlayers(j.top);
            renderServerInfo(j.server);
            renderSession(j.server.session_until);
        } catch (e) {
            toast('Veriler alınamadı', e.message, 'error', 5000);
        }
    }

    function statCard(icon, label, value, note) {
        const card = h('div', 'stat-card');
        const top = h('div', 'sc-top');
        top.append(h('span', null, icon), document.createTextNode(label));
        const val = h('strong', 'sc-value', value);
        card.append(top, val);
        if (note) card.appendChild(h('span', 'sc-note', note));
        return card;
    }

    function renderStats(grid, s) {
        if (!grid) return;
        grid.innerHTML = '';
        grid.append(
            statCard('👥', 'Kullanıcı', String(s.users), s.online + ' çevrimiçi'),
            statCard('💬', 'Mesaj', fmtNum(s.messages), 'bugün ' + s.messages_today),
            statCard('📁', 'Dosya', String(s.files), fmtBytes(s.storage) + ' depolama'),
            statCard('🚫', 'Ban', String(s.banned), s.ipbans + ' IP banı'),
            statCard('🍪', 'Oyuncu', String(s.players), fmtNum(s.total_earned) + ' toplam kurabiye')
        );
    }

    function prettyLog(data) {
        const raw = String(data || '');
        const idx = raw.indexOf(' | {');
        if (idx === -1) return raw;
        const msg = raw.slice(0, idx);
        let obj = null;
        try { obj = JSON.parse(raw.slice(idx + 3)); } catch (e) { return raw; }
        if (!obj || typeof obj !== 'object') return raw;
        const parts = Object.keys(obj).map(k => k + ': ' + String(obj[k]));
        return msg + (parts.length ? ' · ' + parts.join(' · ') : '');
    }

    function logClass(type) {
        if (/ban|fail|delete|clear|block|denied/i.test(type)) return 't-bad';
        if (/login|register|unban|restore/i.test(type)) return 't-ok';
        return '';
    }

    function renderRecentLogs(logs) {
        const box = $('#recentLogs');
        if (!box) return;
        box.innerHTML = '';
        if (!logs || !logs.length) {
            box.appendChild(h('p', 'muted small', 'Henüz kayıt yok.'));
            return;
        }
        logs.forEach(l => {
            const row = h('div', 'log-item');
            row.append(
                h('span', 'log-type ' + logClass(l.type), l.type),
                h('span', 'log-text', prettyLog(l.data)),
                h('span', 'log-time', fmtAgo(l.ts))
            );
            box.appendChild(row);
        });
    }

    function renderTopPlayers(top) {
        const list = $('#topPlayers');
        if (!list) return;
        list.innerHTML = '';
        if (!top || !top.length) {
            list.appendChild(h('li', 'lb-empty', 'Henüz oyuncu yok.'));
            return;
        }
        top.forEach((p, i) => {
            const li = h('li', 'lb-item');
            li.append(h('span', 'lb-pos', String(p.pos || i + 1)), h('span', 'lb-name', p.username), h('span', 'lb-score', fmtNum(p.score)));
            list.appendChild(li);
        });
    }

    function renderServerInfo(srv) {
        const box = $('#serverInfo');
        if (!box) return;
        box.innerHTML = '';
        const rows = [
            ['PHP sürümü', srv.php],
            ['Sunucu', srv.software || '—'],
            ['Veritabanı', srv.db],
            ['upload_max_filesize', srv.upload_max],
            ['post_max_size', srv.post_max],
            ['config.php yazılabilir', srv.config_writable ? 'evet ✓' : 'hayır ✕']
        ];
        rows.forEach(([k, v]) => {
            const row = h('div', 'kv');
            row.append(h('span', null, k), h('strong', null, v));
            box.appendChild(row);
        });
    }

    let sessionUntil = 0;
    function renderSession(until) {
        sessionUntil = Number(until) || 0;
        updateSessionLabel();
    }

    function updateSessionLabel() {
        const el = $('#adminSession');
        if (!el || !sessionUntil) return;
        const remain = Math.max(0, sessionUntil - Math.floor(Date.now() / 1000));
        const hh = Math.floor(remain / 3600);
        const mm = Math.floor((remain % 3600) / 60);
        el.textContent = 'oturum: ' + hh + 's ' + String(mm).padStart(2, '0') + 'd';
        if (remain === 0) el.textContent = 'oturum doldu';
    }

    /* ---------------- kullanıcılar ---------------- */

    async function loadUsers(page) {
        const tbody = $('#usersTable tbody');
        if (!tbody) return;
        tbody.innerHTML = '';
        const tr = document.createElement('tr');
        const cell = td('Yükleniyor…', 'table-empty');
        cell.colSpan = 8;
        tr.appendChild(cell);
        tbody.appendChild(tr);
        try {
            const j = await api('admin_users', { data: { q: A.users.q, page } });
            A.users.page = j.page;
            tbody.innerHTML = '';
            if (!j.users.length) { emptyRow(tbody, 8, 'Kullanıcı bulunamadı.'); }
            j.users.forEach(u => tbody.appendChild(userRow(u)));
            pager($('#usersPager'), j.page, j.pages, (p) => { A.users.page = p; loadUsers(p); });
        } catch (e) {
            emptyRow(tbody, 8, 'Yüklenemedi: ' + e.message);
        }
    }

    function userRow(u) {
        const tr = document.createElement('tr');

        const cellUser = document.createElement('td');
        const wrap = h('div', 'u-cell');
        const av = h('span', 'avatar');
        avatarColor(av, u.username);
        const info = h('div');
        info.append(h('strong', null, u.username), h('small', 'mono', '#' + u.id));
        wrap.append(av, info);
        cellUser.appendChild(wrap);

        const cellIp = document.createElement('td');
        cellIp.appendChild(h('span', 'mono', u.ip));

        const cellStatus = document.createElement('td');
        if (u.is_banned) cellStatus.appendChild(b('banlı', 'bad'));
        else if (u.online) cellStatus.appendChild(b('çevrimiçi', 'ok'));
        else cellStatus.appendChild(b('çevrimdışı', 'off'));
        if (u.muted_until * 1000 > Date.now()) cellStatus.appendChild(b('susturulmuş', 'warn'));

        const cellMsg = td(String(u.msg_count));
        const cellUp = td(fmtBytes(u.up_bytes));
        const cellScore = td(fmtNum(u.total_earned));
        const cellSeen = td(u.online ? 'şimdi' : fmtAgo(u.last_seen), 'mono');

        const cellAct = document.createElement('td');
        const manage = h('button', 'tbtn', 'Yönet');
        manage.type = 'button';
        manage.addEventListener('click', () => openUserModal(u));
        cellAct.appendChild(manage);

        tr.append(cellUser, cellIp, cellStatus, cellMsg, cellUp, cellScore, cellSeen, cellAct);
        return tr;
    }

    function openUserModal(u) {
        A.user = u;
        const modal = $('#userModal');
        const title = $('#umTitle');
        const bodyBox = $('#umBody');
        title.textContent = u.username;
        bodyBox.innerHTML = '';

        const head = h('div', 'um-head');
        const av = h('span', 'avatar');
        avatarColor(av, u.username);
        const idBox = h('div', 'um-id');
        idBox.append(h('strong', null, u.username), h('span', null, '#' + u.id + ' · ' + u.ip));
        const badges = h('div', 'um-badges');
        if (u.is_banned) badges.appendChild(b('banlı', 'bad'));
        if (u.online) badges.appendChild(b('çevrimiçi', 'ok'));
        if (u.muted_until * 1000 > Date.now()) badges.appendChild(b('susturulmuş', 'warn'));
        head.append(av, idBox, badges);

        const grid = h('div', 'um-grid');
        const rows = [
            ['Kayıt', fmtDate(u.created_at)],
            ['Son görülme', u.online ? 'şimdi çevrimiçi' : fmtDate(u.last_seen)],
            ['Mesaj sayısı', String(u.msg_count)],
            ['Dosya yüklemesi', fmtBytes(u.up_bytes)],
            ['Kurabiye', fmtNum(u.cookies)],
            ['Toplam kazanç', fmtNum(u.total_earned)],
            ['Tıklama', fmtNum(u.clicks)],
            ['Tıklama seviyesi', String(u.click_level)],
            ['Susturma bitişi', u.muted_until * 1000 > Date.now() ? fmtDate(u.muted_until) : '—'],
            ['Ban sebebi', u.ban_reason || '—']
        ];
        rows.forEach(([k, v]) => {
            const row = h('div', 'um-row');
            row.append(h('span', null, k), h('strong', null, v));
            grid.appendChild(row);
        });

        bodyBox.append(head, grid, h('div', 'um-section', 'İşlem alanları'));

        const fields = h('div', 'um-fields');
        const reasonIn = h('input');
        reasonIn.type = 'text';
        reasonIn.maxLength = 200;
        reasonIn.placeholder = 'Ban / IP ban sebebi';
        reasonIn.value = u.ban_reason || '';
        const minutesIn = h('input');
        minutesIn.type = 'number';
        minutesIn.min = '1';
        minutesIn.max = '525600';
        minutesIn.value = '10';
        const ipIn = h('input');
        ipIn.type = 'text';
        ipIn.maxLength = 45;
        ipIn.value = u.ip;

        const f1 = h('label', null, 'Sebep');
        f1.appendChild(reasonIn);
        const f2 = h('label', null, 'Süre (dakika)');
        f2.appendChild(minutesIn);
        const f3 = h('label', null, 'IP adresi');
        f3.appendChild(ipIn);
        fields.append(f1, f2, f3);

        const actions = h('div', 'um-actions');

        const act = async (op, extra = {}) => {
            const data = Object.assign({
                uid: u.id,
                op,
                reason: reasonIn.value.trim(),
                minutes: Number(minutesIn.value) || 10,
                ip: ipIn.value.trim()
            }, extra);
            try {
                await api('admin_user_action', { method: 'POST', data });
                toast('İşlem tamam', 'Kullanıcı: ' + u.username, 'success', 2500);
                closeModal(modal);
                loadUsers(A.users.page);
                if (A.tab === 'dashboard') loadDashboard();
            } catch (e) {
                toast('İşlem başarısız', e.message, 'error', 4500);
            }
        };

        const mk = (label, cls, handler) => {
            const btn = h('button', null, label);
            btn.type = 'button';
            if (cls) btn.classList.add(cls);
            btn.addEventListener('click', handler);
            return btn;
        };

        if (u.is_banned) {
            actions.appendChild(mk('Banı kaldır', 'ok', () => act('unban')));
        } else {
            actions.appendChild(mk('Banla', 'bad', () => act('ban')));
        }
        if (u.muted_until * 1000 > Date.now()) {
            actions.appendChild(mk('Susturmayı kaldır', 'ok', () => act('unmute')));
        } else {
            actions.appendChild(mk('Sustur', null, () => act('mute')));
        }
        actions.appendChild(mk('IP güncelle', null, () => act('setip')));
        actions.appendChild(mk('Bu IP\'yi banla', 'bad', async () => {
            const ip = ipIn.value.trim();
            if (!ip) { toast('IP boş', 'Önce bir IP gir.', 'error', 2500); return; }
            const ok = await confirmDialog('IP banı', ip + ' adresi ' + (Number(minutesIn.value) || 10) + ' dakika boyunca banlanacak. Onaylıyor musun?', 'IP banla');
            if (!ok) return;
            try {
                await api('admin_ipban', { method: 'POST', data: { ip, reason: reasonIn.value.trim(), minutes: Number(minutesIn.value) || 0 } });
                toast('IP banlandı', ip, 'success', 3000);
                closeModal(modal);
                if (A.tab === 'ipbans') loadIpBans();
            } catch (e) {
                toast('IP banlanamadı', e.message, 'error', 4000);
            }
        }));
        actions.appendChild(mk('Oyunu sıfırla', null, async () => {
            if (!await confirmDialog('Oyun verisi', u.username + ' adlı kullanıcının oyun verisi sıfırlanacak. Emin misin?', 'Sıfırla')) return;
            act('resetgame');
        }));
        actions.appendChild(mk('Kullanıcıyı sil', 'bad', async () => {
            if (!await confirmDialog('Kullanıcıyı sil', u.username + ' kalıcı olarak silinecek. Mesajları arşivde kalır, dosyaları ve oyun verisi silinir. Bu işlem geri alınamaz.', 'Kalıcı sil')) return;
            act('delete');
        }));

        bodyBox.append(fields, actions);
        openModal(modal);
    }

    /* ---------------- mesajlar ---------------- */

    async function loadMessages(page) {
        const tbody = $('#messagesTable tbody');
        if (!tbody) return;
        emptyRow(tbody, 7, 'Yükleniyor…');
        try {
            const j = await api('admin_messages', {
                data: { q: A.messages.q, filter: A.messages.filter, page }
            });
            A.messages.page = j.page;
            tbody.innerHTML = '';
            if (!j.messages.length) emptyRow(tbody, 7, 'Mesaj bulunamadı.');
            j.messages.forEach(m => {
                const tr = document.createElement('tr');
                tr.append(
                    td(String(m.id), 'mono'),
                    td(m.username || 'silinmiş'),
                    td(m.ip || '—', 'mono')
                );
                const msgCell = document.createElement('td');
                msgCell.className = 'msg-cell' + (m.deleted ? ' deleted' : '');
                let text = m.body || '';
                if (m.gif) text += (text ? ' ' : '') + '🎁 [GIF' + (m.gif === 'tenor' ? ' · Tenor' : '') + ']';
                if (m.file_name) text += (text ? ' ' : '') + '📎 ' + m.file_name + ' (' + fmtBytes(m.file_size) + ')';
                msgCell.textContent = text || '—';
                tr.appendChild(msgCell);
                tr.append(
                    td(fmtDate(m.ts), 'mono'),
                    td(m.deleted ? 'silinmiş' : 'aktif')
                );
                const actCell = document.createElement('td');
                const btn = h('button', 'tbtn' + (m.deleted ? '' : ' bad'), m.deleted ? 'Geri getir' : 'Sil');
                btn.type = 'button';
                btn.addEventListener('click', async () => {
                    try {
                        await api('admin_msg_action', { method: 'POST', data: { id: m.id, op: m.deleted ? 'restore' : 'delete' } });
                        toast(m.deleted ? 'Mesaj geri getirildi' : 'Mesaj silindi', '#' + m.id, 'success', 2200);
                        loadMessages(A.messages.page);
                    } catch (e) {
                        toast('İşlem başarısız', e.message, 'error', 3500);
                    }
                });
                actCell.appendChild(btn);
                tr.appendChild(actCell);

                const statusCell = tr.children[5];
                statusCell.innerHTML = '';
                statusCell.appendChild(m.deleted ? b('silinmiş', 'bad') : b('aktif', 'ok'));

                tbody.appendChild(tr);
            });
            pager($('#messagesPager'), j.page, j.pages, (p) => { A.messages.page = p; loadMessages(p); });
        } catch (e) {
            emptyRow(tbody, 7, 'Yüklenemedi: ' + e.message);
        }
    }

    /* ---------------- dosyalar ---------------- */

    async function loadFiles(page) {
        const tbody = $('#filesTable tbody');
        if (!tbody) return;
        emptyRow(tbody, 8, 'Yükleniyor…');
        try {
            const j = await api('admin_files', { data: { page } });
            A.files.page = j.page;
            tbody.innerHTML = '';
            if (!j.files.length) emptyRow(tbody, 8, 'Dosya yok.');
            j.files.forEach(f => {
                const tr = document.createElement('tr');
                tr.append(td(String(f.id), 'mono'), td(f.name), td(f.mime, 'mono'), td(f.size_txt), td(f.username || 'silinmiş'), td(f.ip, 'mono'), td(fmtDate(f.ts), 'mono'));
                const cell = document.createElement('td');
                const btn = h('button', 'tbtn bad', 'Sil');
                btn.type = 'button';
                btn.addEventListener('click', async () => {
                    if (!await confirmDialog('Dosyayı sil', f.name + ' dosyası kalıcı olarak silinecek. Emin misin?', 'Sil')) return;
                    try {
                        await api('admin_file_delete', { method: 'POST', data: { id: f.id } });
                        toast('Dosya silindi', f.name, 'success', 2500);
                        loadFiles(A.files.page);
                    } catch (e) {
                        toast('Silinemedi', e.message, 'error', 3500);
                    }
                });
                cell.appendChild(btn);
                tr.appendChild(cell);
                tbody.appendChild(tr);
            });
            pager($('#filesPager'), j.page, j.pages, (p) => { A.files.page = p; loadFiles(p); });
            renderPerIp(j.per_ip);
        } catch (e) {
            emptyRow(tbody, 8, 'Yüklenemedi: ' + e.message);
        }
    }

    function renderPerIp(list) {
        const box = $('#perIpList');
        if (!box) return;
        box.innerHTML = '';
        if (!list || !list.length) {
            box.appendChild(h('p', 'muted small', 'Henüz dosya yüklenmemiş.'));
            return;
        }
        list.forEach(row => {
            const wrap = h('div', 'ip-quota');
            const ip = h('span', 'ip-name', row.ip);
            const bar = h('div', 'ip-bar');
            const fill = h('div');
            fill.style.width = Math.min(100, Number(row.percent) || 0) + '%';
            bar.appendChild(fill);
            const meta = h('span', 'ip-meta', row.count + ' dosya · ' + row.bytes_txt + ' (%' + row.percent + ')');
            wrap.append(ip, bar, meta);
            box.appendChild(wrap);
        });
    }

    /* ---------------- IP banları ---------------- */

    async function loadIpBans() {
        const tbody = $('#ipBansTable tbody');
        if (!tbody) return;
        emptyRow(tbody, 6, 'Yükleniyor…');
        try {
            const j = await api('admin_ipbans');
            tbody.innerHTML = '';
            if (!j.bans.length) emptyRow(tbody, 6, 'Banlı IP yok.');
            j.bans.forEach(ban => {
                const tr = document.createElement('tr');
                tr.append(
                    td(ban.ip, 'mono'),
                    td(ban.reason || '—'),
                    td(fmtDate(ban.created_at), 'mono'),
                    td(ban.expires ? fmtDate(ban.expires) : 'süresiz', 'mono')
                );
                const status = td('');
                status.appendChild(ban.active ? b('aktif', 'bad') : b('süresi dolmuş', 'off'));
                tr.appendChild(status);
                const cell = document.createElement('td');
                const btn = h('button', 'tbtn', 'Kaldır');
                btn.type = 'button';
                btn.addEventListener('click', async () => {
                    try {
                        await api('admin_ipunban', { method: 'POST', data: { id: ban.id } });
                        toast('Ban kaldırıldı', ban.ip, 'success', 2500);
                        loadIpBans();
                    } catch (e) {
                        toast('Kaldırılamadı', e.message, 'error', 3500);
                    }
                });
                cell.appendChild(btn);
                tr.appendChild(cell);
                tbody.appendChild(tr);
            });
        } catch (e) {
            emptyRow(tbody, 6, 'Yüklenemedi: ' + e.message);
        }
    }

    /* ---------------- oyun ---------------- */

    async function loadGame() {
        const tbody = $('#gameTable tbody');
        if (!tbody) return;
        emptyRow(tbody, 8, 'Yükleniyor…');
        try {
            const j = await api('admin_game');
            tbody.innerHTML = '';
            const statBox = $('#gameAdminStats');
            if (statBox) {
                statBox.innerHTML = '';
                const players = j.game.length;
                const total = j.game.reduce((acc, r) => acc + (Number(r.total_earned) || 0), 0);
                const clicks = j.game.reduce((acc, r) => acc + (Number(r.clicks) || 0), 0);
                [['Oyuncu', players], ['Toplam kazanç', fmtNum(total)], ['Toplam tıklama', fmtNum(clicks)]].forEach(([k, v]) => {
                    const box = h('div', 'ga-stat');
                    box.append(h('strong', null, String(v)), document.createTextNode(k));
                    statBox.appendChild(box);
                });
            }
            if (!j.game.length) emptyRow(tbody, 8, 'Oyun verisi yok.');
            j.game.forEach((p, i) => {
                const tr = document.createElement('tr');
                tr.append(
                    td(String(i + 1), 'mono'),
                    td(p.username + (p.is_banned ? ' (banlı)' : '')),
                    td(p.ip, 'mono'),
                    td(fmtNum(p.cookies)),
                    td(fmtNum(p.total_earned)),
                    td(fmtNum(p.clicks)),
                    td(String(p.click_level))
                );
                const cell = document.createElement('td');
                const btn = h('button', 'tbtn bad', 'Sıfırla');
                btn.type = 'button';
                btn.addEventListener('click', async () => {
                    if (!await confirmDialog('Oyun verisi', p.username + ' adlı oyuncunun verisi sıfırlanacak.', 'Sıfırla')) return;
                    try {
                        await api('admin_game_reset', { method: 'POST', data: { uid: p.id } });
                        toast('Sıfırlandı', p.username, 'success', 2500);
                        loadGame();
                    } catch (e) {
                        toast('Sıfırlanamadı', e.message, 'error', 3500);
                    }
                });
                cell.appendChild(btn);
                tr.appendChild(cell);
                tbody.appendChild(tr);
            });
        } catch (e) {
            emptyRow(tbody, 8, 'Yüklenemedi: ' + e.message);
        }
    }

    /* ---------------- loglar ---------------- */

    async function loadLogs(page) {
        const tbody = $('#logsTable tbody');
        if (!tbody) return;
        emptyRow(tbody, 6, 'Yükleniyor…');
        try {
            const j = await api('admin_logs', { data: { type: A.logs.type, page } });
            A.logs.page = j.page;
            tbody.innerHTML = '';
            if (!j.logs.length) emptyRow(tbody, 6, 'Log yok.');
            j.logs.forEach(l => {
                const tr = document.createElement('tr');
                const typeCell = td('');
                typeCell.appendChild(h('span', 'log-type ' + logClass(l.type), l.type));
                tr.append(td(String(l.id), 'mono'), typeCell, td(prettyLog(l.data)), td(l.username || '—'), td(l.ip, 'mono'), td(fmtDate(l.ts), 'mono'));
                tbody.appendChild(tr);
            });
            pager($('#logsPager'), j.page, j.pages, (p) => { A.logs.page = p; loadLogs(p); });
            const sel = $('#logTypeSelect');
            if (sel && sel.dataset.filled !== '1') {
                sel.dataset.filled = '1';
                sel.innerHTML = '';
                sel.appendChild(new Option('Tüm türler', ''));
                (j.types || []).forEach(t => sel.appendChild(new Option(t, t)));
                sel.value = A.logs.type;
            }
        } catch (e) {
            emptyRow(tbody, 6, 'Yüklenemedi: ' + e.message);
        }
    }

    /* ---------------- ayarlar ---------------- */

    const settingDefs = [
        {
            title: 'Genel',
            items: [
                { key: 'site_name', label: 'Site adı', desc: 'Sohbet başlığında ve sayfalarda görünür (max 30).', type: 'text' },
                { key: 'announcement', label: 'Duyuru', desc: 'Sohbetin üstünde gösterilir. Boş bırakırsan gizlenir.', type: 'textarea' },
                { key: 'chat_enabled', label: 'Sohbet açık', desc: 'Kapalıyken kimse mesaj gönderemez.', type: 'bool' },
                { key: 'games_enabled', label: 'Oyunlar açık', desc: 'Kurabiye oyununa erişimi kapatır.', type: 'bool' }
            ]
        },
        {
            title: 'Sohbet',
            items: [
                { key: 'cooldown_ms', label: 'Yavaş mod (ms)', desc: 'İki mesaj arası minimum süre. 0-60000.', type: 'number', min: 0, max: 60000 },
                { key: 'msg_max_len', label: 'Maks mesaj uzunluğu', desc: '50-2000 karakter.', type: 'number', min: 50, max: 2000 },
                { key: 'uploads_enabled', label: 'Dosya yükleme', desc: 'Kapalıyken dosya eklenemez.', type: 'bool' },
                { key: 'max_upload_mb', label: 'Maks dosya boyutu (MB)', desc: '1-80 MB arası.', type: 'number', min: 1, max: 80 }
            ]
        },
        {
            title: 'Dosya kotası & GIF',
            items: [
                { key: 'ip_quota_gb', label: 'IP başına kota (GB)', desc: 'Bir IP\'nin toplam yükleyebileceği boyut.', type: 'number', min: 1, max: 100 },
                { key: 'gifs_enabled', label: 'GIF gönderimi (Tenor)', desc: 'Sağ alttaki GIF düğmesini ve canlı Tenor aramasını kontrol eder.', type: 'bool' }
            ]
        },
        {
            title: 'Oyun',
            items: [
                { key: 'click_rate', label: 'Tıklama hakkı/sn', desc: 'Anti-makro limiti. 1-50.', type: 'number', min: 1, max: 50 },
                { key: 'cps_multiplier', label: 'CPS çarpanı (%)', desc: 'Bina üretim hızı. 100 = normal.', type: 'number', min: 10, max: 1000 }
            ]
        },
        {
            title: 'Sistem',
            items: [
                { key: 'maintenance', label: 'Bakım modu', desc: 'Açıkken sadece admin panele erişilir.', type: 'bool' }
            ]
        }
    ];

    async function loadSettings() {
        const box = $('#settingsForm');
        if (!box) return;
        try {
            const j = await api('admin_stats');
            A.settings = j.settings || {};
            A.server = j.server;
            renderSettings(box, A.settings);
            renderSession(j.server.session_until);
        } catch (e) {
            toast('Ayarlar yüklenemedi', e.message, 'error', 4500);
        }
    }

    function renderSettings(box, settings) {
        box.innerHTML = '';
        settingDefs.forEach(group => {
            const sec = h('section', 'settings-group' + (group.title === 'Genel' ? ' wide' : ''));
            sec.appendChild(h('h3', null, group.title));
            group.items.forEach(item => {
                const row = h('div', 'setting-row');
                const label = h('div', 'setting-label');
                label.append(h('strong', null, item.label), h('span', null, item.desc));
                const control = h('div', 'setting-control');
                let input;
                if (item.type === 'bool') {
                    const sw = h('label', 'switch');
                    input = document.createElement('input');
                    input.type = 'checkbox';
                    input.dataset.setting = item.key;
                    input.checked = String(settings[item.key]) === '1';
                    const track = h('span');
                    sw.append(input, track);
                    control.appendChild(sw);
                } else if (item.type === 'textarea') {
                    input = document.createElement('textarea');
                    input.dataset.setting = item.key;
                    input.maxLength = 300;
                    input.value = settings[item.key] || '';
                    control.appendChild(input);
                } else {
                    input = document.createElement('input');
                    input.type = item.type === 'number' ? 'number' : 'text';
                    input.dataset.setting = item.key;
                    if (item.type === 'number') {
                        if (item.min !== undefined) input.min = String(item.min);
                        if (item.max !== undefined) input.max = String(item.max);
                        input.value = settings[item.key] || '0';
                    } else {
                        input.maxLength = 30;
                        input.value = settings[item.key] || '';
                    }
                    control.appendChild(input);
                }
                row.append(label, control);
                sec.appendChild(row);
            });
            box.appendChild(sec);
        });

        const actions = h('div', 'settings-actions');
        const save = h('button', 'btn-primary small', '💾 Ayarları kaydet');
        save.type = 'button';
        save.addEventListener('click', saveSettings);
        actions.appendChild(save);
        box.appendChild(actions);
    }

    async function saveSettings() {
        const box = $('#settingsForm');
        if (!box) return;
        const data = {};
        $$('[data-setting]', box).forEach(input => {
            const key = input.dataset.setting;
            if (!key) return;
            if (input.type === 'checkbox') data[key] = input.checked ? '1' : '0';
            else data[key] = input.value;
        });
        try {
            const j = await api('admin_settings_save', { method: 'POST', data: { settings: data } });
            A.settings = j.settings;
            toast('Ayarlar kaydedildi', 'Değişiklikler anında geçerli.', 'success', 3000);
        } catch (e) {
            toast('Kaydedilemedi', e.message, 'error', 4500);
        }
    }

    /* ---------------- güvenlik ---------------- */

    async function loadSecurity() {
        const info = $('#securityInfo');
        if (!info) return;
        try {
            const j = await api('admin_stats');
            A.server = j.server;
            info.innerHTML = '';
            const rows = [
                ['Admin oturumu', 'aktif'],
                ['Oturum bitişi', fmtDate(j.server.session_until)],
                ['config.php', j.server.config_writable ? 'yazılabilir ✓ (şifre panelden değişebilir)' : 'yazılamıyor ✕ (izin ver)'],
                ['PHP', j.server.php],
                ['Veritabanı', j.server.db]
            ];
            rows.forEach(([k, v]) => {
                const row = h('div', 'kv');
                row.append(h('span', null, k), h('strong', null, v));
                info.appendChild(row);
            });
            renderSession(j.server.session_until);
        } catch (e) {
            toast('Bilgi alınamadı', e.message, 'error', 3500);
        }
    }

    /* ---------------- bağlama ---------------- */

    function bind() {
        const nav = $('#adminNav');
        nav && nav.addEventListener('click', (e) => {
            const btn = e.target.closest('button[data-tab]');
            if (btn) switchTab(btn.dataset.tab);
        });

        $('#refreshDashboard') && $('#refreshDashboard').addEventListener('click', loadDashboard);

        // kullanıcı arama
        const userForm = $('#userSearchForm');
        userForm && userForm.addEventListener('submit', (e) => {
            e.preventDefault();
            A.users.q = $('#userSearch').value.trim();
            A.users.page = 1;
            loadUsers(1);
        });
        $('#userSearchClear') && $('#userSearchClear').addEventListener('click', () => {
            $('#userSearch').value = '';
            A.users.q = '';
            A.users.page = 1;
            loadUsers(1);
        });

        // mesaj filtreleri
        const filters = $('#msgFilters');
        filters && filters.addEventListener('click', (e) => {
            const btn = e.target.closest('button[data-filter]');
            if (!btn) return;
            $$('button', filters).forEach(x => x.classList.toggle('active', x === btn));
            A.messages.filter = btn.dataset.filter;
            A.messages.page = 1;
            loadMessages(1);
        });
        const msgForm = $('#msgSearchForm');
        msgForm && msgForm.addEventListener('submit', (e) => {
            e.preventDefault();
            A.messages.q = $('#msgSearch').value.trim();
            A.messages.page = 1;
            loadMessages(1);
        });

        $('#chatClearBtn') && $('#chatClearBtn').addEventListener('click', async () => {
            if (!await confirmDialog('Sohbeti temizle', 'Tüm mesajlar silinecek (tek tek geri getirilebilir). Emin misin?', 'Temizle')) return;
            try {
                await api('admin_chat_clear', { method: 'POST', data: {} });
                toast('Sohbet temizlendi', '', 'success', 2500);
                loadMessages(1);
                loadDashboard();
            } catch (e) {
                toast('Temizlenemedi', e.message, 'error', 4000);
            }
        });

        // IP ban formu
        const ipForm = $('#ipBanForm');
        ipForm && ipForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const ip = $('#ipBanIp').value.trim();
            const minutes = Number($('#ipBanMinutes').value) || 0;
            const reason = $('#ipBanReason').value.trim();
            if (!ip) { toast('IP gerekli', 'Bir IP adresi gir.', 'error', 2500); return; }
            try {
                await api('admin_ipban', { method: 'POST', data: { ip, minutes, reason } });
                toast('IP banlandı', ip, 'success', 3000);
                ipForm.reset();
                $('#ipBanMinutes').value = '0';
                loadIpBans();
            } catch (e2) {
                toast('Banlanamadı', e2.message, 'error', 4000);
            }
        });

        $('#gameResetAll') && $('#gameResetAll').addEventListener('click', async () => {
            if (!await confirmDialog('Tüm oyun verisi', 'TÜM kullanıcıların kurabiye, bina ve yükseltmeleri silinecek. Bu işlem geri alınamaz!', 'Hepsini sıfırla')) return;
            try {
                await api('admin_game_reset', { method: 'POST', data: { all: '1' } });
                toast('Tüm oyun verileri sıfırlandı', '', 'success', 3000);
                loadGame();
                loadDashboard();
            } catch (e) {
                toast('Sıfırlanamadı', e.message, 'error', 4000);
            }
        });

        $('#logTypeSelect') && $('#logTypeSelect').addEventListener('change', (e) => {
            A.logs.type = e.target.value;
            A.logs.page = 1;
            loadLogs(1);
        });
        $('#logClearBtn') && $('#logClearBtn').addEventListener('click', async () => {
            const days = Number($('#logClearDays').value) || 30;
            if (!await confirmDialog('Logları temizle', days + ' günden eski loglar kalıcı olarak silinecek.', 'Temizle')) return;
            try {
                const j = await api('admin_logs_clear', { method: 'POST', data: { days } });
                toast('Loglar temizlendi', (j.deleted || 0) + ' kayıt silindi.', 'success', 3000);
                loadLogs(1);
            } catch (e) {
                toast('Temizlenemedi', e.message, 'error', 4000);
            }
        });

        $('#settingsSave') && $('#settingsSave').addEventListener('click', saveSettings);

        // şifre değiştirme
        const passForm = $('#passwordForm');
        passForm && passForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const current = $('#passCurrent').value;
            const next = $('#passNew').value;
            const next2 = $('#passNew2').value;
            if (next !== next2) { toast('Şifreler uyuşmuyor', 'Yeni şifreyi iki alana da aynı yaz.', 'error', 3500); return; }
            if (next.length < 6) { toast('Şifre çok kısa', 'En az 6 karakter olmalı.', 'error', 3000); return; }
            try {
                await api('admin_password', { method: 'POST', data: { current, new: next } });
                toast('Şifre güncellendi', 'config.php dosyasına yazıldı.', 'success', 4000);
                passForm.reset();
            } catch (e2) {
                toast('Şifre değiştirilemedi', e2.message, 'error', 5000);
            }
        });

        const doLogout = async () => {
            try { await api('admin_logout', { method: 'POST' }); } catch (e) {}
            location.href = 'adminlol.php';
        };
        $('#adminLogoutBtn') && $('#adminLogoutBtn').addEventListener('click', doLogout);
        $('#securityLogout') && $('#securityLogout').addEventListener('click', doLogout);

        // kullanıcı modalı kapatma
        $$('#userModal [data-close]').forEach(el => el.addEventListener('click', () => closeModal($('#userModal'))));

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal($('#userModal'));
        });
    }

    /* ---------------- başlat ---------------- */

    bind();
    loadDashboard();
    setInterval(updateSessionLabel, 30000);
    setInterval(() => {
        if (A.tab === 'dashboard' && !document.hidden) loadDashboard();
    }, 30000);
})();
