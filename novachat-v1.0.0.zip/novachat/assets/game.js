/* ==========================================================================
   NovaChat - Kurabiye İmparatorluğu istemcisi
   Tıklama, dükkân ve skor tablosu arayüzü. Tüm hesap sunucuda doğrulanır.
   ========================================================================== */
'use strict';

(() => {
    if (document.body.dataset.page !== 'game') return;

    const $ = (s, r = document) => r.querySelector(s);
    const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    let CSRF = csrfMeta ? csrfMeta.content : '';

    /* ---------------- yardımcılar ---------------- */

    function api(action, opts = {}) {
        let url = 'api.php?action=' + encodeURIComponent(action);
        const init = {
            method: opts.method || 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-CSRF-Token': CSRF },
            cache: 'no-store'
        };
        if (opts.data) {
            init.method = 'POST';
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(opts.data);
        }
        return fetch(url, init).then(async (res) => {
            let j = null;
            try { j = await res.json(); } catch (e) { j = null; }
            if (!res.ok || !j || j.ok === false) {
                const err = new Error((j && j.error) || ('Sunucu hatası (' + res.status + ')'));
                err.status = res.status;
                err.payload = j || {};
                throw err;
            }
            if (j.csrf) CSRF = j.csrf;
            return j;
        });
    }

    function authRedirect(err) {
        if (!err) return false;
        if (err.status === 401 || (err.payload && (err.payload.logout || err.payload.banned || err.payload.ip_banned))) {
            location.href = 'index.php';
            return true;
        }
        if (err.payload && err.payload.games_disabled) {
            location.href = 'chat.php';
            return true;
        }
        return false;
    }

    function toast(title, text = '', kind = 'info', ttl = 4000) {
        const root = $('#toastRoot');
        if (!root) return;
        const icons = { info: '💬', success: '✅', error: '⚠️' };
        const el = document.createElement('div');
        el.className = 'toast ' + kind;
        const ico = document.createElement('span');
        ico.className = 'toast-ico';
        ico.textContent = icons[kind] || icons.info;
        const bodyEl = document.createElement('div');
        bodyEl.className = 'toast-body';
        const t = document.createElement('strong');
        t.className = 'toast-title';
        t.textContent = title;
        bodyEl.appendChild(t);
        if (text) {
            const s = document.createElement('span');
            s.className = 'toast-text';
            s.textContent = text;
            bodyEl.appendChild(s);
        }
        el.append(ico, bodyEl);
        root.appendChild(el);
        while (root.children.length > 4) root.removeChild(root.firstElementChild);
        const dismiss = () => {
            el.classList.add('out');
            setTimeout(() => el.remove(), 320);
        };
        setTimeout(dismiss, ttl);
    }

    const UNITS = [
        [1e3, 'B'], [1e6, 'Mn'], [1e9, 'Mr'], [1e12, 'Tn'], [1e15, 'Kt'],
        [1e18, 'Kn'], [1e21, 'Sk'], [1e24, 'Sp'], [1e27, 'Ok'], [1e30, 'Nn']
    ];

    function fmt(n) {
        n = Number(n) || 0;
        if (!isFinite(n)) return '∞';
        const neg = n < 0 ? '-' : '';
        n = Math.abs(n);
        if (n < 1000) {
            if (Number.isInteger(n)) return neg + String(n);
            return neg + (n < 10 ? n.toFixed(1).replace('.', ',') : String(Math.floor(n)));
        }
        for (let i = UNITS.length - 1; i >= 0; i--) {
            const [v, u] = UNITS[i];
            if (n >= v) {
                const val = n / v;
                const txt = val >= 100 ? Math.round(val).toLocaleString('tr-TR') : val.toFixed(1).replace('.', ',');
                return neg + txt + ' ' + u;
            }
        }
        return neg + Math.floor(n).toLocaleString('tr-TR');
    }

    function fmtFull(n) {
        return (Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 0 });
    }

    function escapeHtmlUnused() { /* kasıtlı: verileri asla innerHTML'e basmıyoruz */ }

    function avatarColor(el, name) {
        let h = 0;
        for (const ch of String(name || '?')) h = (h * 31 + ch.codePointAt(0)) % 360;
        el.style.background = `linear-gradient(135deg, hsl(${h} 85% 62%), hsl(${(h + 65) % 360} 85% 52%))`;
        el.style.boxShadow = `0 6px 18px hsl(${h} 80% 40% / .45), inset 0 0 0 1px rgba(255,255,255,.14)`;
    }

    /* ---------------- durum ---------------- */

    const G = {
        cookies: 0,
        display: 0,
        cps: 0,
        clickPower: 1,
        clickLevel: 1,
        clickCost: 50,
        tokens: 30,
        tokenRate: 20,
        clicks: 0,
        totalEarned: 0,
        buildings: [],
        amount: 1,
        multiplier: 1,
        rank: 0,
        lb: [],
        meId: Number(document.body.dataset.uid) || 0,
        meName: document.body.dataset.username || '',
        pending: 0,
        flushTimer: null,
        sending: false,
        busy: false,
        lastLive: performance.now(),
        loaded: false,
        gameOver: false
    };

    const el = {
        cookie: $('#bigCookie'),
        coinCount: $('#cookieCount'),
        cps: $('#cpsCount'),
        power: $('#clickPower'),
        tokens: $('#tokenCount'),
        total: $('#totalEarned'),
        clicks: $('#clickTotal'),
        tokenFill: $('#tokenFill'),
        shop: $('#shopList'),
        buyToggle: $('#buyToggle'),
        clickLevel: $('#clickLevel'),
        clickCost: $('#clickUpgradeCost'),
        upgradeBtn: $('#buyClickUpgrade'),
        lb: $('#gameLb'),
        lbMe: $('#lbMe'),
        rankPill: $('#gameRankPill'),
        offline: $('#offlineModal'),
        offlineGain: $('#offlineGain'),
        offlineAway: $('#offlineAway'),
        clickLayer: $('#clickLayer'),
        confetti: $('#confetti'),
        logout: $('#gameLogout')
    };

    const wrap = el.cookie ? el.cookie.closest('.cookie-wrap') : null;

    /* ---------------- görünüm ---------------- */

    /* Saniyede 10 kez çağrılır: yalnızca gerçekten değişen metinlere dokunur,
       böylece gereksiz DOM yazımı ve yeniden çizim olmaz. */
    const statCache = {};
    function setText(node, key, value) {
        if (!node || statCache[key] === value) return;
        statCache[key] = value;
        node.textContent = value;
    }

    function updateStats() {
        if (el.coinCount) {
            setText(el.coinCount, 'coins', fmt(G.display));
            const title = fmtFull(G.display) + ' kurabiye';
            if (statCache.coinTitle !== title) {
                statCache.coinTitle = title;
                el.coinCount.title = title;
            }
        }
        setText(el.cps, 'cps', fmt(G.cps));
        setText(el.power, 'power', String(G.clickPower));
        setText(el.tokens, 'tokens', String(Math.floor(G.tokens)));
        setText(el.total, 'total', fmt(G.totalEarned));
        setText(el.clicks, 'clicks', fmtFull(G.clicks));
        if (el.tokenFill) {
            const cap = Math.max(1, G.tokenRate * 2);
            const width = Math.min(100, (G.tokens / cap) * 100) + '%';
            if (statCache.tokenFill !== width) {
                statCache.tokenFill = width;
                el.tokenFill.style.width = width;
            }
        }
        const chip = el.tokens ? el.tokens.closest('.stat-chip') : null;
        if (chip) {
            const low = G.tokens < 1;
            if (statCache.low !== low) {
                statCache.low = low;
                chip.classList.toggle('low', low);
            }
        }
        setText(el.clickLevel, 'clickLevel', String(G.clickLevel));
        setText(el.clickCost, 'clickCost', fmt(G.clickCost));
        if (el.upgradeBtn) {
            const disabled = G.display < G.clickCost || G.gameOver;
            if (statCache.upgradeDisabled !== disabled) {
                statCache.upgradeDisabled = disabled;
                el.upgradeBtn.disabled = disabled;
            }
        }
        if (el.rankPill) setText(el.rankPill, 'rank', G.rank ? ('#' + G.rank + ' sıradasın') : '#—');
    }

    function renderShop() {
        if (!el.shop) return;
        el.shop.innerHTML = '';
        G.buildings.forEach((b) => {
            const li = document.createElement('li');
            li.className = 'shop-item';
            const affordable = G.display >= (G.amount === 10 ? b.cost10 : b.cost);
            if (b.count > 0) li.classList.add('unlocked');
            else if (!affordable) li.classList.add('locked');

            const emoji = document.createElement('span');
            emoji.className = 'shop-emoji';
            emoji.textContent = b.emoji;

            const info = document.createElement('div');
            info.className = 'shop-info';
            const nameRow = document.createElement('div');
            nameRow.className = 'shop-name';
            const name = document.createElement('span');
            name.textContent = b.name;
            const count = document.createElement('span');
            count.className = 'shop-count';
            count.textContent = '×' + b.count;
            nameRow.append(name, count);
            const cpsEl = document.createElement('span');
            cpsEl.className = 'shop-cps';
            cpsEl.textContent = 'her biri +' + fmt(b.cps) + '/sn · toplam +' + fmt(b.cps_total);
            info.append(nameRow, cpsEl);

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'shop-buy';
            btn.disabled = !affordable || G.gameOver;
            const cost = document.createElement('span');
            cost.textContent = '🍪 ' + fmt(G.amount === 10 ? b.cost10 : b.cost);
            const lbl = document.createElement('small');
            lbl.textContent = 'satın al ×' + G.amount;
            btn.append(cost, lbl);
            btn.addEventListener('click', () => buyBuilding(b.id));

            li.append(emoji, info, btn);
            el.shop.appendChild(li);
        });
    }

    function renderLb(list, myPos) {
        if (!el.lb) return;
        el.lb.innerHTML = '';
        (list || []).slice(0, 10).forEach((p, i) => {
            const li = document.createElement('li');
            li.className = 'lb-item' + (p.id === G.meId ? ' me' : '');
            const pos = document.createElement('span');
            pos.className = 'lb-pos';
            pos.textContent = String(p.pos || i + 1);
            const name = document.createElement('span');
            name.className = 'lb-name';
            name.textContent = p.username;
            const score = document.createElement('span');
            score.className = 'lb-score';
            score.textContent = fmt(p.score);
            li.append(pos, name, score);
            el.lb.appendChild(li);
        });
        if (!list || !list.length) {
            const li = document.createElement('li');
            li.className = 'lb-empty';
            li.textContent = 'İlk skoru sen koy!';
            el.lb.appendChild(li);
        }
        if (el.lbMe) {
            el.lbMe.innerHTML = '';
            const left = document.createElement('span');
            left.textContent = 'Sıran: ';
            const pos = document.createElement('strong');
            pos.textContent = '#' + (myPos || G.rank || '—');
            const sep = document.createElement('span');
            sep.textContent = ' · Skor: ';
            const sc = document.createElement('strong');
            sc.textContent = fmt(G.totalEarned);
            el.lbMe.append(left, pos, sep, sc);
        }
    }

    function applyPayload(j, opts = {}) {
        G.loaded = true;
        G.cookies = Number(j.cookies) || 0;
        G.display = G.cookies;
        G.totalEarned = Number(j.total_earned) || 0;
        G.clicks = Number(j.clicks) || 0;
        G.clickLevel = Number(j.click_level) || 1;
        G.clickPower = Number(j.click_power) || 1;
        G.clickCost = Number(j.click_cost) || 50;
        G.cps = Number(j.cps) || 0;
        G.tokens = Number(j.tokens) || 0;
        G.multiplier = Number(j.multiplier) || 1;
        G.buildings = j.buildings || [];
        G.rank = Number(j.rank) || 0;
        G.lb = j.leaderboard || [];
        G.pending = 0;
        G.tokens = Math.min(G.tokenRate * 2, G.tokens);
        updateStats();
        renderShop();
        renderLb(G.lb, G.rank);

        if (!opts.silent && Number(j.away_seconds) > 60 && Number(j.away_gain) > 0.5) {
            showOffline(j.away_seconds, j.away_gain);
        }
    }

    function showOffline(secs, gain) {
        if (!el.offline) return;
        el.offlineGain.textContent = fmt(gain) + ' kurabiye';
        const h = Math.floor(secs / 3600);
        const m = Math.floor((secs % 3600) / 60);
        const s = secs % 60;
        el.offlineAway.textContent = 'Uzakta olduğun süre: ' +
            (h > 0 ? h + ' saat ' : '') + (m > 0 ? m + ' dakika ' : '') + (s > 0 && h === 0 ? s + ' saniye' : '');
        el.offline.classList.remove('hidden');
        confettiBurst(window.innerWidth / 2, window.innerHeight / 2, 70);
    }

    /* ---------------- oyun aksiyonları ---------------- */

    async function refresh(full = true) {
        try {
            const j = await api('game_get');
            applyPayload(j, { silent: !full });
        } catch (e) {
            if (authRedirect(e)) return;
            toast('Sunucuya ulaşılamadı', e.message, 'error', 4000);
        }
    }

    async function refreshLb() {
        try {
            const j = await api('game_lb');
            G.lb = j.leaderboard || [];
            G.rank = Number(j.rank) || G.rank;
            renderLb(G.lb, G.rank);
            updateStats();
        } catch (e) {
            if (authRedirect(e)) return;
        }
    }

    function queueClick() {
        if (G.gameOver) return;
        if (G.tokens < 1) {
            el.cookie.classList.remove('pressed');
            void el.cookie.offsetWidth;
            el.cookie.classList.add('pressed');
            setTimeout(() => el.cookie.classList.remove('pressed'), 130);
            toast('Çok hızlı tıklıyorsun', 'Tıklama hakkın yenileniyor…', 'info', 1800);
            return;
        }
        G.tokens = Math.max(0, G.tokens - 1);
        G.pending += 1;
        G.display += G.clickPower;
        updateStats();
        scheduleFlush();
    }

    function scheduleFlush() {
        if (G.flushTimer) return;
        G.flushTimer = setTimeout(flushClicks, 120);
    }

    async function flushClicks() {
        G.flushTimer = null;
        if (G.sending) { scheduleFlush(); return; }
        if (G.pending < 1) return;
        const n = Math.min(G.pending, 60);
        G.pending -= n;
        G.sending = true;
        try {
            const j = await api('game_click', { method: 'POST', data: { n } });
            G.cookies = Number(j.cookies) || G.cookies;
            G.display = Math.max(G.cookies, G.display - n * G.clickPower) + n * G.clickPower;
            G.display = G.cookies;
            G.totalEarned = Number(j.total_earned) || G.totalEarned;
            G.clicks = Number(j.clicks) || G.clicks;
            G.tokens = Number(j.tokens) || 0;
            G.clickPower = Number(j.click_power) || G.clickPower;
            G.cps = Number(j.cps) || G.cps;
            updateStats();
        } catch (e) {
            G.pending = 0;
            if (authRedirect(e)) return;
            if (e.payload && e.payload.tokens === 0) {
                toast('Fren yap!', 'Tıklama hakkın bitti, biraz bekle.', 'error', 2200);
            } else {
                toast('Tıklama kaydedilemedi', e.message, 'error', 3500);
            }
            refresh(false);
        } finally {
            G.sending = false;
            if (G.pending > 0) scheduleFlush();
        }
    }

    async function buyBuilding(id) {
        if (G.busy || G.gameOver) return;
        G.busy = true;
        try {
            const j = await api('game_buy', { method: 'POST', data: { kind: 'building', id, amount: G.amount } });
            const before = G.totalEarned;
            applyPayload(j, { silent: true });
            const spentCps = (j.buildings || []).find(b => b.id === id);
            if (spentCps && G.amount >= 10) {
                confettiBurst(window.innerWidth / 2, window.innerHeight / 3, 45);
            }
            toast('Satın alındı!', spentCps ? spentCps.name + ' ×' + G.amount : '', 'success', 1800);
            if (before === G.totalEarned) { /* aynı */ }
        } catch (e) {
            if (authRedirect(e)) return;
            if (e.payload && e.payload.need) {
                toast('Yetersiz kurabiye', 'Gerekli: ' + fmt(e.payload.need) + ' 🍪', 'error', 3000);
            } else {
                toast('Satın alma başarısız', e.message, 'error', 3500);
            }
            refresh(false);
        } finally {
            G.busy = false;
        }
    }

    async function buyUpgrade() {
        if (G.busy || G.gameOver) return;
        G.busy = true;
        try {
            const j = await api('game_buy', { method: 'POST', data: { kind: 'click', amount: 1 } });
            applyPayload(j, { silent: true });
            toast('Tıklama gücü arttı!', 'Yeni güç: ' + G.clickPower, 'success', 2000);
            if (G.clickLevel % 5 === 0) confettiBurst(window.innerWidth / 2, window.innerHeight / 2, 40);
        } catch (e) {
            if (authRedirect(e)) return;
            if (e.payload && e.payload.need) {
                toast('Yetersiz kurabiye', 'Gerekli: ' + fmt(e.payload.need) + ' 🍪', 'error', 3000);
            } else {
                toast('Yükseltilemedi', e.message, 'error', 3000);
            }
        } finally {
            G.busy = false;
        }
    }

    /* ---------------- uçan sayılar / konfeti ---------------- */

    function spawnFloat(x, y, amount) {
        if (!el.clickLayer || !wrap) return;
        const rect = wrap.getBoundingClientRect();
        const span = document.createElement('span');
        span.className = 'float-num';
        span.textContent = '+' + fmt(amount);
        span.style.left = (x - rect.left) + 'px';
        span.style.top = (y - rect.top) + 'px';
        el.clickLayer.appendChild(span);
        setTimeout(() => span.remove(), 1050);
    }

    const conf = { ctx: null, parts: [], raf: 0 };

    function confettiSetup() {
        if (!el.confetti) return;
        const canvas = el.confetti;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        conf.ctx = ctx;
        const resize = () => {
            const dpr = window.devicePixelRatio || 1;
            canvas.width = Math.floor(window.innerWidth * dpr);
            canvas.height = Math.floor(window.innerHeight * dpr);
            canvas.style.width = window.innerWidth + 'px';
            canvas.style.height = window.innerHeight + 'px';
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        };
        resize();
        window.addEventListener('resize', resize);
    }

    function confettiBurst(x, y, count = 60) {
        if (!conf.ctx) return;
        const colors = ['#7c5cff', '#22d3ee', '#ff5ea8', '#ffc857', '#3ddc97', '#ffffff'];
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 4 + Math.random() * 9;
            conf.parts.push({
                x, y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 4,
                g: 0.24 + Math.random() * 0.12,
                w: 5 + Math.random() * 6,
                h: 7 + Math.random() * 7,
                rot: Math.random() * Math.PI,
                vr: (Math.random() - 0.5) * 0.3,
                color: colors[Math.floor(Math.random() * colors.length)],
                life: 1
            });
        }
        if (!conf.raf) conf.raf = requestAnimationFrame(confettiLoop);
    }

    function confettiLoop() {
        const ctx = conf.ctx;
        if (!ctx) return;
        ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        conf.parts = conf.parts.filter(p => p.life > 0 && p.y < window.innerHeight + 60);
        conf.parts.forEach(p => {
            p.vy += p.g;
            p.x += p.vx;
            p.y += p.vy;
            p.vx *= 0.995;
            p.rot += p.vr;
            p.life -= 0.006;
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot);
            ctx.globalAlpha = Math.max(0, p.life);
            ctx.fillStyle = p.color;
            ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
            ctx.restore();
        });
        if (conf.parts.length) {
            conf.raf = requestAnimationFrame(confettiLoop);
        } else {
            ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
            conf.raf = 0;
        }
    }

    /* ---------------- canlı sayaç ---------------- */

    function liveTick() {
        const now = performance.now();
        const dt = Math.min(1, (now - G.lastLive) / 1000);
        G.lastLive = now;
        if (!G.loaded) return;
        if (G.cps > 0) {
            G.display += G.cps * dt;
            G.cookies += G.cps * dt;
            G.totalEarned += G.cps * dt;
        }
        const cap = G.tokenRate * 2;
        if (G.tokens < cap) G.tokens = Math.min(cap, G.tokens + G.tokenRate * dt);
        updateStats();
    }

    /* ---------------- olaylar ---------------- */

    function bind() {
        if (el.cookie) {
            el.cookie.addEventListener('pointerdown', (e) => {
                if (e.button !== undefined && e.button !== 0) return;
                e.preventDefault();
                queueClick();
                spawnFloat(e.clientX, e.clientY, G.clickPower);
                el.cookie.classList.add('pressed');
                setTimeout(() => el.cookie.classList.remove('pressed'), 120);
            });
            el.cookie.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const r = el.cookie.getBoundingClientRect();
                    queueClick();
                    spawnFloat(r.left + r.width / 2, r.top + r.height / 2, G.clickPower);
                }
            });
        }

        window.addEventListener('keydown', (e) => {
            if (e.code !== 'Space') return;
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
            e.preventDefault();
            if (!el.cookie) return;
            const r = el.cookie.getBoundingClientRect();
            queueClick();
            spawnFloat(r.left + r.width / 2, r.top + r.height / 2, G.clickPower);
            el.cookie.classList.add('pressed');
            setTimeout(() => el.cookie.classList.remove('pressed'), 120);
        });

        el.upgradeBtn && el.upgradeBtn.addEventListener('click', buyUpgrade);

        el.buyToggle && el.buyToggle.addEventListener('click', (e) => {
            const btn = e.target.closest('button[data-amount]');
            if (!btn) return;
            G.amount = Number(btn.dataset.amount) === 10 ? 10 : 1;
            $$('button[data-amount]', el.buyToggle).forEach(b => b.classList.toggle('active', b === btn));
            renderShop();
            updateStats();
        });

        $('#refreshGameLb') && $('#refreshGameLb').addEventListener('click', () => {
            refreshLb();
            toast('Skor tablosu yenilendi', '', 'success', 1600);
        });

        $('#offlineClose') && $('#offlineClose').addEventListener('click', () => {
            el.offline.classList.add('hidden');
        });

        el.logout && el.logout.addEventListener('click', async () => {
            try { await api('logout', { method: 'POST' }); } catch (e) {}
            location.href = 'index.php';
        });

        document.addEventListener('visibilitychange', () => {
            document.documentElement.classList.toggle('nc-hidden', document.hidden);
            if (!document.hidden) refresh(false);
        });
    }

    /* ---------------- başlat ---------------- */

    const meAvatar = $('.user-chip .avatar');
    if (meAvatar && G.meName) avatarColor(meAvatar, G.meName);
    confettiSetup();
    bind();
    renderLb([], 0);
    setInterval(liveTick, 100);
    setInterval(() => refresh(false), 20000);
    setInterval(refreshLb, 30000);
    refresh(true);
})();
