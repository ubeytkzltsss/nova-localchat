/* ==========================================================================
   NovaChat - giriş + sohbet istemcisi
   Tüm yetki/doğrulama sunucuda; bu dosya sadece arayüzü yönetir.
   ========================================================================== */
'use strict';

(() => {
    const $ = (sel, root = document) => root.querySelector(sel);
    const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
    const body = document.body;
    const page = body.dataset.page || '';
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    let CSRF = csrfMeta ? csrfMeta.content : '';

    const SITE_NAME = body.dataset.siteName || 'NovaChat';

    /* ------------------------------------------------------------------
       Yardımcılar
       ------------------------------------------------------------------ */

    function api(action, opts = {}) {
        let url = 'api.php?action=' + encodeURIComponent(action);
        if (opts.params) {
            const qs = new URLSearchParams();
            Object.keys(opts.params).forEach(k => qs.set(k, String(opts.params[k])));
            url += '&' + qs.toString();
        }
        const init = {
            method: opts.method || 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-CSRF-Token': CSRF },
            cache: 'no-store'
        };
        if (opts.data instanceof FormData) {
            init.method = 'POST';
            init.body = opts.data;
        } else if (opts.data) {
            init.method = 'POST';
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify(opts.data);
        }
        return fetch(url, init).then(async (res) => {
            let json = null;
            try { json = await res.json(); } catch (e) { json = null; }
            if (!res.ok || !json || json.ok === false) {
                const err = new Error((json && json.error) || ('Sunucu hatası (' + res.status + ')'));
                err.status = res.status;
                err.payload = json || {};
                throw err;
            }
            if (json.csrf) CSRF = json.csrf;
            return json;
        });
    }

    function authRedirect(err) {
        if (!err) return false;
        if (err.status === 401) { location.href = 'index.php'; return true; }
        if (err.payload && (err.payload.logout || err.payload.banned || err.payload.ip_banned)) {
            location.href = 'index.php';
            return true;
        }
        return false;
    }

    function toast(title, text = '', kind = 'info', ttl = 4000) {
        const root = $('#toastRoot');
        if (!root) return;
        const icons = { info: '💬', success: '✅', error: '⚠️', mention: '🔔' };
        const el = document.createElement('div');
        el.className = 'toast ' + kind;
        const ico = document.createElement('span');
        ico.className = 'toast-ico';
        ico.textContent = icons[kind] || icons.info;
        const bodyEl = document.createElement('div');
        bodyEl.className = 'toast-body';
        const t = document.createElement('strong');
        t.className = 'toast-title';
        t.textContent = title;
        bodyEl.appendChild(t);
        if (text) {
            const s = document.createElement('span');
            s.className = 'toast-text';
            s.textContent = text;
            bodyEl.appendChild(s);
        }
        el.append(ico, bodyEl);
        el.style.pointerEvents = 'auto';
        el.addEventListener('click', () => dismiss());
        root.appendChild(el);
        while (root.children.length > 4) root.removeChild(root.firstElementChild);

        let closed = false;
        const dismiss = () => {
            if (closed) return;
            closed = true;
            el.classList.add('out');
            setTimeout(() => el.remove(), 320);
        };
        setTimeout(dismiss, ttl);
        return dismiss;
    }

    function hashHue(name) {
        let h = 0;
        for (const ch of String(name || '?')) h = (h * 31 + ch.codePointAt(0)) % 360;
        return h;
    }

    function applyAvatarColor(el, name) {
        if (!el || el.dataset.colored === '1') return;
        const h = hashHue(name);
        el.style.background = `linear-gradient(135deg, hsl(${h} 85% 62%), hsl(${(h + 65) % 360} 85% 52%))`;
        el.style.boxShadow = `0 6px 18px hsl(${h} 80% 40% / .45), inset 0 0 0 1px rgba(255,255,255,.14)`;
        el.dataset.colored = '1';
        if (el.textContent.trim() === '') el.textContent = String(name || '?').slice(0, 1).toUpperCase();
    }

    function colorAllAvatars(root = document) {
        $$('.avatar[data-avatar]', root).forEach(el => applyAvatarColor(el, el.dataset.avatar));
    }

    function fmtShort(n) {
        n = Number(n) || 0;
        const neg = n < 0 ? '-' : '';
        n = Math.abs(n);
        if (n < 1000) {
            if (Number.isInteger(n)) return neg + String(n);
            return neg + (n < 10 ? n.toFixed(1).replace('.', ',') : String(Math.floor(n)));
        }
        const units = [['Mn', 1e6], ['Mr', 1e9], ['Tn', 1e12], ['Kt', 1e15], ['Kn', 1e18]];
        if (n < 1e6) return neg + (n / 1e3).toFixed(n < 1e4 ? 1 : 0).replace('.', ',') + 'B';
        for (let i = units.length - 1; i >= 0; i--) {
            if (n >= units[i][1] * 1000 || i === units.length - 1) {
                const v = n / units[i][1];
                return neg + (v >= 100 ? Math.round(v) : v.toFixed(1).replace('.', ',')) + ' ' + units[i][0];
            }
        }
        return neg + Math.round(n);
    }

    function fmtTime(ts) {
        return new Date(ts * 1000).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    }

    function dayKey(ts) {
        const d = new Date(ts * 1000);
        return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate();
    }

    function dayLabel(ts) {
        const d = new Date(ts * 1000);
        const today = new Date();
        const yesterday = new Date();
        yesterday.setDate(today.getDate() - 1);
        const time = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
        if (dayKey(ts) === dayKey(Math.floor(today.getTime() / 1000))) return 'Bugün';
        if (dayKey(ts) === dayKey(Math.floor(yesterday.getTime() / 1000))) return 'Dün';
        return d.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
    }

    function escapeRegExp(s) {
        return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function openModal(el) {
        if (!el) return;
        el.classList.remove('hidden');
        document.body.classList.add('modal-open');
    }

    function closeModal(el) {
        if (!el) return;
        el.classList.add('hidden');
        if (!$$('.modal:not(.hidden)').length) document.body.classList.remove('modal-open');
    }

    function bindModals(root = document) {
        $$('.modal', root).forEach(modal => {
            $$('[data-close]', modal).forEach(b => b.addEventListener('click', () => closeModal(modal)));
        });
        document.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape') return;
            const open = $$('.modal:not(.hidden)');
            if (open.length) closeModal(open[open.length - 1]);
            body.classList.remove('online-open');
        });
    }

    /* ------------------------------------------------------------------
       Giriş sayfası
       ------------------------------------------------------------------ */

    function initLogin() {
        const form = $('#loginForm');
        if (!form) return;

        const input = $('#username');
        const shell = $('#nameShell');
        const status = $('#nameStatus');
        const hint = $('#nameHint');
        const err = $('#loginErr');
        const btn = $('#loginBtn');
        const card = $('#loginCard');
        const reserved = ['admin', 'administrator', 'yonetici', 'yönetici', 'sistem', 'system', 'moderator', 'mod', 'root', 'nova', 'novachat', 'sunucu'];

        colorAllAvatars();

        const nameValid = (v) => {
            if (!/^[\p{L}\p{N}_]{3,20}$/u.test(v)) return { ok: false, msg: '3-20 karakter · harf, rakam ve alt çizgi' };
            if (reserved.includes(v.toLowerCase())) return { ok: false, msg: 'Bu kullanıcı adı rezerve edilmiş' };
            return { ok: true, msg: 'Kullanıma hazır ✨' };
        };

        const refresh = () => {
            const v = input.value.trim();
            if (v === '') {
                shell.classList.remove('valid', 'invalid');
                status.textContent = '';
                hint.textContent = '3-20 karakter · harf, rakam ve alt çizgi';
                hint.className = '';
                return;
            }
            const r = nameValid(v);
            shell.classList.toggle('valid', r.ok);
            shell.classList.toggle('invalid', !r.ok);
            status.textContent = r.ok ? '✓' : '✕';
            hint.textContent = r.msg;
            hint.className = r.ok ? 'ok' : 'bad';
        };

        input.addEventListener('input', () => { refresh(); err.textContent = ''; });
        input.focus();

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (btn.classList.contains('loading')) return;
            const name = input.value.trim();
            const r = nameValid(name);
            if (!r.ok) {
                err.textContent = r.msg;
                card.classList.add('shake');
                setTimeout(() => card.classList.remove('shake'), 500);
                input.focus();
                return;
            }
            err.textContent = '';
            btn.classList.add('loading');
            try {
                const res = await api('login', { method: 'POST', data: { username: name } });
                btn.classList.remove('loading');
                btn.classList.add('done');
                card.classList.add('success');
                toast('Hoş geldin, ' + (res.username || name) + '!', 'Sohbete yönlendiriliyorsun…', 'success', 2000);
                setTimeout(() => { location.href = res.redirect || 'chat.php'; }, 650);
            } catch (e2) {
                btn.classList.remove('loading');
                err.textContent = e2.message;
                card.classList.add('shake');
                setTimeout(() => card.classList.remove('shake'), 500);
                if (e2.payload && e2.payload.taken) {
                    shell.classList.add('invalid');
                }
                authRedirect(e2);
            }
        });
    }

    /* ------------------------------------------------------------------
       Sohbet sayfası
       ------------------------------------------------------------------ */

    function initChat() {
        const ds = body.dataset;
        const me = { id: Number(ds.uid) || 0, username: ds.username || '' };

        const chat = {
            settings: {
                cooldown_ms: Number(ds.cooldownMs) || 3000,
                msg_max_len: Number(ds.maxLen) || 500,
                uploads_enabled: ds.uploadsEnabled === '1',
                gifs_enabled: ds.gifsEnabled === '1',
                games_enabled: ds.gamesEnabled === '1',
                chat_enabled: ds.chatEnabled === '1',
                max_upload_mb: Number(ds.maxUpload) || 80,
                quota_gb: 5,
                site_name: SITE_NAME
            },
            sinceId: 0,
            deletedSince: 0,
            online: [],
            gif: { q: '', items: [], loading: false, seq: 0, lastQuery: null },
            firstState: true,
            msgIds: new Set(),
            lastDay: '',
            unread: 0,
            pollTimer: null,
            pollFails: 0,
            serverOffset: 0,
            lastMsgMs: Number(ds.lastMsgMs) || 0,
            muteUntil: Number(ds.muteUntil) || 0,
            quotaUsed: Number(ds.quotaUsed) || 0,
            quotaLimit: Number(ds.quotaLimit) || 0,
            reply: null,
            file: null,
            uploading: false,
            uploadXhr: null,
            cooling: false,
            cdRaf: null,
            typingAt: 0,
            notifyBlocked: false
        };

        const messagesEl = $('#messages');
        const wrapEl = $('#messagesWrap');
        const input = $('#msgInput');
        const form = $('#composer');
        const sendBtn = $('#btnSend');
        const charCount = $('#charCount');
        const attachBtn = $('#btnAttach');
        const fileInput = $('#fileInput');
        const pendingFile = $('#pendingFile');
        const pfName = $('#pfName');
        const pfSize = $('#pfSize');
        const pfBar = $('#pfBar');
        const replyBar = $('#replyBar');
        const replyName = $('#replyName');
        const typingBar = $('#typingBar');
        const typingText = $('#typingText');
        const onlineList = $('#onlineList');
        const onlineCount = $('#onlineCount');
        const onlinePill = $('#onlinePill');
        const cooldownBar = $('#cooldownBar');
        const cooldownFill = $('#cooldownFill');
        const cooldownText = $('#cooldownText');
        const muteNotice = $('#muteNotice');
        const muteLeft = $('#muteLeft');
        const newMsgPill = $('#newMsgPill');
        const annWrap = $('#announcement');
        const annText = $('#annText');
        const annClose = $('#annClose');
        const quotaInfo = $('#quotaInfo');
        const meQuotaText = $('#meQuotaText');
        const meQuotaFill = $('#meQuotaFill');
        const connBanner = $('#connBanner');
        const livePill = $('#livePill');
        const notifyBtn = $('#btnNotify');
        const gifFab = $('#gifFab');
        const baseTitle = document.title;

        colorAllAvatars();

        /* ---------- temel UI ---------- */

        function serverNow() { return Date.now() + chat.serverOffset; }
        function nowSec() { return serverNow() / 1000; }

        function scrollBottom(smooth) {
            messagesEl.scrollTo({ top: messagesEl.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
        }

        function isNearBottom() {
            return messagesEl.scrollHeight - messagesEl.scrollTop - messagesEl.clientHeight < 160;
        }

        function updateUnreadTitle() {
            if (chat.unread > 0) {
                document.title = '(' + chat.unread + ') ' + baseTitle;
            } else {
                document.title = baseTitle;
            }
        }

        function updateQuotaUI() {
            const used = chat.quotaUsed;
            const limit = chat.quotaLimit;
            const pct = limit > 0 ? Math.min(100, (used / limit) * 100) : 0;
            if (meQuotaFill) meQuotaFill.style.width = pct + '%';
            if (meQuotaText) meQuotaText.textContent = fmtBytes(used) + ' / ' + fmtBytes(limit);
            if (quotaInfo) quotaInfo.textContent = 'Kota: ' + fmtBytes(used) + ' / ' + fmtBytes(limit);
            if (attachBtn) {
                const full = limit > 0 && used >= limit;
                attachBtn.disabled = !chat.settings.uploads_enabled || full || !chat.settings.chat_enabled;
                attachBtn.title = full ? 'IP dosya kotan doldu' : 'Dosya ekle (max ' + chat.settings.max_upload_mb + ' MB)';
            }
        }

        function fmtBytes(b) {
            b = Number(b) || 0;
            const units = ['B', 'KB', 'MB', 'GB', 'TB'];
            let i = 0;
            while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
            return (i === 0 ? Math.round(b) : b.toFixed(2).replace('.', ',')) + ' ' + units[i];
        }

        function setSendEnabled() {
            if (!sendBtn) return;
            const muted = chat.muteUntil > nowSec();
            sendBtn.disabled = chat.cooling || muted || !chat.settings.chat_enabled || chat.uploading;
        }

        function applyChatState() {
            if (!input) return;
            const enabled = chat.settings.chat_enabled;
            input.maxLength = chat.settings.msg_max_len;
            input.disabled = !enabled;
            if (sendBtn) sendBtn.disabled = !enabled;
            if (attachBtn) attachBtn.disabled = !chat.settings.uploads_enabled || !enabled;
            if (gifFab) gifFab.classList.toggle('hidden', !chat.settings.gifs_enabled);
            if (charCount) {
                const label = input.value.length + '/' + chat.settings.msg_max_len;
                if (charCount.textContent !== label) charCount.textContent = label;
            }
            updateMute();
            updateQuotaUI();
            setSendEnabled();
        }

        let muteState = null;
        function updateMute() {
            if (!muteNotice) return;
            const remain = Math.ceil(chat.muteUntil - nowSec());
            const active = remain > 0 && chat.settings.chat_enabled;
            if (active) {
                const m = Math.floor(remain / 60);
                const s = remain % 60;
                const label = (m > 0 ? m + ' dk ' : '') + s + ' sn';
                if (muteState !== 'on') {
                    muteState = 'on';
                    muteNotice.classList.remove('hidden');
                    if (input) input.disabled = true;
                }
                if (muteLeft.textContent !== label) muteLeft.textContent = label;
                setSendEnabled();
            } else if (muteState !== 'off') {
                muteState = 'off';
                muteNotice.classList.add('hidden');
                if (input && chat.settings.chat_enabled) input.disabled = false;
                setSendEnabled();
            }
        }

        setInterval(() => { updateMute(); }, 1000);

        /* ---------- koşullu yavaş mod ---------- */

        function startCooldown(fromMs) {
            const cd = Math.max(0, Number(chat.settings.cooldown_ms) || 0);
            if (!cd || !cooldownBar) return;
            if (fromMs) chat.lastMsgMs = Math.max(chat.lastMsgMs, fromMs);
            cancelAnimationFrame(chat.cdRaf);
            chat.cooling = true;
            cooldownBar.classList.remove('hidden', 'done');
            setSendEnabled();
            const step = () => {
                const remain = chat.lastMsgMs + cd - serverNow();
                if (remain <= 0) {
                    cooldownFill.style.width = '100%';
                    cooldownText.textContent = 'Hazır ✓';
                    cooldownBar.classList.add('done');
                    chat.cooling = false;
                    setSendEnabled();
                    setTimeout(() => cooldownBar.classList.add('hidden'), 500);
                    chat.cdRaf = 0;
                    return;
                }
                cooldownFill.style.width = Math.min(100, (1 - remain / cd) * 100) + '%';
                cooldownText.textContent = 'Yavaş mod · ' + (remain / 1000).toFixed(1).replace('.', ',') + ' sn';
                chat.cdRaf = requestAnimationFrame(step);
            };
            step();
        }

        /* ---------- mesaj oluşturma ---------- */

        function buildLinkified(text) {
            const frag = document.createDocumentFragment();
            const myName = me.username;
            const re = /(https?:\/\/[^\s<>"']+)|(@[\p{L}\p{N}_]{2,20})/gu;
            let last = 0;
            let m;
            while ((m = re.exec(text)) !== null) {
                if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
                if (m[1]) {
                    let url = m[1];
                    let trailing = '';
                    while (/[.,!?;:)\]}"]$/.test(url)) { trailing = url.slice(-1) + trailing; url = url.slice(0, -1); }
                    const a = document.createElement('a');
                    a.href = url;
                    a.target = '_blank';
                    a.rel = 'noopener noreferrer nofollow';
                    a.textContent = url;
                    frag.appendChild(a);
                    if (trailing) frag.appendChild(document.createTextNode(trailing));
                } else if (m[2]) {
                    const span = document.createElement('span');
                    const isMe = m[2].slice(1).toLowerCase() === myName.toLowerCase();
                    span.className = 'mention' + (isMe ? ' me' : '');
                    span.textContent = m[2];
                    frag.appendChild(span);
                }
                last = re.lastIndex;
            }
            if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
            return frag;
        }

        function fileUrl(id) { return 'api.php?action=file&id=' + encodeURIComponent(id); }

        function buildFileNode(f) {
            const wrap = document.createElement('div');
            wrap.className = 'msg-file';
            if (f.is_image) {
                const a = document.createElement('a');
                a.className = 'file-image';
                a.href = fileUrl(f.id);
                const img = document.createElement('img');
                img.src = fileUrl(f.id);
                img.alt = f.name;
                img.loading = 'lazy';
                a.appendChild(img);
                a.addEventListener('click', (e) => {
                    e.preventDefault();
                    openLightbox(fileUrl(f.id));
                });
                wrap.appendChild(a);
            } else if (f.is_video) {
                const v = document.createElement('video');
                v.className = 'file-video';
                v.controls = true;
                v.preload = 'metadata';
                v.src = fileUrl(f.id);
                wrap.appendChild(v);
            } else if (f.is_audio) {
                const au = document.createElement('audio');
                au.className = 'file-audio';
                au.controls = true;
                au.preload = 'metadata';
                au.src = fileUrl(f.id);
                wrap.appendChild(au);
            } else {
                const a = document.createElement('a');
                a.className = 'file-chip';
                a.href = fileUrl(f.id);
                a.download = f.name;
                const ico = document.createElement('span');
                ico.className = 'file-icon';
                ico.textContent = fileIcon(f.name);
                const info = document.createElement('span');
                info.className = 'file-info';
                const nm = document.createElement('span');
                nm.className = 'file-name';
                nm.textContent = f.name;
                const sz = document.createElement('span');
                sz.className = 'file-size';
                sz.textContent = f.size_txt + ' · indir';
                info.append(nm, sz);
                a.append(ico, info);
                wrap.appendChild(a);
            }
            return wrap;
        }

        function fileIcon(name) {
            const ext = String(name || '').split('.').pop().toLowerCase();
            if (['zip', 'rar', '7z'].includes(ext)) return '🗜️';
            if (['pdf'].includes(ext)) return '📕';
            if (['doc', 'docx'].includes(ext)) return '📘';
            if (['xls', 'xlsx'].includes(ext)) return '📗';
            if (['ppt', 'pptx'].includes(ext)) return '📙';
            if (['txt'].includes(ext)) return '📄';
            return '📦';
        }

        function createMessageElement(msg) {
            const el = document.createElement('div');
            el.className = 'msg';
            el.id = 'm-' + msg.id;
            el.dataset.id = msg.id;

            const isMention = msg.body && new RegExp('(^|[^\\p{L}\\p{N}_])@' + escapeRegExp(me.username) + '(?![\\p{L}\\p{N}_])', 'iu').test(msg.body);
            if (isMention && msg.uid !== me.id) el.classList.add('mentioned');

            const avatar = document.createElement('span');
            avatar.className = 'avatar';
            const displayName = msg.username || 'silinmiş';
            applyAvatarColor(avatar, displayName);
            avatar.textContent = displayName.slice(0, 1).toUpperCase();

            const main = document.createElement('div');
            main.className = 'msg-main';

            const head = document.createElement('div');
            head.className = 'msg-head';
            const name = document.createElement('span');
            name.className = 'msg-name';
            name.textContent = msg.username || 'silinmiş kullanıcı';
            const time = document.createElement('span');
            time.className = 'msg-time';
            time.textContent = fmtTime(msg.ts);
            head.append(name, time);

            if (msg.reply) {
                const tag = document.createElement('button');
                tag.type = 'button';
                tag.className = 'reply-tag';
                tag.title = 'Orijinal mesaja git';
                const arrow = document.createElement('span');
                arrow.textContent = '↩';
                const rn = document.createElement('span');
                rn.className = 'rt-name';
                rn.textContent = '@' + (msg.reply.username || 'silinmiş');
                const rb = document.createElement('span');
                rb.className = 'rt-body';
                rb.textContent = msg.reply.deleted ? '(silinmiş mesaj)' : (msg.reply.body || '');
                tag.append(arrow, rn, rb);
                tag.addEventListener('click', () => {
                    const target = document.getElementById('m-' + msg.reply.id);
                    if (target) {
                        target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        target.classList.remove('flash');
                        void target.offsetWidth;
                        target.classList.add('flash');
                    } else {
                        toast('Mesaj bulunamadı', 'Orijinal mesaj artık görünmüyor.', 'info', 2600);
                    }
                });
                head.appendChild(tag);
            }

            main.appendChild(head);

            if (msg.body) {
                const text = document.createElement('p');
                text.className = 'msg-text';
                text.appendChild(buildLinkified(msg.body));
                main.appendChild(text);
            }

            if (msg.file) main.appendChild(buildFileNode(msg.file));

            if (msg.gif && msg.gif.url) {
                const gifWrap = document.createElement('span');
                gifWrap.className = 'msg-file';
                if (/\.(mp4|webm)$/i.test(msg.gif.url)) {
                    const vid = document.createElement('video');
                    vid.className = 'chat-gif';
                    vid.src = msg.gif.url;
                    vid.autoplay = true;
                    vid.loop = true;
                    vid.muted = true;
                    vid.playsInline = true;
                    vid.setAttribute('playsinline', '');
                    vid.addEventListener('click', () => openLightbox(msg.gif.url));
                    gifWrap.appendChild(vid);
                } else {
                    const img = document.createElement('img');
                    img.className = 'chat-gif';
                    img.src = msg.gif.url;
                    img.alt = msg.gif.label || 'GIF';
                    img.loading = 'lazy';
                    img.addEventListener('click', () => openLightbox(msg.gif.url));
                    gifWrap.appendChild(img);
                }
                main.appendChild(gifWrap);
            }

            const actions = document.createElement('div');
            actions.className = 'msg-actions';
            const replyBtn = document.createElement('button');
            replyBtn.type = 'button';
            replyBtn.title = 'Yanıtla';
            replyBtn.textContent = '↩';
            replyBtn.addEventListener('click', () => setReply(msg));
            actions.appendChild(replyBtn);

            el.append(avatar, main, actions);
            return el;
        }

        function appendDividerIfNeeded(ts) {
            const key = dayKey(ts);
            if (chat.lastDay === key) return;
            chat.lastDay = key;
            const div = document.createElement('div');
            div.className = 'date-divider';
            div.textContent = dayLabel(ts);
            messagesEl.appendChild(div);
        }

        function appendMessage(msg, own = false) {
            if (!msg || chat.msgIds.has(msg.id)) return;
            const near = isNearBottom();
            clearEmptyState();
            appendDividerIfNeeded(msg.ts);
            messagesEl.appendChild(createMessageElement(msg));
            chat.msgIds.add(msg.id);
            chat.firstState = false;
            const sk = $('#skeletonList');
            if (sk) sk.remove();
            if (near || own) {
                scrollBottom(true);
            } else {
                chat.unread++;
                updateUnreadTitle();
                if (newMsgPill) newMsgPill.classList.remove('hidden');
            }
        }

        function clearEmptyState() {
            const empty = $('#emptyChat');
            if (empty) empty.remove();
        }

        function showEmptyState() {
            if (!messagesEl || messagesEl.querySelector('.msg') || document.getElementById('emptyChat')) return;
            const div = document.createElement('div');
            div.className = 'empty-chat';
            div.id = 'emptyChat';
            const ico = document.createElement('span');
            ico.textContent = '💬';
            const h = document.createElement('strong');
            h.textContent = 'Henüz mesaj yok';
            const p = document.createElement('p');
            p.textContent = 'İlk mesajı sen yaz, sohbeti başlat!';
            div.append(ico, h, p);
            messagesEl.appendChild(div);
        }

        function removeMessages(ids) {
            ids.forEach(id => {
                const el = document.getElementById('m-' + id);
                if (el) el.remove();
                chat.msgIds.delete(Number(id));
            });
            chat.unread = Math.max(0, chat.unread);
        }

        function setReply(msg) {
            chat.reply = { id: msg.id, username: msg.username || 'silinmiş' };
            if (!replyBar) return;
            replyName.textContent = '@' + (msg.username || 'silinmiş');
            replyBar.classList.remove('hidden');
            if (input) input.focus();
        }

        function clearReply() {
            chat.reply = null;
            if (replyBar) replyBar.classList.add('hidden');
        }

        /* ---------- online liste ---------- */

        let onlineSig = '';
        function renderOnline(list) {
            if (!onlineList) return;
            // Aynı veri geldiğinde listeyi yeniden kurmayız: hem gereksiz DOM işi
            // hem de her 3 saniyede tekrar oynayan satır animasyonları önlenir.
            const sig = list.map((u) => u.id + '|' + u.username + '|' + u.score + '|' + (u.typing ? 1 : 0)).join(',');
            if (sig === onlineSig) return;
            onlineSig = sig;
            const frag = document.createDocumentFragment();
            list.forEach((u) => {
                const li = document.createElement('li');
                li.className = 'online-item' + (u.id === me.id ? ' me' : '') + (u.typing ? ' typing' : '');
                li.dataset.name = u.username;
                const av = document.createElement('span');
                av.className = 'avatar';
                applyAvatarColor(av, u.username);
                av.textContent = u.username.slice(0, 1).toUpperCase();

                const meta = document.createElement('span');
                meta.className = 'online-meta';
                const nm = document.createElement('span');
                nm.className = 'online-name';
                nm.textContent = u.username + (u.id === me.id ? ' ' : '');
                if (u.id === me.id) {
                    const em = document.createElement('em');
                    em.textContent = '(sen)';
                    nm.appendChild(em);
                }
                const sc = document.createElement('span');
                sc.className = 'online-score';
                sc.textContent = '🍪 ' + fmtShort(u.score);
                meta.append(nm, sc);

                const dot = document.createElement('span');
                dot.className = 'presence-dot';
                li.append(av, meta, dot);
                frag.appendChild(li);
            });
            onlineList.innerHTML = '';
            onlineList.appendChild(frag);
            $('#onlineCount') && ($('#onlineCount').textContent = String(list.length));
            if (onlinePill) onlinePill.textContent = list.length + ' çevrimiçi';
        }

        /* ---------- skor tabloları (oyun menüsü) ---------- */

        function renderLb(listEl, items, myId, emptyText) {
            if (!listEl) return;
            listEl.innerHTML = '';
            if (!items || !items.length) {
                const li = document.createElement('li');
                li.className = 'lb-empty';
                li.textContent = emptyText || 'Henüz skor yok.';
                listEl.appendChild(li);
                return;
            }
            items.forEach((it, idx) => {
                const li = document.createElement('li');
                li.className = 'lb-item' + (myId && it.id === myId ? ' me' : '');
                const pos = document.createElement('span');
                pos.className = 'lb-pos';
                pos.textContent = String(idx + 1);
                const nm = document.createElement('span');
                nm.className = 'lb-name';
                nm.textContent = it.username;
                const sc = document.createElement('span');
                sc.className = 'lb-score';
                sc.textContent = fmtShort(it.score);
                li.append(pos, nm, sc);
                listEl.appendChild(li);
            });
        }

        async function loadGameLb() {
            const listEl = $('#gameLbList');
            if (!chat.settings.games_enabled) {
                renderLb(listEl, [], 0, 'Oyunlar şu anda kapalı.');
                return;
            }
            try {
                const j = await api('game_lb');
                renderLb(listEl, j.leaderboard.slice(0, 8), me.id, 'Henüz skor yok. İlk sen oyna!');
            } catch (e) {
                renderLb(listEl, [], 0, 'Skor tablosu yüklenemedi.');
            }
        }

        /* ---------- gifler ---------- */

        const gifInput = $('#gifQuery');
        const gifClear = $('#gifClear');
        const gifGrid = $('#gifGrid');
        const gifStatus = $('#gifStatus');
        const gifHint = $('#gifHint');
        let gifTimer = null;

        function gifRenderLoading() {
            if (!gifGrid) return;
            gifGrid.innerHTML = '';
            for (let i = 0; i < 12; i++) {
                const ph = document.createElement('div');
                ph.className = 'gif-item gif-skel';
                gifGrid.appendChild(ph);
            }
            if (gifStatus) {
                gifStatus.textContent = 'GIF\'ler getiriliyor…';
                gifStatus.className = 'gif-status';
            }
        }

        function gifRenderError(message, query) {
            if (!gifGrid) return;
            gifGrid.innerHTML = '';
            const box = document.createElement('div');
            box.className = 'gif-empty';
            const ico = document.createElement('span');
            ico.textContent = '📡';
            const strong = document.createElement('strong');
            strong.textContent = 'GIF\'ler yüklenemedi';
            const p = document.createElement('p');
            p.textContent = message || 'Bağlantı sorunu olabilir.';
            const retry = document.createElement('button');
            retry.type = 'button';
            retry.className = 'mini-btn';
            retry.textContent = '↻ Tekrar dene';
            retry.addEventListener('click', () => gifSearch(query || '', true));
            box.append(ico, strong, p, retry);
            gifGrid.appendChild(box);
            if (gifStatus) {
                gifStatus.textContent = '';
                gifStatus.className = 'gif-status';
            }
        }

        function gifRenderItems(items) {
            if (!gifGrid) return;
            gifGrid.innerHTML = '';
            if (!items.length) {
                const box = document.createElement('div');
                box.className = 'gif-empty';
                const ico = document.createElement('span');
                ico.textContent = '🔍';
                const strong = document.createElement('strong');
                strong.textContent = 'Sonuç bulunamadı';
                const p = document.createElement('p');
                p.textContent = 'Farklı bir kelimeyle aramayı dene.';
                box.append(ico, strong, p);
                gifGrid.appendChild(box);
                if (gifStatus) gifStatus.textContent = '';
                return;
            }
            const frag = document.createDocumentFragment();
            items.forEach((item) => {
                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'gif-item';
                btn.title = item.title || 'GIF gönder';
                btn.dataset.id = item.id;

                const img = document.createElement('img');
                img.src = item.tiny || item.url;
                img.alt = item.title || 'GIF';
                img.loading = 'lazy';
                img.decoding = 'async';
                if (item.w && item.h) {
                    img.width = item.w;
                    img.height = item.h;
                }
                btn.appendChild(img);
                btn.addEventListener('click', () => {
                    closeModal($('#gifModal'));
                    sendGif(item.url);
                });
                frag.appendChild(btn);
            });
            gifGrid.appendChild(frag);
            if (gifStatus) {
                gifStatus.textContent = items.length + ' GIF · beğendiğine tıkla, anında gönderilir';
                gifStatus.className = 'gif-status';
            }
        }

        async function gifSearch(query, force) {
            const q = String(query || '').trim().slice(0, 40);
            if (!force && q === chat.gif.lastQuery && chat.gif.loading) return;
            chat.gif.lastQuery = q;
            chat.gif.q = q;
            const seq = ++chat.gif.seq;
            chat.gif.loading = true;
            gifRenderLoading();
            if (gifHint) gifHint.textContent = q === '' ? 'Popüler GIF\'ler' : '“' + q + '” için sonuçlar';
            if (gifClear) gifClear.classList.toggle('hidden', q === '');
            try {
                const j = await api('gif_search', { params: { q } });
                if (seq !== chat.gif.seq) return;
                chat.gif.items = j.items || [];
                gifRenderItems(chat.gif.items);
            } catch (e) {
                if (seq !== chat.gif.seq) return;
                if (authRedirect(e)) return;
                gifRenderError(e.message, q);
            } finally {
                if (seq === chat.gif.seq) chat.gif.loading = false;
            }
        }

        function openGifModal() {
            if (!$('#gifModal')) return;
            if (!chat.settings.gifs_enabled) {
                toast('GIF gönderimi kapalı', 'Yönetici GIF özelliğini devre dışı bıraktı.', 'info', 3000);
                return;
            }
            openModal($('#gifModal'));
            if (gifInput) {
                gifInput.value = chat.gif.q || '';
                setTimeout(() => gifInput.focus(), 120);
            }
            if (!chat.gif.items.length || chat.gif.lastQuery === null) {
                gifSearch(chat.gif.q || '', true);
            } else {
                gifRenderItems(chat.gif.items);
            }
        }

        /* ---------- dış görünüm / ışık kutusu ---------- */

        function openLightbox(src) {
            const lb = $('#lightbox');
            const img = $('#lightboxImg');
            if (!lb || !img) return;
            img.src = src;
            lb.classList.remove('hidden');
        }

        function closeLightbox() {
            const lb = $('#lightbox');
            const img = $('#lightboxImg');
            if (!lb) return;
            lb.classList.add('hidden');
            if (img) img.src = '';
        }

        /* ---------- bildirimler ---------- */

        const canNotify = 'Notification' in window;

        function updateNotifyBtn() {
            if (!notifyBtn) return;
            if (!canNotify) {
                notifyBtn.title = 'Tarayıcı bildirimi desteklenmiyor';
                notifyBtn.textContent = '🔕';
                return;
            }
            if (Notification.permission === 'granted') {
                notifyBtn.textContent = '🔔';
                notifyBtn.title = 'Masaüstü bildirimleri açık';
                notifyBtn.classList.add('ringing');
            } else if (Notification.permission === 'denied') {
                notifyBtn.textContent = '🔕';
                notifyBtn.title = 'Bildirim izni engellenmiş (tarayıcı ayarlarından aç)';
            } else {
                notifyBtn.textContent = '🔔';
                notifyBtn.title = 'Masaüstü bildirimlerini aç';
            }
        }

        function askNotify() {
            if (!canNotify) {
                toast('Desteklenmiyor', 'Bu tarayıcı masaüstü bildirimlerini desteklemiyor.', 'error', 4000);
                return;
            }
            if (Notification.permission === 'granted') {
                toast('Bildirimler açık', 'Sekme arka plandayken yeni mesajları haber vereceğim.', 'success', 3200);
                return;
            }
            Notification.requestPermission().then((p) => {
                updateNotifyBtn();
                if (p === 'granted') {
                    toast('Bildirimler açıldı 🎉', 'Sekme arka plana geçince haber vereceğim.', 'success', 3500);
                } else {
                    toast('İzin verilmedi', 'Bildirim gelmesini istersen tarayıcı ayarlarından izin ver.', 'error', 4000);
                }
            });
        }

        function previewOf(msg) {
            if (msg.body) return msg.body.length > 110 ? msg.body.slice(0, 110) + '…' : msg.body;
            if (msg.file) return '📎 ' + msg.file.name;
            if (msg.gif) return '🎁 GIF';
            return 'Yeni mesaj';
        }

        function notifyNew(list) {
            const hidden = document.hidden || !document.hasFocus();
            let desktop = 0;
            list.forEach(msg => {
                if (!msg || msg.uid === me.id) return;
                const isMention = msg.body && new RegExp('(^|[^\\p{L}\\p{N}_])@' + escapeRegExp(me.username) + '(?![\\p{L}\\p{N}_])', 'iu').test(msg.body);
                if (isMention) {
                    toast('🔔 Etiketlendin!', msg.username + ': ' + previewOf(msg), 'mention', 7000);
                }
                if (hidden && canNotify && Notification.permission === 'granted' && desktop < 3) {
                    desktop++;
                    try {
                        const n = new Notification(msg.username + ' · ' + SITE_NAME, {
                            body: previewOf(msg),
                            tag: 'novachat-' + msg.id,
                            silent: false
                        });
                        n.onclick = () => { window.focus(); n.close(); };
                    } catch (e) { /* yoksay */ }
                }
            });
        }

        /* ---------- durum (polling) ---------- */

        function applySettingsFrom(j) {
            const s = j.settings || {};
            chat.settings.cooldown_ms = Number(s.cooldown_ms) || 0;
            chat.settings.msg_max_len = Number(s.msg_max_len) || 500;
            chat.settings.max_upload_mb = Number(s.max_upload_mb) || 80;
            chat.settings.quota_gb = Number(s.quota_gb) || 5;
            chat.settings.uploads_enabled = Number(s.uploads_enabled) === 1;
            chat.settings.gifs_enabled = Number(s.gifs_enabled) === 1;
            chat.settings.chat_enabled = Number(s.chat_enabled) === 1;
            chat.settings.games_enabled = Number(s.games_enabled) === 1;
            applyChatState();
        }

        function applyAnnouncement(text) {
            if (!annWrap) return;
            text = (text || '').trim();
            if (!text) { annWrap.classList.add('hidden'); return; }
            let dismissed = null;
            try { dismissed = localStorage.getItem('nc_ann_dismissed'); } catch (e) {}
            if (dismissed === text) { annWrap.classList.add('hidden'); return; }
            if (annText) annText.textContent = text;
            annWrap.classList.remove('hidden');
        }

        function handleState(j) {
            chat.serverOffset = (Number(j.server_time) || 0) * 1000 - Date.now();

            if (j.deleted_ids && j.deleted_ids.length) removeMessages(j.deleted_ids);
            if (j.next_deleted_since) chat.deletedSince = j.next_deleted_since;

            const fresh = j.messages || [];
            const wasFirst = chat.firstState;
            if (wasFirst) {
                chat.firstState = false;
                const sk = $('#skeletonList');
                if (sk) sk.remove();
                messagesEl.innerHTML = '';
                chat.msgIds.clear();
                chat.lastDay = '';
                if (!fresh.length) showEmptyState();
            }
            fresh.forEach((m, idx) => {
                const own = m.uid === me.id;
                appendMessage(m, wasFirst && idx === fresh.length - 1 ? isNearBottom() : own);
                chat.sinceId = Math.max(chat.sinceId, Number(m.id) || 0);
            });
            if (wasFirst) {
                scrollBottom(false);
                if (!messagesEl.querySelector('.msg')) showEmptyState();
            }
            if (!wasFirst) notifyNew(fresh);

            applySettingsFrom(j);
            if (j.announcement !== undefined) applyAnnouncement(j.announcement);

            chat.online = j.online || [];
            renderOnline(chat.online);

            if (j.typing && j.typing.length) {
                typingText.textContent = j.typing.slice(0, 3).join(', ') + (j.typing.length > 3 ? ' ve diğerleri' : '') + ' yazıyor…';
                typingBar.classList.add('active');
            } else {
                typingBar.classList.remove('active');
            }

            if (j.my) {
                chat.muteUntil = Number(j.my.muted_until) || 0;
                chat.quotaUsed = Number(j.my.quota_used) || 0;
                chat.quotaLimit = Number(j.my.quota_limit) || 0;
                const myLast = Number(j.my.last_msg_at) || 0;
                if (myLast > 0) {
                    const cdLeft = myLast + chat.settings.cooldown_ms - serverNow();
                    if (cdLeft > 0 && myLast > chat.lastMsgMs) {
                        chat.lastMsgMs = myLast;
                        startCooldown(myLast);
                    } else if (myLast > chat.lastMsgMs) {
                        chat.lastMsgMs = myLast;
                    }
                }
                applyChatState();
            }

            livePill && livePill.classList.remove('danger');
            connBanner && connBanner.classList.add('hidden');
            chat.pollFails = 0;
        }

        async function pollOnce() {
            try {
                const j = await api('state', {
                    params: {
                        since_id: chat.sinceId,
                        deleted_since: chat.deletedSince
                    }
                });
                handleState(j);
                schedulePoll(3000);
            } catch (e) {
                if (authRedirect(e)) return;
                chat.pollFails++;
                if (livePill) livePill.classList.add('danger');
                if (connBanner && chat.pollFails > 1) connBanner.classList.remove('hidden');
                const delay = Math.min(15000, 2000 * chat.pollFails);
                schedulePoll(delay);
            }
        }

        function schedulePoll(delay) {
            clearTimeout(chat.pollTimer);
            chat.pollTimer = setTimeout(pollOnce, delay);
        }

        /* ---------- mesaj gönderme ---------- */

        function clearComposer() {
            input.value = '';
            input.style.height = 'auto';
            updateCharCount();
            clearReply();
            clearFile(true);
        }

        function updateCharCount() {
            const len = input.value.length;
            charCount.textContent = len + '/' + chat.settings.msg_max_len;
            charCount.classList.toggle('near', len > chat.settings.msg_max_len * 0.85 && len < chat.settings.msg_max_len);
            charCount.classList.toggle('max', len >= chat.settings.msg_max_len);
        }

        function autoGrow() {
            input.style.height = 'auto';
            input.style.height = Math.min(input.scrollHeight, 130) + 'px';
        }

        async function sendMessage() {
            if (!chat.settings.chat_enabled) return;
            if (chat.muteUntil > nowSec()) { toast('Susturulmuşsun', 'Süre dolmadan mesaj gönderemezsin.', 'error', 3000); return; }
            if (chat.cooling) return;
            if (chat.uploading) { toast('Dosya yükleniyor', 'Yükleme bitince gönderebilirsin.', 'info', 2500); return; }
            const text = input.value.trim();
            if (!text && !chat.file) {
                input.focus();
                return;
            }
            const payload = {
                body: text,
                reply_to: chat.reply ? chat.reply.id : 0
            };
            if (chat.file) payload.file_id = chat.file.id;

            sendBtn.classList.add('loading');
            try {
                const j = await api('send', { method: 'POST', data: payload });
                appendMessage(j.message, true);
                chat.sinceId = Math.max(chat.sinceId, j.message.id);
                chat.lastMsgMs = Number(j.last_msg_at) || Date.now();
                if (j.cooldown_ms !== undefined) chat.settings.cooldown_ms = Number(j.cooldown_ms) || 0;
                clearComposer();
                if (cooldownBar) {
                    if (chat.settings.cooldown_ms > 0) startCooldown(j.last_msg_at); else if (cooldownBar) cooldownBar.classList.add('hidden');
                }
                if (newMsgPill) newMsgPill.classList.add('hidden');
                input.focus();
            } catch (e) {
                if (authRedirect(e)) return;
                if (e.payload && e.payload.cooldown_remaining) {
                    chat.lastMsgMs = serverNow() - (chat.settings.cooldown_ms - e.payload.cooldown_remaining);
                    startCooldown(chat.lastMsgMs);
                }
                toast('Mesaj gönderilemedi', e.message, 'error', 4200);
            } finally {
                sendBtn.classList.remove('loading');
                setSendEnabled();
            }
        }

        async function sendGif(url) {
            if (chat.cooling || chat.muteUntil > nowSec()) return;
            if (!url) return;
            try {
                const j = await api('send', { method: 'POST', data: { gif_url: url, reply_to: chat.reply ? chat.reply.id : 0 } });
                appendMessage(j.message, true);
                chat.sinceId = Math.max(chat.sinceId, j.message.id);
                chat.lastMsgMs = Number(j.last_msg_at) || Date.now();
                if (j.cooldown_ms !== undefined) chat.settings.cooldown_ms = Number(j.cooldown_ms) || 0;
                clearReply();
                startCooldown(j.last_msg_at);
                toast('GIF gönderildi', '🎁', 'success', 1500);
                if (newMsgPill) newMsgPill.classList.add('hidden');
            } catch (e) {
                if (authRedirect(e)) return;
                toast('GIF gönderilemedi', e.message, 'error', 4000);
            }
        }

        /* ---------- dosya yükleme ---------- */

        function clearFile(silent) {
            if (pendingFile) pendingFile.classList.add('hidden');
            if (pfBar) pfBar.style.width = '0%';
            chat.file = null;
            if (fileInput) fileInput.value = '';
            if (!silent) updateQuotaUI();
        }

        function handleFile(file) {
            if (!file) return;
            if (!chat.settings.uploads_enabled) { toast('Yükleme kapalı', 'Yönetici dosya yüklemeyi kapatmış.', 'error', 3000); return; }
            const maxBytes = chat.settings.max_upload_mb * 1024 * 1024;
            if (file.size > maxBytes) {
                toast('Dosya çok büyük', 'En fazla ' + chat.settings.max_upload_mb + ' MB yükleyebilirsin.', 'error', 4000);
                return;
            }
            if (chat.quotaLimit > 0 && chat.quotaUsed + file.size > chat.quotaLimit) {
                toast('IP kotan doldu', 'Kullandığın: ' + fmtBytes(chat.quotaUsed) + ' / ' + fmtBytes(chat.quotaLimit), 'error', 4500);
                return;
            }
            if (chat.file) {
                api('cancel_file', { method: 'POST', data: { file_id: chat.file.id } }).catch(() => {});
            }
            chat.file = null;
            chat.uploading = true;
            if (pendingFile) pendingFile.classList.remove('hidden');
            if (pfName) pfName.textContent = file.name;
            if (pfSize) pfSize.textContent = 'Yükleniyor… %0';
            if (pfBar) pfBar.style.width = '0%';
            setSendEnabled();

            const fd = new FormData();
            fd.append('file', file);
            const xhr = new XMLHttpRequest();
            chat.uploadXhr = xhr;
            xhr.open('POST', 'api.php?action=upload', true);
            xhr.setRequestHeader('X-CSRF-Token', CSRF);
            xhr.upload.onprogress = (ev) => {
                if (!ev.lengthComputable) return;
                const pct = Math.round((ev.loaded / ev.total) * 100);
                if (pfBar) pfBar.style.width = pct + '%';
                if (pfSize) pfSize.textContent = 'Yükleniyor… %' + pct;
            };
            xhr.onload = () => {
                chat.uploading = false;
                chat.uploadXhr = null;
                let j = null;
                try { j = JSON.parse(xhr.responseText); } catch (e) {}
                if (xhr.status >= 200 && xhr.status < 300 && j && j.ok) {
                    chat.file = j.file;
                    chat.quotaUsed = Number(j.quota_used) || chat.quotaUsed;
                    chat.quotaLimit = Number(j.quota_limit) || chat.quotaLimit;
                    if (pfSize) pfSize.textContent = j.file.size_txt + ' · gönderime hazır';
                    if (pfBar) pfBar.style.width = '100%';
                    updateQuotaUI();
                    setSendEnabled();
                    toast('Dosya hazır', j.file.name + ' · ' + j.file.size_txt, 'success', 2500);
                } else {
                    toast('Yükleme başarısız', (j && j.error) || 'Sunucu dosyayı kabul etmedi.', 'error', 4500);
                    clearFile();
                }
                setSendEnabled();
            };
            xhr.onerror = () => {
                chat.uploading = false;
                chat.uploadXhr = null;
                toast('Bağlantı hatası', 'Dosya yüklenemedi.', 'error', 4000);
                clearFile();
                setSendEnabled();
            };
            xhr.send(fd);
        }

        function cancelPendingFile() {
            if (chat.uploading && chat.uploadXhr) {
                try { chat.uploadXhr.abort(); } catch (e) {}
                chat.uploading = false;
                chat.uploadXhr = null;
                clearFile();
                toast('Yükleme iptal edildi', '', 'info', 2200);
                setSendEnabled();
                return;
            }
            if (chat.file) {
                const id = chat.file.id;
                api('cancel_file', { method: 'POST', data: { file_id: id } })
                    .then(j => { chat.quotaUsed = Number(j.quota_used) || chat.quotaUsed; updateQuotaUI(); })
                    .catch(() => {});
            }
            clearFile();
        }

        /* ---------- olaylar ---------- */

        function bind() {
            // form
            form.addEventListener('submit', (e) => { e.preventDefault(); sendMessage(); });

            input.addEventListener('input', () => {
                autoGrow();
                updateCharCount();
                const now = Date.now();
                if (input.value.trim() && now - chat.typingAt > 1600) {
                    chat.typingAt = now;
                    api('typing', { method: 'POST', data: {} }).catch(() => {});
                }
            });

            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });

            $('#replyCancel') && $('#replyCancel').addEventListener('click', clearReply);
            $('#pfRemove') && $('#pfRemove').addEventListener('click', cancelPendingFile);

            attachBtn && attachBtn.addEventListener('click', () => fileInput.click());
            fileInput && fileInput.addEventListener('change', () => {
                const f = fileInput.files && fileInput.files[0];
                if (f) handleFile(f);
                fileInput.value = '';
            });

            onlineList && onlineList.addEventListener('click', (e) => {
                const item = e.target.closest('.online-item');
                if (!item) return;
                const name = item.dataset.name || '';
                if (name) {
                    const pos = input.selectionStart;
                    const v = input.value;
                    input.value = v.slice(0, pos) + '@' + name + ' ' + v.slice(pos);
                    input.focus();
                    input.selectionStart = input.selectionEnd = pos + name.length + 2;
                    updateCharCount();
                }
                body.classList.remove('online-open');
            });

            $('#btnPeople') && $('#btnPeople').addEventListener('click', () => body.classList.toggle('online-open'));

            $('#btnLogout') && $('#btnLogout').addEventListener('click', async () => {
                try { await api('logout', { method: 'POST' }); } catch (e) {}
                location.href = 'index.php';
            });

            notifyBtn && notifyBtn.addEventListener('click', askNotify);

            gifFab && gifFab.addEventListener('click', openGifModal);
            $('#gifModal') && bindModals($('#gifModal'));

            if (gifInput) {
                gifInput.addEventListener('input', () => {
                    const v = gifInput.value;
                    if (gifClear) gifClear.classList.toggle('hidden', v.trim() === '');
                    clearTimeout(gifTimer);
                    gifTimer = setTimeout(() => {
                        if (v.trim().length === 1) return;
                        gifSearch(v, true);
                    }, 420);
                });
                gifInput.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        clearTimeout(gifTimer);
                        gifSearch(gifInput.value, true);
                    } else if (e.key === 'Escape') {
                        gifInput.value = '';
                        gifSearch('', true);
                    }
                });
            }
            gifClear && gifClear.addEventListener('click', () => {
                if (gifInput) { gifInput.value = ''; gifInput.focus(); }
                gifClear.classList.add('hidden');
                gifSearch('', true);
            });

            $('#btnGames') && $('#btnGames').addEventListener('click', () => {
                openModal($('#gamesModal'));
                loadGameLb();
            });
            $('#refreshLb') && $('#refreshLb').addEventListener('click', loadGameLb);

            $('#annClose') && $('#annClose').addEventListener('click', () => {
                const text = annText ? annText.textContent : '';
                annWrap.classList.add('hidden');
                try { localStorage.setItem('nc_ann_dismissed', text); } catch (e) {}
            });

            newMsgPill && newMsgPill.addEventListener('click', () => {
                scrollBottom(true);
                newMsgPill.classList.add('hidden');
                chat.unread = 0;
                updateUnreadTitle();
            });

            messagesEl.addEventListener('scroll', () => {
                if (isNearBottom()) {
                    if (newMsgPill) newMsgPill.classList.add('hidden');
                    if (chat.unread > 0) { chat.unread = 0; updateUnreadTitle(); }
                }
            });

            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    chat.unread = 0;
                    updateUnreadTitle();
                }
            });
            window.addEventListener('focus', () => { chat.unread = 0; updateUnreadTitle(); });

            $('#lightboxClose') && $('#lightboxClose').addEventListener('click', closeLightbox);
            $('#lightbox') && $('#lightbox').addEventListener('click', (e) => {
                if (e.target.id === 'lightbox') closeLightbox();
            });

            window.addEventListener('beforeunload', () => clearTimeout(chat.pollTimer));

        // Sekme arka plandayken süs animasyonlarını duraklat: CPU/GPU boşa yorulmaz,
        // geri dönüldüğünde her şey aynı yerden devam eder.
        document.addEventListener('visibilitychange', () => {
            document.documentElement.classList.toggle('nc-hidden', document.hidden);
        });
        }

        /* ---------- başlat ---------- */

        bind();
        bindModals(document);
        updateNotifyBtn();
        updateCharCount();
        applyAnnouncement(annText ? annText.textContent : '');
        updateQuotaUI();
        updateMute();
        setSendEnabled();
        if (chat.settings.cooldown_ms > 0 && chat.lastMsgMs > 0) startCooldown(chat.lastMsgMs);
        showEmptyState();
        schedulePoll(30);
    }

    /* ------------------------------------------------------------------
       Yönlendirme
       ------------------------------------------------------------------ */

    if (page === 'login') {
        initLogin();
    } else if (page === 'chat') {
        initChat();
    }
})();
