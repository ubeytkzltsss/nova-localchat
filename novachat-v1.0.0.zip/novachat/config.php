<?php
/**
 * NovaChat - Yapılandırma (admin panelinden güncellenebilir)
 */

return array (
  'db' => 
  array (
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'novachat_db',
    'user' => 'root',
    'pass' => '',
  ),
  'admin_pass_hash' => '$2y$12$RhlqPBts3CwrzCNRZJ7EU.rcw2ZGNhp78SVZA7dWnKZ/js3V/VuC.',
  'app' => 
  array (
    'name' => 'NovaChat',
    'timezone' => 'Europe/Istanbul',
    'session_days' => 30,
  ),
);
