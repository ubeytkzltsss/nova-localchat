<?php
/**
 * NovaChat - Giriş sayfası
 * Sadeleştirilmiş: sadece kullanıcı adı alanı.
 */
declare(strict_types=1);

require __DIR__ . '/core.php';
nc_page_headers();

$ip = nc_client_ip();

if (nc_ip_banned($ip)) {
    nc_block_page('IP Adresi Engellendi', 'Bu IP adresinden siteye erişim engellenmiş.<br><br>IP: <strong>' . nc_h($ip) . '</strong>', 403);
}
if ((int)nc_setting('maintenance', '0') === 1) {
    nc_block_page('Bakım Çalışması', 'Site şu anda bakım modunda. Kısa bir süre sonra tekrar deneyebilirsin. 🔧', 503);
}

$current = nc_user();
if ($current) {
    if ((int)$current['is_banned'] === 1) {
        $reason = (string)$current['ban_reason'] !== '' ? (string)$current['ban_reason'] : 'Belirtilmedi';
        nc_block_page('Hesabın Askıya Alındı', 'Hesabın bir yönetici tarafından banlandı.<br><br><strong>Sebep:</strong> ' . nc_h($reason) . '<br><strong>Kullanıcı adı:</strong> ' . nc_h($current['username']), 403);
    }
    header('Location: chat.php');
    exit;
}

$siteName = nc_setting('site_name', 'NovaChat');
$csrf     = nc_csrf_token();
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#070812">
<meta name="csrf-token" content="<?= nc_h($csrf) ?>">
<title><?= nc_h($siteName) ?></title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-login simple" data-page="login">

<div class="bg-decor" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
    <div class="grid-floor"></div>
</div>

<main class="simple-wrap">

    <div class="brand big simple-brand">
        <span class="logo-mark">✦</span>
        <span class="brand-name"><?= nc_h($siteName) ?></span>
    </div>

    <section class="simple-card" id="loginCard">
        <h1>Kullanıcı adını yaz</h1>

        <form id="loginForm" autocomplete="off" novalidate>
            <div class="input-shell" id="nameShell">
                <span class="at">@</span>
                <input
                    id="username"
                    name="username"
                    type="text"
                    maxlength="20"
                    minlength="3"
                    placeholder="kullanıcı adı"
                    autocomplete="off"
                    autocapitalize="none"
                    spellcheck="false"
                    autofocus
                    required
                >
                <span class="input-status" id="nameStatus"></span>
            </div>

            <p class="hint-row simple-hint"><span id="nameHint">3-20 karakter · harf, rakam, alt çizgi</span></p>

            <button class="btn-primary" id="loginBtn" type="submit">
                <span class="btn-label">Giriş Yap</span>
                <span class="spinner" aria-hidden="true"></span>
            </button>

            <p class="err" id="loginErr" role="alert"></p>
        </form>

        <p class="faint-note">
            IP adresiniz sunucuda kayıt edilmektedir ve kullanıcı adınız IP adresinizle eşleştirilir.
        </p>
    </section>

</main>

<div id="toastRoot" class="toast-root" aria-live="polite"></div>
<script src="assets/app.js" defer></script>
</body>
</html>
