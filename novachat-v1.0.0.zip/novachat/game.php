<?php
/**
 * NovaChat - Kurabiye İmparatorluğu (sunucu taraflı sonsuz clicker)
 */
declare(strict_types=1);

require __DIR__ . '/core.php';
nc_page_headers();
$user = nc_guard_page();

if ((int)nc_setting('games_enabled', '1') !== 1) {
    nc_block_page('Oyunlar Kapalı', 'Oyunlar şu anda yönetici tarafından devre dışı bırakıldı. 🎮', 403);
}

$siteName = nc_setting('site_name', 'NovaChat');
$csrf = nc_csrf_token();
?>
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#070812">
<meta name="csrf-token" content="<?= nc_h($csrf) ?>">
<title>🍪 Kurabiye İmparatorluğu · <?= nc_h($siteName) ?></title>
<link rel="icon" href="assets/favicon.png">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="page-game"
      data-page="game"
      data-uid="<?= (int)$user['id'] ?>"
      data-username="<?= nc_h($user['username']) ?>"
      data-site-name="<?= nc_h($siteName) ?>">

<div class="bg-decor game-bg" aria-hidden="true">
    <span class="orb orb-1"></span>
    <span class="orb orb-2"></span>
    <span class="orb orb-3"></span>
    <div class="grid-floor"></div>
</div>

<header class="topbar game-topbar">
    <a class="brand back-link" href="chat.php">
        <span class="back-ico">←</span>
        <span class="brand-name">Sohbete dön</span>
    </a>

    <div class="game-head-title">
        <span class="gt-emoji-sm">🍪</span>
        <span>Kurabiye İmparatorluğu</span>
        <span class="brand-badge">sonsuz</span>
    </div>

    <div class="topbar-actions">
        <span class="live-pill" title="Skor sıralaman">
            <span class="live-dot"></span>
            <span id="gameRankPill">#—</span>
        </span>
        <div class="user-chip">
            <span class="avatar" data-avatar="<?= nc_h($user['username']) ?>"><?= nc_h(mb_strtoupper(mb_substr($user['username'], 0, 1))) ?></span>
            <span class="user-name"><?= nc_h($user['username']) ?></span>
        </div>
        <button class="btn-icon" id="gameLogout" title="Çıkış yap" type="button">⏻</button>
    </div>
</header>

<main class="game-layout">

    <section class="panel game-stage">
        <div class="stage-top">
            <div class="cookie-wrap">
                <div class="cookie-aura"></div>
                <div class="cookie-orbit orbit-a"></div>
                <div class="cookie-orbit orbit-b"></div>
                <button id="bigCookie" class="big-cookie" type="button" aria-label="Kurabiyeye tıkla">
                    <span class="cookie-face">🍪</span>
                    <span class="cookie-shine"></span>
                </button>
                <div class="click-layer" id="clickLayer" aria-hidden="true"></div>
            </div>

            <div class="cookie-stats">
                <div class="cookie-count">
                    <strong id="cookieCount">0</strong>
                    <span>kurabiye</span>
                </div>

                <div class="stat-chips">
                    <div class="stat-chip">
                        <span class="sc-ico">⚡</span>
                        <div><strong id="cpsCount">0</strong><small>saniyede</small></div>
                    </div>
                    <div class="stat-chip">
                        <span class="sc-ico">👆</span>
                        <div><strong id="clickPower">1</strong><small>tıklama gücü</small></div>
                    </div>
                    <div class="stat-chip">
                        <span class="sc-ico">⏳</span>
                        <div><strong id="tokenCount">30</strong><small>tıklama hakkı</small></div>
                    </div>
                </div>

                <div class="cookie-meta">
                    <span>Toplam kazanç: <strong id="totalEarned">0</strong></span>
                    <span>·</span>
                    <span>Toplam tıklama: <strong id="clickTotal">0</strong></span>
                </div>

                <div class="token-track"><div class="token-fill" id="tokenFill"></div></div>
            </div>
        </div>

        <div class="upgrade-card" id="upgradeCard">
            <div class="upgrade-info">
                <span class="up-emoji">💪</span>
                <div>
                    <strong>Daha güçlü tıklama</strong>
                    <span>Seviye <b id="clickLevel">1</b> · her seviye <b>+2</b> güç</span>
                </div>
            </div>
            <button class="btn-buy" id="buyClickUpgrade" type="button">
                Yükselt <span id="clickUpgradeCost">50</span> 🍪
            </button>
        </div>

        <p class="game-tip">
            💡 <kbd>Boşluk</kbd> tuşuyla da tıklayabilirsin. İlerlemen her tıklamada sunucuya kaydedilir;
            sayfayı kapatıp geri döndüğünde kaldığın yerden devam edersin.
        </p>
    </section>

    <section class="panel shop">
        <div class="panel-head">
            <h2>🛒 Dükkân</h2>
            <div class="buy-toggle" id="buyToggle">
                <button type="button" data-amount="1" class="active">×1</button>
                <button type="button" data-amount="10">×10</button>
            </div>
        </div>
        <ul class="shop-list" id="shopList">
            <li class="shop-loading">Dükkân açılıyor…</li>
        </ul>
    </section>

    <aside class="panel game-lb-panel">
        <div class="panel-head">
            <h2>🏆 Skor Tablosu</h2>
            <span class="badge">Top 10</span>
        </div>
        <ol class="lb-list" id="gameLb">
            <li class="lb-empty">Yükleniyor…</li>
        </ol>
        <div class="lb-me" id="lbMe"></div>
        <button class="btn-ghost full" id="refreshGameLb" type="button">↻ Skoru Yenile</button>
    </aside>

</main>

<div class="modal hidden" id="offlineModal" role="dialog" aria-modal="true" aria-label="Çevrimdışı kazanç">
    <div class="modal-backdrop"></div>
    <div class="modal-card offline-card">
        <div class="offline-emoji">🌙</div>
        <h3>Sen yokken çalışmaya devam ettim!</h3>
        <p>Döndüğünde <strong id="offlineGain">0</strong> kurabiye seni bekliyordu.</p>
        <p class="muted small" id="offlineAway"></p>
        <button class="btn-primary" id="offlineClose" type="button">Harika, devam! 🍪</button>
    </div>
</div>

<canvas id="confetti" class="confetti-canvas" aria-hidden="true"></canvas>
<div id="toastRoot" class="toast-root" aria-live="polite"></div>
<script src="assets/game.js" defer></script>
</body>
</html>
